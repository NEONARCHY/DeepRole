import {createInterface} from 'node:readline';
import {DeepRoleBrowser} from './runtime.mjs';

// This Node process owns its browser. The REPL gets only this finite UI API.
const browser=new DeepRoleBrowser(process.argv[2]);
const methods=new Set(['start','status','tabs','open','openDeepRole','inspect','screenshot','act','grantFile','navigate','restart','openManualLogin','returnToBackground']);
const input=createInterface({input:process.stdin,crlfDelay:Infinity});
let queue=Promise.resolve();
const reply=value=>process.stdout.write(JSON.stringify(value)+'\n');
reply({ready:true,status:browser.status()});
input.on('line',line=>{
 queue=queue.then(async()=>{
  let request;try{request=JSON.parse(line);}catch{reply({error:'Malformed browser request'});return;}
  const{id,method,args}=request;
  if(!Number.isSafeInteger(id)||!Array.isArray(args)||args.length>4||!methods.has(method)&&method!=='close'){reply({id,error:'Unsupported browser request'});return;}
  try{const result=await browser[method](...args);reply({id,result:result??null});if(method==='close'){input.close();process.stdin.pause();}}
  catch(error){reply({id,error:String(error.message)});}
 }).catch(error=>reply({error:String(error.message)}));
});
input.on('close',()=>{queue.finally(()=>browser.close()).catch(()=>{});});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{browser.close().finally(()=>process.exit(0));});
