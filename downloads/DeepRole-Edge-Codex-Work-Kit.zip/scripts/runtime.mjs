import {readFileSync,writeFileSync,existsSync,statSync,realpathSync} from 'node:fs';
import {join,extname,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {PrivateBrowserDriver} from './driver.mjs';
import {FORMAT,ownedWorkspace,childPath,sha256,allowedUrl,noLinks} from './isolation.mjs';
const delay=ms=>new Promise(r=>setTimeout(r,ms));

/** Browser UI only. No main-profile attachment, storage RPC or public eval API. */
export class DeepRoleBrowser{
 #root;#config;#driver;#manifest;#extensionId;#contextTab;#seen=new Map();#files=new Map();#busy=false;
 constructor(configPath){
  noLinks(configPath);this.#config=JSON.parse(readFileSync(configPath,'utf8'));
  if(this.#config.format!==FORMAT)throw Error('Unknown browser configuration');
  this.#root=ownedWorkspace(this.#config.workspace);
  if(resolve(configPath)!==join(this.#root,'config.json'))throw Error('Configuration must belong to its workspace');
  this.#verifyExtension();this.#driver=new PrivateBrowserDriver(this.#root,{executable:this.#config.executable,headless:this.#config.headless??true});
 }
 #verifyExtension(){
  ownedWorkspace(this.#root);const files=this.#config.extensionFiles;
  if(!files||typeof files!=='object'||Object.keys(files).length!==23)throw Error('Expected the verified 23-file DeepRole build');
  for(const[name,hash]of Object.entries(files))if(!/^[a-f0-9]{64}$/iu.test(hash)||sha256(childPath(join(this.#root,'extension'),name))!==hash.toLowerCase())throw Error('Extension code changed: '+name);
  this.#manifest=JSON.parse(readFileSync(join(this.#root,'extension','manifest.json'),'utf8'));
  if(this.#manifest.manifest_version!==3||this.#manifest.short_name!=='DeepRole'||!this.#manifest.side_panel?.default_path)throw Error('Expected DeepRole MV3 side panel');
 }
 status(){return{workspace:this.#root,profile:join(this.#root,'profile'),browser:this.#config.browser??'brave',automationHeadless:this.#config.headless??true,mode:this.#driver.mode,extensionId:this.#extensionId,extensionVersion:this.#manifest.version,mainProfileAttached:false};}
 async start(){
  this.#verifyExtension();await this.#driver.start();
  if(!this.#extensionId){
   const cachePath=join(this.#root,'extension-target.json');noLinks(cachePath);
   if(existsSync(cachePath)){
    const cached=JSON.parse(readFileSync(cachePath,'utf8')),owner=JSON.parse(readFileSync(join(this.#root,'ownership.json'),'utf8'));
    if(cached.format!==FORMAT||cached.workspaceId!==owner.id||cached.manifestHash!==this.#config.extensionFiles['manifest.json']||!(/^[a-p]{32}$/u.test(cached.extensionId)))throw Error('Cached extension identity does not match its owned workspace');
    this.#extensionId=cached.extensionId;
   }
   for(let attempt=0;attempt<40;attempt++){
    if(this.#extensionId)break;
    for(const target of(await this.#driver.targets()).filter(t=>['page','service_worker'].includes(t.type)&&t.url.startsWith('chrome-extension://'))){
     const manifest=await this.#driver.read(target.targetId,'chrome.runtime.getManifest()').catch(()=>null);
     if(manifest?.short_name==='DeepRole'&&manifest.version===this.#manifest.version&&manifest.background?.service_worker===this.#manifest.background?.service_worker){this.#extensionId=new URL(target.url).hostname;break;}
    }
    if(this.#extensionId)break;await delay(100);
   }
   if(!this.#extensionId)throw Error('DeepRole has not exposed a verified target in its isolated browser');
   if(!existsSync(cachePath)){const owner=JSON.parse(readFileSync(join(this.#root,'ownership.json'),'utf8'));writeFileSync(cachePath,JSON.stringify({format:FORMAT,workspaceId:owner.id,manifestHash:this.#config.extensionFiles['manifest.json'],extensionId:this.#extensionId},null,2)+'\n',{flag:'wx'});}
  }
  return this.status();
 }
 #url(url){return allowedUrl(url,this.#extensionId,this.#config.extraOrigins??[]);}
 async #target(tabId){
  if(this.#driver.mode!=='background')throw Error('UI automation is paused during manual login');
  const target=(await this.#driver.targets()).find(t=>t.type==='page'&&t.targetId===tabId);if(!target)throw Error('Owned tab is missing; list tabs again');this.#url(target.url);return target;
 }
 async tabs(){await this.start();return{...this.status(),tabs:(await this.#driver.targets()).filter(t=>{try{return t.type==='page'&&!!this.#url(t.url);}catch{return false;}}).map(t=>({tabId:t.targetId,title:t.title,url:t.url}))};}
 async open(url){await this.start();const requested=this.#url(url),{targetId}=await this.#driver.command('Target.createTarget',{url:requested,background:true});
  for(let i=0;i<80;i++){
   let state;try{state=await this.#driver.read(targetId,'({url:location.href,ready:document.readyState})');}catch{}
   if(state&&(state.url!=='about:blank'||requested==='about:blank')&&['interactive','complete'].includes(state.ready)){
    this.#url(state.url);const target=(await this.#driver.targets()).find(t=>t.targetId===targetId);if(target?.url===state.url)return this.inspect(targetId);
   }
   await delay(100);
  }
  throw Error('Navigation did not produce a settled allowed document; inspect the owned tab before retrying');
 }
 async openDeepRole(){
  await this.start();const path=this.#manifest.side_panel.default_path;
  if(typeof path!=='string'||path.includes('..')||path.includes(':')||path.startsWith('/'))throw Error('Unsafe extension entrypoint');
  const url='chrome-extension://'+this.#extensionId+'/'+path;
  if(!this.#contextTab)return this.open(url);
  const host=await this.#target(this.#contextTab);
  if(new URL(host.url).origin!=='https://chat.deepseek.com')throw Error('Activate the owned DeepSeek tab first');
  const targets=await this.#driver.targets(),before=new Set(targets.map(t=>t.targetId));
  const worker=targets.find(t=>t.type==='service_worker'&&t.url.startsWith('chrome-extension://'+this.#extensionId+'/'));
  if(!worker)throw Error('The owned DeepRole worker is not ready; inspect the current tab');
  // Browser-window UI only. No storage/game RPC and no generic public eval.
  // An extension page's currentWindow must be the SAME window as its host.
  const windowContext=await this.#driver.read(worker.targetId,`(async()=>{const [host]=await chrome.tabs.query({active:true,lastFocusedWindow:true});if(!host||host.url!==${JSON.stringify(host.url)})throw Error('Owned active DeepSeek context changed');const old=await chrome.tabs.query({url:${JSON.stringify(url)}});const tab=await chrome.tabs.create({url:${JSON.stringify(url)},windowId:host.windowId,active:false});return{sourceWindowId:host.windowId,panelWindowId:tab.windowId,previousPanelWindows:old.map(t=>t.windowId)};})()`);
  if(windowContext.sourceWindowId!==windowContext.panelWindowId)throw Error('DeepRole opened outside its owned host window');
  for(let i=0;i<80;i++){
   const pages=(await this.#driver.targets()).filter(t=>t.type==='page'&&t.url===url&&!before.has(t.targetId));
   if(pages.length>1)throw Error('Ambiguous new DeepRole page; inspect owned tabs');
   if(pages.length===1)return{...await this.inspect(pages[0].targetId),windowContext};
   await delay(100);
  }
  throw Error('Created DeepRole page not observed; do not repeat without inspecting tabs');
 }
 async inspect(tabId){
  const target=await this.#target(tabId),old=this.#seen.get(tabId),key='__deeprole_agent_'+randomUUID().replaceAll('-','');
  const page=await this.#driver.read(tabId,`(${inspectDOM.toString()})(${JSON.stringify(key)},${visibleLabel.toString()})`);
  const snapshotId=randomUUID();this.#seen.set(tabId,{snapshotId,key,url:target.url,elements:new Map(page.elements.map(e=>[e.elementId,e]))});
  if(old)await this.#driver.read(tabId,`delete window[${JSON.stringify(old.key)}]`).catch(()=>{});
  return{tabId,snapshotId,url:target.url,...page};
 }
 async screenshot(tabId){await this.#target(tabId);const result=await this.#driver.page(tabId,'Page.captureScreenshot',{format:'png',captureBeyondViewport:false});return{mimeType:'image/png',data:result.data};}
 async #mutation(run){if(this.#busy)throw Error('Another browser action is still running');this.#busy=true;try{return await run();}finally{this.#busy=false;}}
 async act({tabId,snapshotId,elementId,action,value='',fileId,expectedText}){
  return this.#mutation(async()=>{
   const target=await this.#target(tabId),seen=this.#seen.get(tabId),element=seen?.elements.get(elementId);
   if(!seen||seen.snapshotId!==snapshotId||seen.url!==target.url||!element)throw Error('Stale snapshot or element; inspect again');
   if(!['click','fill','select','press','upload'].includes(action)||typeof value!=='string'||value.length>20000)throw Error('Unsupported browser action');
   const expression=`window[${JSON.stringify(seen.key)}]?.get(${JSON.stringify(elementId)})`;
   const meta=await this.#driver.read(tabId,`(${elementMeta.toString()})(${expression},${visibleLabel.toString()})`);
   if(!meta||meta.label!==element.label||meta.type!==element.type)throw Error('Element changed since the snapshot; inspect again');
   if(meta.secret)throw Error('Passwords, payment fields and verification codes require manual user input');
   if(action!=='upload'&&(!meta.visible||!meta.unobstructed||meta.disabled))throw Error('Element is hidden, blocked or disabled; inspect again');
   let file;
   if(action==='upload'){file=this.#files.get(fileId);if(!file||!meta.file)throw Error('Upload requires a granted file and a file control');if(sha256(file.path)!==file.hash)throw Error('Granted file changed; obtain a new grant');}
   this.#seen.delete(tabId);
   try{
    if(action==='upload'){
     const handle=await this.#driver.page(tabId,'Runtime.evaluate',{expression,returnByValue:false});if(!handle.result?.objectId)throw Error('File control disappeared');
     await this.#driver.page(tabId,'DOM.setFileInputFiles',{objectId:handle.result.objectId,files:[file.path]});
    }else if(action==='click'){
     await this.#driver.page(tabId,'Page.setInterceptFileChooserDialog',{enabled:true});
     await this.#driver.page(tabId,'Input.dispatchMouseEvent',{type:'mousePressed',x:meta.x,y:meta.y,button:'left',clickCount:1});
     await this.#driver.page(tabId,'Input.dispatchMouseEvent',{type:'mouseReleased',x:meta.x,y:meta.y,button:'left',clickCount:1});
    }else if(action==='press'){
     const codes={Enter:13,Escape:27,Tab:9,ArrowDown:40,ArrowUp:38};if(!Object.hasOwn(codes,value))throw Error('Unsupported page key');
     await this.#driver.read(tabId,`${expression}.focus()`);
     await this.#driver.page(tabId,'Input.dispatchKeyEvent',{type:'keyDown',key:value,code:value,windowsVirtualKeyCode:codes[value],...value==='Enter'?{text:'\r'}:{}});
     await this.#driver.page(tabId,'Input.dispatchKeyEvent',{type:'keyUp',key:value,code:value,windowsVirtualKeyCode:codes[value]});
    }else{
     const result=await this.#driver.read(tabId,`(${fillDOM.toString()})(${expression},${JSON.stringify(action)},${JSON.stringify(value)})`);if(result?.error)throw Error(result.error);
    }
    await delay(200);let after=await this.inspect(tabId);
    if(expectedText!==undefined){if(typeof expectedText!=='string'||!expectedText.trim())throw Error('Expected text must be nonempty');for(let i=0;i<8&&!after.text.includes(expectedText);i++){await delay(200);after=await this.inspect(tabId);}return{acted:true,verified:after.text.includes(expectedText),after};}
    return{acted:true,after};
   }catch(error){throw Error('Action outcome may be unknown; inspect before retrying. '+error.message,{cause:error});}
  });
 }
 grantFile(path){
  if(typeof path!=='string'||!['.json','.txt','.md','.csv','.png','.jpg','.jpeg','.webp','.pdf'].includes(extname(path).toLowerCase())||/[\\/](?:\.codex|\.ssh|\.aws|\.azure|User Data|Login Data|Cookies|Network)[\\/]/iu.test(path))throw Error('File is not eligible for browser upload');
  noLinks(path);const canonical=realpathSync(path),stat=statSync(canonical);if(!stat.isFile()||stat.size>30*1024*1024)throw Error('Upload must be a regular file no larger than 30 MB');
  const fileId=randomUUID();this.#files.set(fileId,{path:canonical,hash:sha256(canonical)});return{fileId,path:canonical,bytes:stat.size};
 }
 async navigate(tabId,action,direction='down'){
  return this.#mutation(async()=>{const target=await this.#target(tabId);this.#seen.delete(tabId);
   if(action==='reload')await this.#driver.page(tabId,'Page.reload');
   else if(action==='activate'){await this.#driver.command('Target.activateTarget',{targetId:tabId});if(new URL(target.url).origin==='https://chat.deepseek.com')this.#contextTab=tabId;}
   else if(action==='back'){const h=await this.#driver.page(tabId,'Page.getNavigationHistory');if(h.currentIndex>0){this.#url(h.entries[h.currentIndex-1].url);await this.#driver.page(tabId,'Page.navigateToHistoryEntry',{entryId:h.entries[h.currentIndex-1].id});}}
   else if(action==='scroll'&&['up','down'].includes(direction))await this.#driver.read(tabId,`(${scrollDOM.toString()})(${direction==='up'?-1:1})`);
   else throw Error('Unsupported page navigation');
   await delay(250);return this.inspect(tabId);
  });
 }
 // A direct runtime.reload did not reliably re-enable command-line-loaded
 // Brave extensions in native QA. Explicitly restart our own browser instead;
 // preserve the same profile, and never silently recover/repeat an action.
 async restart(){if(this.#busy)throw Error('Wait for the current action');await this.close();return{...await this.start(),restarted:true,verificationRequired:true};}
 async close(){this.#seen.clear();this.#extensionId=undefined;this.#contextTab=undefined;await this.#driver.close();}
 async openManualLogin(){if(this.#busy)throw Error('Wait for the current action');await this.close();this.#verifyExtension();const login=await this.#driver.openManualLogin();return{...this.status(),...login};}
 async returnToBackground(){await this.close();return this.start();}
}

function visibleLabel(el){
 let associated='';if(el.labels?.[0]){const copy=el.labels[0].cloneNode(true);for(const control of copy.querySelectorAll('input,textarea,select'))control.remove();associated=copy.textContent;}
 return String(el.getAttribute('aria-label')||associated||el.getAttribute('placeholder')||el.innerText||el.title||el.name||el.type||'').replace(/\s+/gu,' ').trim().slice(0,180);
}
function inspectDOM(key,describe){
 const map=new Map();window[key]=map;let next=0;
 const elements=Array.from(document.querySelectorAll('button,a[href],input,textarea,select,summary,[role="button"],[role="checkbox"],[role="switch"],[role="radio"],[aria-pressed],[tabindex="0"],[contenteditable="true"]')).flatMap(el=>{
  const r=el.getBoundingClientRect(),style=getComputedStyle(el),file=el.type==='file',x=r.x+r.width/2,y=r.y+r.height/2,top=document.elementFromPoint(x,y);
  if(el.type==='hidden'||!file&&(r.width<1||r.height<1||r.bottom<=0||r.top>=innerHeight||r.right<=0||r.left>=innerWidth||style.visibility==='hidden'||style.display==='none'||!top||top!==el&&!el.contains(top)))return[];
  const elementId=String(++next);map.set(elementId,el);const label=describe(el),secret=/password|cc-|current-password|new-password|one-time-code/iu.test((el.type||'')+' '+(el.autocomplete||''))||/парол|password|verification code|код подтверждения/iu.test(label);
  return[{elementId,tag:el.tagName.toLowerCase(),type:el.type??'',label,disabled:!!el.disabled,...['checkbox','radio'].includes(el.type)?{checked:!!el.checked}:{},...!secret&&el.matches('input,textarea,select')&&el.type!=='file'?{value:String(el.value).slice(0,500)}:{},...el.tagName==='SELECT'?{options:Array.from(el.options).map(o=>({value:o.value,label:o.label}))}:{}}];
 }).slice(0,160);
 return{title:document.title,text:(document.body?.innerText||'').slice(0,24000),elements,viewport:{width:innerWidth,height:innerHeight},note:document.querySelector('iframe')?'Iframe contents are not read; open DeepRole through its own extension page.':undefined};
}
function elementMeta(el,describe){
 if(!el?.isConnected)return null;const r=el.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2,style=getComputedStyle(el),top=document.elementFromPoint(x,y);
 const label=describe(el);
 return{type:el.type??'',label,disabled:!!el.disabled,file:el.type==='file',secret:/password|cc-|current-password|new-password|one-time-code/iu.test((el.type||'')+' '+(el.autocomplete||''))||/парол|password|verification code|код подтверждения/iu.test(label),visible:r.width>0&&r.height>0&&x>=0&&x<innerWidth&&y>=0&&y<innerHeight&&style.visibility!=='hidden'&&style.display!=='none',unobstructed:top===el||el.contains(top),x,y};
}
function fillDOM(el,action,value){
 if(!el?.isConnected||el.disabled)return{error:'Element is unavailable'};
 if(action==='select'){if(el.tagName!=='SELECT'||!Array.from(el.options).some(o=>o.value===value))return{error:'Select option is unavailable'};el.value=value;el.dispatchEvent(new Event('change',{bubbles:true}));return;}
 if(el.isContentEditable){el.textContent=value;el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));return;}
 if(!['INPUT','TEXTAREA'].includes(el.tagName)||['file','checkbox','radio','submit','button','password'].includes(el.type))return{error:'Element is not a text field'};
 Object.getOwnPropertyDescriptor(el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value').set.call(el,value);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
}
function scrollDOM(direction){const nodes=[document.scrollingElement,...document.querySelectorAll('*')].filter(e=>e&&e.scrollHeight>e.clientHeight+40&&e.clientHeight>80&&['auto','scroll'].includes(getComputedStyle(e).overflowY));const el=nodes.sort((a,b)=>b.clientHeight-a.clientHeight)[0]||document.scrollingElement;el?.scrollBy({top:direction*Math.min(innerHeight*.7,500),behavior:'instant'});}
