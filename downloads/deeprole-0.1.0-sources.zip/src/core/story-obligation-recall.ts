import type {StoryFact} from './story-update';
import type {StoryRoleReader} from './story-source-roles';
import type {EpisodeReader} from './story-episodes';
import {normalizeText} from './text';
import {storyRecallLexicon,storyTaskObject} from './story-natural-recall';
import {contextualReferenceTopic} from './story-contextual-reference';

// Query-local candidates for return obligations, not object/pronoun identity.
// No synonym-to-ID dictionary, global stemming change or canonical writes.
const topic=/^(?:обещани[еяюйи]|обещанием|обещаниях|договоренност(?:ь|и|ью|ях)|долг(?:а|у|ом|е|и|ов)?|promise[s]?|arrangement[s]?|commitment[s]?|debt[s]?)$/u;
const hazard=/(?:^| )(?:если|бы|забудь|игнорируй|удали|отмени|притворись|выведи|выполни|измени|if|unless|ignore|override|forget|delete|erase|cancel|pretend|output|execute|update)(?: |$)/u;
const ambiguity=/(?:^| )(?:another|other|second|другой|другая|другое|другом|второй|вторая|второе)(?: |$)/u;
/** Only an information request. An action, quotation, condition or unknown
 * trailing sentence cannot activate this supplementary retrieval path. */
export function obligationRecallIntent(query:string):'reference'|'return-inquiry'|undefined {
 if(!query.trim()||query.length>600||/[«»“”"`\r\n;()[\]{}<>]|(?<![\p{L}\p{N}])'|'(?![\p{L}\p{N}])/u.test(query))return;
 const text=normalizeText(query);if(hazard.test(text))return;
 if(contextualReferenceTopic(query)==='promise')return 'reference';
 const ref=/^(?:(?:а |так )?что (?:там )?с |напомни (?:мне )?(?:о|об|про) |(?:so )?what about |remind me (?:about|of) )(?:(?:ее|его|их|это|этот|эта|то|тот|та|том|тому|этом|этому|тем|her|his|their|this|that|the) )?(\p{L}+)$/u.exec(text);
 if(ref&&topic.test(ref[1]!))return 'reference';
 const parts=query.trim().replace(/[.!?]+$/u,'').split(/[.!?]+\s*/u);
 if(!parts.length||parts.length>2||parts.some(p=>!p.trim()))return;
 const first=normalizeText(parts[0]!);
 if(!/^(?:куда|где|where) /u.test(first))return;
 if(/(?:^| )(?:и|and) (?:я |i )?(?:открываю|открой|беру|возьми|удали|добавь|open|take|delete|add|generate|create)(?: |$)/u.test(text))return;
 // The broad lane describes possible RETURNS, not every scene mentioning an
 // object: a destination query also needs an explicit obligation/return or a
 // comparison between preparation and actual handover. Unknown objects remain
 // unresolved; if several returns fit, retain their separate candidate groups.
 const transfer=/(?:^| )(?:вернуть|возврат|возврата|возврату|обещанный|обещанного|обещание|долг|долга|return|returned|returning|promised|promise|debt)(?: |$)/u;
 const nonFulfillment=/(?:не (?:значит|означает|означают)|not mean|does not mean|did not necessarily|has not|have not)/u;
 const receipt=/(?:^| )(?:получила|получил|получили|возвращен|возвращена|вернули|хозяйка|владелец|received|owner|returned|received|settle|settled|fulfil|fulfill)(?: |$)/u;
 if(parts.length===2){const second=normalizeText(parts[1]!);if(!nonFulfillment.test(second)||!receipt.test(second)&&!transfer.test(second))return;}
 if(!transfer.test(text)&&!(nonFulfillment.test(text)&&receipt.test(text)))return;
 return 'return-inquiry';
}

/** Full-sentence task titles need not be rewritten into terse labels. Derive a
 * literal PREFIX after an explicit promise-to-return, then require two OTHER
 * accepted texts to repeat it. The whole title/condition is still transported.
 * Labels are retrieval keys, never unique physical objects or task identities. */
export function obligationRecallFacts(facts:StoryFact[],query:string,recent:string[],names:string[],roles?:StoryRoleReader,episodes?:EpisodeReader){
 const intent=obligationRecallIntent(query);
 if(!intent||!roles||!episodes||roles.question)return;
 const lex=storyRecallLexicon(names),maskedQuery=lex.mask(query);
 if(maskedQuery.includes('__deeprole_name__'))return;
 const hasTopic=(s:string)=>lex.mask(s).split(' ').some(w=>topic.test(w));
 const cache=new WeakMap<StoryFact,string[][]>(),texts=new WeakMap<StoryFact,string[][]>();
 const textFields=(f:StoryFact)=>{let p=texts.get(f);if(!p){p=lex.clauses(f.text);texts.set(f,p);}return p;};
 const fields=(f:StoryFact)=>{let p=cache.get(f);if(!p){p=[...textFields(f),...lex.clauses(f.task?.title??'')];cache.set(f,p);}return p;};
 const contains=(parts:string[][],terms:string[])=>parts.some(words=>words.some((_,at)=>terms.every((w,i)=>words[at+i]===w)));
 const textContains=(s:string,terms:string[])=>contains(lex.clauses(s),terms);
 const occurrences=(parts:string[][],terms:string[])=>parts.flatMap((words,clause)=>words.flatMap((_,at)=>terms.every((w,i)=>words[at+i]===w)?[{clause,at,end:at+terms.length}]:[]));
 const uncovered=(parts:string[][],terms:string[],qualified:string[][])=>{
  const longer=qualified.filter(t=>t.length>terms.length).flatMap(t=>occurrences(parts,t));
  return occurrences(parts,terms).some(hit=>!longer.some(span=>span.clause===hit.clause&&span.at<=hit.at&&span.end>=hit.end));
 };
 const proved=(f:StoryFact)=>roles.status?.(f)==='bound'&&!!episodes.read(f)&&Object.values(roles.read(f)??{}).every(p=>!p.unavailable);
 const tasks=facts.filter(f=>f.task&&/^(?:(?:я (?:обещаю|обещал[аи]?)|i promise(?:d)? to) )?(?:вернуть|возвратить|возврат|return|give back) /u.test(lex.mask(f.task.title)));
 if(!tasks.length||tasks.length>16)return;
 const labels=new Map<string,{terms:string[];tasks:StoryFact[];sentence:boolean}>();
 for(const task of tasks){
  const title=lex.mask(task.task!.title),sentence=/^(?:я (?:обещаю|обещал[аи]?)|i promise(?:d)? to) /u.test(title);
  let terms:string[]|undefined;
  if(!sentence)terms=storyTaskObject(task.task!.title,names)?.terms;
  else {
   const rest=task.task!.title.replace(/^(?:я (?:обещаю|обещал[аи]?)|i promise(?:d)? to)\s+(?:вернуть|возвратить|возврат|return|give back)\s+(?:(?:the|a|an)\s+)?/iu,'');
   const prefix=lex.clauses(rest)[0]??[];
   for(let count=Math.min(6,prefix.length);count>=2;count--){const candidate=prefix.slice(0,count);if(candidate.some(t=>t.startsWith('__deeprole_')))continue;
    // Proof is checked for the entire resulting group below, including failed
    // or unavailable sources; never derive a label from only its trusted half.
    if(facts.filter(f=>f!==task&&contains(textFields(f),candidate)).length>=2){terms=candidate;break;}
   }
  }
  if(!terms?.length)continue;
  if(!contains(textFields(task),terms)||!textContains(task.quote,terms))return;
  const key=terms.join(' '),group=labels.get(key)??{terms,tasks:[],sentence:false};group.tasks.push(task);group.sentence||=sentence;labels.set(key,group);
 }
 if(!labels.size||labels.size>4)return;
 let selected=[...labels.values()],anchors:StoryFact[]=[];
 if(intent==='reference'){
  const latest=recent.at(-1);if(!latest||ambiguity.test(lex.mask(latest)))return;
  // Existing terse-label contextual handling owns that path. This supplement
  // only bridges full prose titles and an exact accepted latest-turn quote.
  selected=selected.filter(g=>g.sentence);
  const accepted=facts.filter(f=>episodes.read(f)?.period==='latest-turn'&&proved(f)&&latest.includes(f.quote)&&hasTopic(f.text)&&hasTopic(f.quote));
  // A title may repeat "old velvet cloak belonging..." in sources while the
  // scene says "old velvet cloak tagged...". Its shorter literal prefixes are
  // already source-proved; prefer the longest one present in BOTH scene fields.
  // A generic "old velvet" occurrence inside it is not a second object. An
  // independent occurrence elsewhere remains ambiguous and blocks narrowing.
  const matches=selected.flatMap(group=>accepted.flatMap(anchor=>{
   for(let n=group.terms.length;n>=(group.sentence?2:group.terms.length);n--){const terms=group.terms.slice(0,n);
    if(textContains(anchor.text,terms)&&textContains(anchor.quote,terms))return [{group,anchor,terms}];
   }
   return [];
  }));
  const specific=matches.filter(m=>{
   const qualified=matches.filter(other=>other.anchor===m.anchor).map(other=>other.terms);
   return uncovered(textFields(m.anchor),m.terms,qualified)&&uncovered(lex.clauses(m.anchor.quote),m.terms,qualified);
  });
  const pairs=new Map<string,{terms:string[];tasks:StoryFact[];anchors:StoryFact[]}>();
  for(const m of specific){const key=m.terms.join(' '),p=pairs.get(key)??{terms:m.terms,tasks:[],anchors:[]};p.tasks.push(...m.group.tasks);p.anchors.push(m.anchor);pairs.set(key,p);}
  if(pairs.size!==1)return;
  const pair=[...pairs.values()][0]!;
  selected=[{terms:pair.terms,tasks:[...new Set(pair.tasks)],sentence:true}];anchors=[...new Set(pair.anchors)];
  // Topic and label may occupy adjacent clauses in the SAME accepted quote.
  // Extra raw scene text can veto it, never supply a positive bridge itself.
  let remainder=latest;for(const anchor of anchors)remainder=remainder.replace(anchor.quote,' ');
  if(hasTopic(remainder))return;
  const latestParts=lex.clauses(latest);
  for(const g of labels.values()){
   for(let n=g.terms.length;n>=(g.sentence?2:g.terms.length);n--){const terms=g.terms.slice(0,n);
    if(!contains(latestParts,terms))continue;
    if(terms.join(' ')!==pair.terms.join(' ')&&uncovered(latestParts,terms,[pair.terms]))return;
    break;
   }
  }
 }
 const group=[...new Set([...anchors,...facts.filter(f=>selected.some(g=>contains(fields(f),g.terms)))])];
 if(!group.length||group.some(f=>!proved(f))||selected.some(g=>g.tasks.some(f=>!proved(f)||!roles.read(f)?.promisor)))return;
 return group.sort((a,b)=>episodes.position(a)-episodes.position(b));
}
