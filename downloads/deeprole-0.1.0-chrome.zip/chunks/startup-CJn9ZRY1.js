function o(e,r=8e3){return new Promise((n,t)=>{const i=setTimeout(()=>t(new Error("startup-timeout")),r);e.then(n,t).finally(()=>clearTimeout(i))})}export{o as s};
