import { constants, copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { browserExecutable } from './scripts/driver.mjs';
import { childPath, FORMAT, ownedWorkspace, sha256 } from './scripts/isolation.mjs';

const kitRoot = dirname(fileURLToPath(import.meta.url));
const source = join(kitRoot, 'extension');
const requestedRoot = resolve(process.argv[2] ?? join(homedir(), '.codex', 'deeprole-edge-work'));
const executable = browserExecutable('edge');
if (!executable) throw Error('Microsoft Edge was not found in a Windows installation directory');

const fingerprints = JSON.parse(readFileSync(join(kitRoot, 'extension-files.json'), 'utf8').replace(/^\uFEFF/u, ''));
const files = Object.entries(fingerprints);
if (files.length !== 23 || !Object.hasOwn(fingerprints, 'manifest.json')) throw Error('Expected the verified Chromium file set');
for (const [name, expected] of files) {
  if (typeof expected !== 'string' || sha256(childPath(source, name)) !== expected.toLowerCase()) throw Error('Kit file hash mismatch: ' + name);
}

const root = ownedWorkspace(requestedRoot, true);
const configPath = join(root, 'config.json');
const extension = join(root, 'extension');
if (existsSync(configPath)) throw Error('This workspace is already configured. Use ' + configPath);

for (const [name, expected] of files) {
  const target = childPath(extension, name);
  mkdirSync(dirname(target), { recursive: true });
  if (!existsSync(target)) copyFileSync(childPath(source, name), target, constants.COPYFILE_EXCL);
  if (sha256(target) !== expected.toLowerCase()) throw Error('Owned extension file hash mismatch: ' + name);
}

const config = {
  format: FORMAT,
  workspace: root,
  browser: 'edge',
  executable,
  nodeExecutable: process.execPath,
  extensionFiles: fingerprints,
  extraOrigins: [],
  headless: false,
};
writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ configPath, extension, headless: config.headless }, null, 2));
