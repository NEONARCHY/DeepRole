import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {ownedWorkspace,acquireOwner} from './isolation.mjs';

// Adapted from the user's codex pet browser-driver: private inherited pipes,
// one process we own, no TCP listener or attachment to an existing browser.
export function braveExecutable(){
 return [process.env.PROGRAMFILES,process.env['PROGRAMFILES(X86)'],process.env.LOCALAPPDATA].filter(Boolean).map(p=>join(p,'BraveSoftware','Brave-Browser','Application','brave.exe')).find(existsSync)||'';
}
export function browserExecutable(browser='brave'){
 if(browser==='brave')return braveExecutable();if(browser!=='edge')throw Error('Unsupported browser');
 return [process.env.PROGRAMFILES,process.env['PROGRAMFILES(X86)'],process.env.LOCALAPPDATA].filter(Boolean).map(p=>join(p,'Microsoft','Edge','Application','msedge.exe')).find(existsSync)||'';
}
export function browserArgs(root,headless=true){if(typeof headless!=='boolean')throw Error('headless must be a boolean');return ['--user-data-dir='+join(root,'profile'),'--no-first-run','--no-default-browser-check','--window-size=1100,850','--remote-debugging-pipe',...headless?['--headless=new']:[],'--load-extension='+join(root,'extension'),'about:blank'];}
export function manualArgs(root){return ['--user-data-dir='+join(root,'profile'),'--no-first-run','--no-default-browser-check','--disable-background-mode','--window-size=1100,850','--load-extension='+join(root,'extension'),'https://chat.deepseek.com/'];}
export class PrivateBrowserDriver{
 #child;#manual=false;#starting;#pending=new Map();#sessions=new Map();#next=0;#release;#spawn;#timeout;#headless;
 mode='stopped';
 constructor(root,{executable=braveExecutable(),spawnProcess=spawn,timeout=15000,headless=true}={}){if(typeof headless!=='boolean')throw Error('headless must be a boolean');this.root=ownedWorkspace(root);this.executable=executable;this.#spawn=spawnProcess;this.#timeout=timeout;this.#headless=headless;}
 async start(){
  if(this.#starting)await this.#starting;
  if(this.#child){if(this.#manual)throw Error('Close the separate manual browser window before resuming automation');return;}
  this.#starting=(async()=>{
   ownedWorkspace(this.root);if(!this.executable||!existsSync(this.executable))throw Error('Browser executable is missing');this.#release=acquireOwner(this.root);
   let child;try{child=this.#spawn(this.executable,browserArgs(this.root,this.#headless),{windowsHide:this.#headless,stdio:['ignore','ignore','ignore','pipe','pipe']});}catch(error){this.#release();this.#release=undefined;throw error;}
   this.#child=child;this.#manual=false;this.mode='background';if(child.pid)this.#release.trackBrowser(child.pid);let buffer='';
   child.stdio[4].setEncoding('utf8');child.stdio[4].on('data',chunk=>{
    buffer+=chunk;if(buffer.length>24*1024*1024){child.kill();return;}
    let end;while((end=buffer.indexOf('\0'))>=0){const part=buffer.slice(0,end);buffer=buffer.slice(end+1);let message;try{message=JSON.parse(part);}catch{continue;}
     const pending=this.#pending.get(message.id);if(!pending)continue;this.#pending.delete(message.id);clearTimeout(pending.timer);
     message.error?pending.reject(Error(String(message.error.message))):pending.resolve(message.result);
    }
   });
   const ended=()=>{if(this.#child!==child)return;this.#child=undefined;this.mode='stopped';this.#sessions.clear();for(const p of this.#pending.values()){clearTimeout(p.timer);p.reject(Error('Owned browser closed; action outcome may be unknown. Do not repeat automatically'));}this.#pending.clear();const release=this.#release;this.#release=undefined;release?.();};
   child.once('exit',ended);child.once('error',ended);
   try{await this.command('Browser.getVersion');}catch(error){await this.close();throw error;}
  })().finally(()=>{this.#starting=undefined;});return this.#starting;
 }
 async openManualLogin(){
  if(this.#child)throw Error('Close the owned automated browser before manual login');
  ownedWorkspace(this.root);if(!this.executable||!existsSync(this.executable))throw Error('Browser executable is missing');this.#release=acquireOwner(this.root);
  let child;try{child=this.#spawn(this.executable,manualArgs(this.root),{windowsHide:false,stdio:['ignore','ignore','ignore']});}catch(error){this.#release();this.#release=undefined;throw error;}
  this.#child=child;this.#manual=true;this.mode='login';if(child.pid)this.#release.trackBrowser(child.pid);
  const ended=()=>{if(this.#child!==child)return;this.#child=undefined;this.#manual=false;this.mode='stopped';const release=this.#release;this.#release=undefined;release?.();};
  child.once('exit',ended);child.once('error',ended);
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});
  return{manualLoginRequired:true,automationConnected:false,closeWindowBeforeResume:true};
 }
 command(method,params={},sessionId){
  if(this.#manual)return Promise.reject(Error('No automation connection exists during manual login'));
  const pipe=this.#child?.stdio[3];if(!pipe||pipe.destroyed)return Promise.reject(Error('Owned browser is not connected'));
  const id=++this.#next;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.#pending.delete(id);reject(Error('Browser did not confirm the action; inspect before retrying'));},this.#timeout);this.#pending.set(id,{resolve,reject,timer});pipe.write(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}})+'\0',error=>{if(error){const p=this.#pending.get(id);if(p){this.#pending.delete(id);clearTimeout(p.timer);reject(error);}}});});
 }
 async targets(){return(await this.command('Target.getTargets')).targetInfos;}
 async page(targetId,method,params={}){let session=this.#sessions.get(targetId);if(!session){session=(await this.command('Target.attachToTarget',{targetId,flatten:true})).sessionId;this.#sessions.set(targetId,session);}return this.command(method,params,session);}
 async read(targetId,expression){const r=await this.page(targetId,'Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error('Page operation failed; inspect fresh state before retrying');return r.result?.value;}
 async close(){
  const child=this.#child;if(!child)return;
  if(this.#manual)throw Error('Close the separate manual browser window yourself; it will not be killed or controlled');
  await this.command('Browser.close').catch(()=>{});
  if(child.exitCode===null)await Promise.race([new Promise(r=>child.once('exit',r)),new Promise(r=>setTimeout(r,1800))]);
  if(child.exitCode===null)child.kill();
  if(this.#child===child){this.#child=undefined;this.mode='stopped';this.#sessions.clear();const release=this.#release;this.#release=undefined;release?.();}
 }
}
