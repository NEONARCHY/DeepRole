import type { DeepRoleSettings } from "./types";
import { DEFAULT_PORTRAIT_MAX_EDGE, DEFAULT_PORTRAIT_PREVIEW_SIZE } from "./portrait-upload";
import { DEFAULT_ACTIONS } from "./character-actions";

export const DEFAULT_SETTINGS: DeepRoleSettings = {
  strictMemorySending: false,
  automaticMetadataRepair: false,
  portraitMaxEdge: DEFAULT_PORTRAIT_MAX_EDGE,
  portraitPreviewSize: DEFAULT_PORTRAIT_PREVIEW_SIZE,
  referencePreviewSize: DEFAULT_PORTRAIT_PREVIEW_SIZE,
  showDeepSeekReasoning: false,
  replyRecoveryEnabled: true,
  contextWarningsEnabled: true,
  chatContextCapacity: 1_000_000,
  locale:
    typeof navigator !== "undefined" && navigator.language.toLowerCase().startsWith("ru")
      ? "ru"
      : "en",
  onboardingComplete: false,
  characterSheetsEnabled: true,
  relationshipsEnabled: true,
  relationshipDisplay: "both",
  characterSpritesEnabled: true,
  portraitLayoutResetAt: 0,
  characterActions: [...DEFAULT_ACTIONS],
  sceneChoicesEnabled: true,
  pinSceneChoices: false,
  pinPortraitLeft: false,
  pinPortraitRight: false,
  adaptiveLayout: true,
  floatingPanelWidth: 224,
  showChatContextMeter: true,
  showMemoryContextIndicator: true,
  contextBudget: 2000,
  relevanceThreshold: 6,
  suggestionInterval: 20,
  suggestionsEnabled: true,
  recentMessageCount: 4,
  animationsEnabled: true,
  confirmDeletions: true,
};

export const BOOK_COLORS = [
  "#58a6ff",
  "#8b7cff",
  "#31c7a1",
  "#f1a65a",
  "#e975a8",
  "#8ea1b5",
];

export const APP_VERSION = "0.1.0";
