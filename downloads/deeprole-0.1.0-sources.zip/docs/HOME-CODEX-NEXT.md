# Codex на другом ПК: откуда продолжать после pull

## Актуальная передача — RP308, 16 октября 2026

Последняя правка: эмоция в узком списке на отдельной строке; первые два показателя
портретов показываются при hover/focus, touch без hover сохраняет их видимость.
Данные и генерация не менялись. См. верх CODEX-HANDOFF/ROADMAP; установленная копия
сама не обновляется. Дальнейшие живые проверки из RP307 остаются открытыми.

## Предыдущая передача — RP307, 16 октября 2026

Пользователь попросил заранее учитывать модельные лимиты Venice при подготовке
плана картинки. Читай верх CODEX-HANDOFF/ROADMAP и IMAGE-MODEL-BUDGETS.md.
PromptComposition даёт model IDs и measured fixed costs; сохранённые identities,
style и состав не обрезаются. Unknown mode cap не заимствует cap другого режима.
87unit/tsc0,2native budget pass; первые E2E fixtures оказались устаревшими, review
повторён на RP306 и тоже fail. Final12E2E pass/4Firefox Edge-only skip,0fail/flaky;
fixtures обновлены для isolated workers и полной гидратации photo-store bytes.
Обе сборки/архивы обновлены, final byte/CRC check. Установленная пользовательская
копия остаётся RP306, новый ZIP требует отдельного обновления. Детали/QA сверху handoff.
После задачи вернуться к off-scene/live хвосту RP306. Push не запрошен.

## Актуальная передача — RP306, 16 октября 2026

Начни с текущего CODEX-HANDOFF и LIVE-QA-2026-10-16. Prefix после reload исправлен
в injected-user-text/story-continuation/deepseek-handoff-dom/story-history-dom.
Пользователь обновил установленную копию, повторный reload успешен. Реальные OOC
условия и manual choices проверены. Второй перенос открыл125a5a3d; финальная
проверка прошла: после reload оба предмета у Алекса/unsigned receipt/два open;
сам native handoff request содержит6чистых turns. Личные миры не менять,
исходные тестовые чаты не удалять.

Дополнительно перенесена «Предложить варианты» в toolbar рядом с иллюстрацией,
через slot, без изменения wire/state/signature. Эта правка ПОСЛЕ последнего
пользовательского обновления; затем пользователь обновил ЕЩЁ РАЗ и live toolbar
проверен:40px/одинаковые стили/8px, Enter запустил запрос и появились4варианта.
Final130unit/126E2E,tsc/diff0; первый77pass/25fail разобран в RP306 описании,
не скрыт. Пакеты Chrome/Firefox/source23/23/917 CRC/bytes/canonicalSHA verified,
итоговые docs включены в source. Следом off-scene coverage и оставшиеся
доступные live случаи; глобальный RP05 открыт. Push не запрошен.

## Актуальная передача — RP305, 16 октября 2026

Начни с верхних CODEX-HANDOFF/ROADMAP и CONTINUATION-FIRST-SEND-REPAIR.md.
RP304 сохранён. Реальная проверка нашла потерю сжимки при первом запросе нового
чата: native адрес создаётся до POST. Исправлены content.tsx/continuation-flow.ts,
временный exact target для контекста без ранней активации. Новый pre-fix тест
упал; post-fix chain18/18, unit38/38, UI+recap18pass/2Firefoxskip, tsc/diff0.
После ручного обновления пользователем реальный automatic Continue прошёл до
target9a68d51d «Архивное утро»: мир/3 персонажа/reload/точные владельцы и оба
незавершённых обещания/old-chat notice. FirstFAIL не скрыты, см. LIVE-QA-2026-10-16.

Следующая конкретная задача: видимый raw character prefix после reload и его
попадание в recent scenes вместо текста user action. Затем проверка off-scene
анкеты по вопросу о её предмете. Не повторять закрытый RP304 corpus repair и не
объявлять весь RP05/live suite завершённым. Menu srcdoc limitation/reset/cast/
export/images требуют других live проверок. Личный мир не менять. Push не запрошен.

## Актуальная передача — RP304, 16 октября 2026

Начни с верхних CODEX-HANDOFF/ROADMAP и `docs/RELAY-REPAIR.md`.
Прежняя задача исправления RP303 выполнена: целевой SEEN 40/40, 204/204 записей,
0 missing/integrity/guard gaps/lost prior. Первый результат 25/40 сохранён.

- Runtime: story-obligation-recall.ts/game-context.ts. Распознаются ограниченные
  conversational readiness, anaphora и first/then action-plus-recall запросы.
  Условия и источники берутся из принятых записей, не из утверждений игрока.
- Короткая ссылка требует exact accepted latest-turn quote. Raw-only и unknown
  tail не создают связь. Исходный ambiguous-name guard и исторические роли
  сохраняются при передаче нескольких кандидатов.
- Нет owner/identity/permission/completion inference, canonical writes или
  повышения caps. Старое cancelled и новое open поручения остаются раздельными.
  Opt-outs и exact source/budget fallback проверяются.
- RP303 input/gold/fixture/protocol/runner/report/seal неизменны; RP302 snapshots
  до правок сверены с 414 hashes. Исторические RP302 tests теперь проверяют
  снимки, новые `story-relay-seen-report.test.ts` — текущий runtime.
- Runner: `scripts/story-search-relay-seen.mjs`, отчёты `rp304-*-seen-results.json`,
  итоговая QA: `docs/benchmarks/rp304-qa-results.json`.
- Все девять корпусов:650 входов/388 scored/1826 gold,388/388 полных,
  0 missing/integrity/guard gaps/lost prior. Controls и budget не считаются
  полноценными пройденными историями.

**Следующий шаг:** новая независимая preregistered проверка другими текстами.
Все нынешние девять корпусов — известные; не называть их повтор слепым.
General semantics, RP-05 и true cross-turn delta ещё открыты. Не начинать заново
RP303 repair. Личные миры/installed copy не менялись; live DeepSeek не запускался.
Push этой итерации не запрошен. Source ZIP без tests/private-assets, нужен Git checkout.
Ниже RP303 и раньше — история.

RP304 full unit:8600 pass/0 fail/5 прежних TODO; финальные62repair/report/first
checks прошли отдельно. TypeScript/diff0,Chrome/Firefox собраны. Первый concurrent
strict:491pass/1timeout в storage test на100порций (30s), попытка сохранена.
Изолированный повтор прошёл с прежним timeout и тем же runtime. На этой машине
запускать strict после full/corpus нагрузок; исходные сведения:rp304 QA report.

Финальный strict без внешних тяжёлых прогонов:492pass/0fail,2427pairs57configs.
Первый timeout сохранён; runtime и исходный automation test/timeout не менялись.
Packages23Chrome/23Firefox/910sources entries: CRC/bytes/canonical SHA verified.
Source ZIP без tests/private-assets. При4200tokens новый корпус8/8RU/EN по двум
сюжетам; при1000 —неполон сbudgetstatus. Native/live/installedcopy не проверялись.

## Актуальная передача — RP303, 16 октября 2026

Начни здесь ивверхних CODEX-HANDOFF/ROADMAP; детали `docs/RELAY-RESULTS.md`.
Свежая независимая проверка уже выполнена на неизменённом RP302. Не запускать
вновь --freeze/--evaluate поверх первых файлов и не называть повтор независимым.

- Два новых авторских сюжета: winter refuge/regatta в RU/EN. 64 inputs/40 scored/
  204gold/16controls/8budget/24uncertainty.414hashes/input/gold/ownrunner/protocol
  frozen ДО первогоcompiler-run. Переводы ипараметризованный фон коррелированы.
- Первый результат: 25/40, 181/204 records, 23 missing в 15 queries, 12 guard gaps,
  0integrity/false-complete. Прямые,partial-condition,negative,revoked,replacement
  полны. Разговорные перефразировки/новаяанафора/first-then sequences неполны.
- Guard отсутствует в 4 paraphrase, 4 accepted-reference, 4 raw-only; coverage unverified
  сохраняется. Не смешивать это с12ошибками интерфейса илиложнымcomplete.
- First baseline `tests/fixtures/story-relay-audit-baseline.json`, fixture
  `story-relay-audit.ts`,runner `scripts/story-search-relay-audit.mjs`,protocol
  `docs/RELAY-EVALUATION.md`,report/seal `docs/benchmarks/rp303-*.json` неизменяемы.
- Точные mutable runtime snapshots уже есть: `rp302-final-game-context.txt` и
  `rp302-final-obligation.txt`;сверяются с414hashes. При правке другихфайлов
  сохранить их исходныеверсии тоже. Тест `story-relay-audit.test.ts` pin-итfirstscore.

**Следующая задача:** воспроизвести15recall cases/12guards, исправить без owner/
permission/completion inference и capincrease. Отдельный SEEN RP303 +8старых
наборовRP302. Не менятьgold чтобы получитьзелёныйрезультат. RP-05/semantics/
true delta открыты. Личные миры/installedcopy unchanged,неliveDeepSeek;
push этойитерации не запрошен. QA:`docs/benchmarks/rp303-qa-results.json`.
Для воспроизведения нужен Git checkout:sourceZIP excludes tests/private-assets.
Ниже RP302ираньше — история, их прежний следующий freshaudit уже выполнен.

RP303 QA: 21 audit/prior-report test + 492 unified strict checks, 0 fail;
финальные 7 first-result checks повторены. TypeScript/diff 0. Chrome/Firefox
ZIP: 23/23/896 entries, CRC/bytes/canonical SHA проверены. Full unit/native/live
не повторяли: runtime/UI прежние. Первые 25/40 и 12 guard gaps остаются открытыми.

## Актуальная передача — RP302, 16 октября 2026

Начни с верхнего CODEX-HANDOFF, ROADMAP и `docs/EMBARGO-REPAIR.md`.
Ниже RP301/RP300 — история, их старые следующие задачи уже выполнены.

- Исправлены10 неполных RP301 входов и2 пропуска guard: целевой SEEN24/24,
  114/114 записей,0 missing/integrity/guard gaps/lost prior.
- Вопрос о готовности к публикации подбирает целые группы условий/места/статуса
  и сохраняет uncertainty. Publication/display compound подбирает именованный
  материал по повторённому принятому title/text/quote, не по одному говорящему.
- Runtime:2файла story-obligation-recall.ts/game-context.ts. Caps/rollback/optouts
  прежние, нет записи канона или вывода согласия/завершения/владельца. Общий alias
  не разрешается: исходный guard остаётся при подборе отдельных кандидатов.
- До исправления сохранены RP300 runtime snapshots по414 RP301 hashes.
  Frozen first14/24/input/gold/fixture/protocol/runner/report/seal не переписаны.
- SEEN runner:`scripts/story-search-embargo-seen.mjs`; текущая QA:
  `docs/benchmarks/rp302-qa-results.json`; отчёты`rp302-*-seen-results.json`.
- Все8наборов:586inputs/348scored/1622gold,348/348 complete,0missing/integrity/
  guard gaps/lost prior. Controls/budget отдельно; не586пройденныхисторий.
  Новые48repair/report/seal checks прошли; первые результаты сохранены.

**Дальше:** новый независимый preregistered сюжет с gold до первого compiler-run,
затем отдельный первый неизменяемый результат. Все нынешние8корпусов — известные.
General semantics/RP-05/true delta не закрыты. Не начинать снова RP301 repair.
Личные миры/installed extension unchanged, live DeepSeek не проверялся; push в
этой итерации не запрошен. Для тестов нужен Git checkout, sourceZIP excludes tests.

Финальные проверки RP302:fullunit8534pass/0fail/5existingTODO,309files;48final
repair/report/seal checks отдельно;unifiedstrict492pass/2427pairs57configs;
TypeScript/diff0. ZIPs23Chrome/23Firefox/888source entries,CRC/bytes/canonicalSHA
verified. Старый chunkwarning остаётся. Budget3000/6000=7/7RUEN;900=1/7RU,
2/7EN сbudgetstatus — не обещать полную память при900tokens. Браузерныйnative
иliveDeepSeek вэтойитерации не запускались. Для сборки наэтомWindows использованы
TEMP/TMP `.output/rp302-build-tmp`, исключая прежнийuserTEMP/esbuild access-denied.

## Актуальная передача — RP301, 16 октября 2026

Новое независимое измерение уже выполнено на неизменённом RP300. Сначала читать
`docs/EMBARGO-RESULTS.md` и верх CODEX-HANDOFF/ROADMAP. Ниже RP300 — история.

- До первого запуска заморожены входы/ручной gold/протокол/runner/414 хешей:
  `tests/fixtures/story-embargo-audit-baseline.json`.
- Первый итог: 40 входов, 24 scored, 114 expected records; **14/24 полных,
  102/114 записей**, 12 пропусков в 10 входах, 2 guard gaps, 0 integrity и
  false-complete. 10 негативных контролей пройдены. 6 budget — отдельные наблюдения.
- `ru/en:paraphrase`: нет a2/a3 и guard. `ru/en:compound` и шесть `scale`:
  отсутствует c1. Это уточнение «сжатие фото не заменяет согласия»; отмена и
  запрет сохранены. Вопрос/убеждение не подтверждают разрешение.
- Результаты и seals: `docs/benchmarks/rp301-embargo-results.json`,
  `rp301-first-report-seal.json`. Не менять их, fixture, protocol или runner.

**Следующая работа:** перед runtime-правкой сохранить точные RP300 snapshots
по baseline-хешам, воспроизвести эти пропуски, затем source-bound исправление
отдельным SEEN плюс семь прежних rp300a наборов. Не увеличивать cap и не
подменять неподтверждённую ссылку уверенностью. Новый корпус уже известен.
RP-05 не закрыт, general semantic recall и true cross-turn delta не решены.
QA: `docs/benchmarks/rp301-qa-results.json`. Live DeepSeek/installed copy не
проверялись, личные миры не менялись. Push этой итерации не запрошен.

Проверки этой итерации:46 audit/prior-seal tests +492 unified strict,0fail,
TypeScript/diff0; финальные4 seal checks повторены. Chrome/Firefox пересобраны,
три canonical ZIP:23/23/874 entries,CRC/bytes/SHA проверены. Fullunit и native
браузер не повторялись. Первый Chrome build был заблокирован Windows TEMP;
повтор с `.output/rp301-build-tmp` через TEMP/TMP успешен. SourceZIP без tests:
для воспроизведения нужен Git checkout.

## Актуальная передача — RP300, 16 октября 2026

Начинай здесь, затем прочитай верхние разделы `CODEX-HANDOFF.md`, `ROADMAP.md` и дневник `docs/HANDOFF-2026-10-16.md`. Разделы ниже исторические: не возобновляй старые задачи RP289/RP292, уже исправленные позже. Пользователь попросил отправить весь накопленный результат RP289–RP300 на GitHub и передать работу другому Codex.

### Что уже сделано

- Условия обещаний подбираются полными группами подтверждённых записей: кто обещал, доступ, место, подготовка, незавершённость, отмена и запреты. Упаковка или просушка не означают выполнение.
- Похожие названия предметов и общие короткие имена не дают права объединять владельцев или обязательства. Завершённая задача другого персонажа не закрывает текущую.
- Вопрос пользователя не считается доказательством, что названный предмет или обещание существуют. Добавлены предупреждения при неподтверждённой связи; сомнительные кандидаты не становятся новым каноном.
- Расширены поддерживаемые вопросы о доставке/ремонте/договорённости, короткие ссылки и составные действия с просьбой напомнить условия. Поддержаны принятые заголовки «если/когда/после», «пока…не», «без разрешения…не», unless/without. Это ограниченный буквальный поиск, не универсальная семантика.
- Добавлен единый `npm run test:memory -- --strict-recall`: комбинации настроек и длительные пути хранения. Он не заменяет независимые новые сюжетные проверки.
- Новые независимые замеры RP289/RP292/RP295/RP297/RP299 выявляли реальные пропуски; их исправления имеют отдельные SEEN-отчёты. Первые результаты и ручные ожидания сохранены, не переименованы в успешные.

Пример последнего исправления: «Пока вода не уйдёт и завхоз не выдаст пропуск, плащ не понесу». Поддерживаемый вопрос «с той серебристой одеждой уже разобрались?» теперь подтягивает условие, пропуск, новое место и отсутствие передачи. Расширение не решает за модель, что вода уже ушла или пропуск получен.

### Точная проверенная точка

Последний первый аудит RP299:15/22,11 пропущенных записей в7 вопросах,5 пропусков guard. После RP300:22/22 и100/100 записей. Итоговые **семь SEEN-наборов `rp300a-*`:324/324 оцениваемых случаев,1508/1508 записей**,0 нарушений источников/guard gaps/потери ранее выбранных фактов. Всего546 входов, включая контрольные и бюджетные; не называй их546 полноценно пройденными сюжетами.

Full unit8501 pass,0fail,5 прежних TODO,307 файлов; unified492 checks,2427 пар в57 конфигурациях,60/60 recall; TypeScript0. Два изолированных synthetic Edge теста прошли; окна закрыты. Chrome/Firefox собраны. Итоговые отчёты: `docs/benchmarks/rp300-qa-results.json`, `rp300a-*-seen-results.json`, `rp300-native.json`. Сборки и три canonical ZIP находятся в `downloads/`. Установленная копия отдельно не перезагружалась.

Первый частичный SEEN-прогон `rp300-*` прервался из-за Vite watcher/EBUSY временных Cookies параллельного браузера. Пять отчётов и исходный runner сохранены; итоговый повтор `rp300a-*` использует `watch:null`. Это исправление тестового инструмента, не изменение игровой логики. Проверки живого DeepSeek и качества ответа модели на новом театральном сюжете не проводились.

### Что делать дальше

1. Подготовить действительно новые сюжеты и формулировки с ручными ожиданиями **до первого запуска**. Не ограничиваться очередным переименованием плаща и фонаря; проверить другие виды условий/обязательств и неоднозначные ссылки.
2. Зафиксировать входы, gold, собственный runner/протокол и текущий runtime. Сделать первый неизменяемый замер. Новый корпус после этого считается известным, не слепым.
3. Если найдены пропуски — воспроизвести, сохранить точные runtime-снимки перед исправлением, затем отдельный SEEN-замер плюс регрессия семи нынешних наборов. Не подгонять первые ожидания под реализацию.
4. После стабилизации возвращаться к открытым задачам RP-05/общей семантики и настоящей межходовой дельты передачи памяти. Они **не закрыты** этими тестами. Не обещать пользователю универсальную память, любые тексты или бесконечный нативный контекст DeepSeek.
5. Для живой проверки пользователь должен обновить установленную копию расширения и страницу DeepSeek; архив не делает этого автоматически. Не трогать личный мир, историю и аккаунт без отдельной необходимости/разрешения.

### Команды и ограничения

Работать из корня актуального checkout, не из родительской старой копии BDS. После pull проверить `git status`, не стирать чужие изменения. Для тестов нужен Git checkout: source ZIP исключает `tests/` и `private-assets/`.

```sh
npm run typecheck
npm run test:memory -- --strict-recall
npm test -- --maxWorkers=2
npx playwright test tests/e2e/story-obligation-runtime.spec.ts --project=chromium --workers=1
```

Не перезапускать audit с `--freeze`/`--evaluate` поверх уже сохранённых первых отчётов; не перезаписывать SEEN-отчёты. Их скрипты создают новые результаты через wx/суффикс попытки. Для тестовых Vite runner отключать filesystem watch; браузерный TEMP держать вне наблюдаемых деревьев. При Windows esbuild TEMP access-denied сборку можно направить в отдельную временную папку.

Не повышать лимиты ради зелёного теста и не обрезать цитаты. При900-токенном бюджете часть памяти всё ещё не помещается. Сохранять условия, роли, владельцев, отменённые разрешения, whole-group rollback и пользовательские правки. Проверки retrieval не доказывают автоматическое извлечение событий. После каждой итерации обновлять roadmap/передачу, писать пользователю кратко по-русски с примером.

### История ниже — справочная, не текущая очередь

## RP292 — первый новый audit:39/60,следом условия и свободные ссылки

Новые истории RU/EN: дирижабль, караван и типография,до6500фоновыхзаписей.96inputs:60scored/30controls/6budget. Первый39/60,264/306gold;42missing в21case:paraphrase9records,same-label10,free-reference11,composite12.0integrity/falsecomplete;42UIunverified,36guard/6gaps толькоfree-reference. Namedhandover/replacement/twojobs/cancel/consent/scale полны. [Результаты](CROSS-OWNER-RESULTS.md), [protocol](CROSS-OWNER-EVALUATION.md), [firstreport](benchmarks/rp292-cross-owner-results.json). RuntimeRP291неизменён,414frozenfingerprints/firstseals/oldreports прежние. QA1056/1056checks в11files,100новых;TypeScript/diff-check0.3ZIP23/23/771entries/canonicalSHA256checked,notesупакованы. Fullunit/native/live не повторялись:код/UI прежние. Syntheticacceptedmemory,неlive/externalblindproof;новые кейсы теперьseen. [QA](benchmarks/rp292-qa-results.json).

Перваязадача:repro21losses+6free-referenceguards,неповторновыполнятьRP291wrong-owner12cases. Same-labelliteralнеobjectID:сохранитьобегруппыA/B,разныероли/taskkeys/доступ/отмену. Проверитьпределproseverbs handover/replace,нонеугадыватьпричинувсехпотерь. БудущийfixтолькоseparateseenсрегрессомRP289/RP287/RP283;first39/60/gold/report/sealнепереписывать. RP-05/general semantics/true delta открыты,личныймир/installedcopyпрежние,pushнезапрошен.

## RP291 — владелец/предмет из вопроса не считаются фактом

12guard gaps закрыты metered premise warning отдельно от retrieval/reference logic. Ни owner/object identity,ни новыйканон,нискрытый synonym mapping не создаются. Поддержаны finite RUEN вопросы;bare role questions/opt-out/restart/reference-only прежние. Все288 прежних selectedIds/порядок иcoverage совпали,только23/1/2outputs RP289/RP287/RP283 изменились предупреждением. Всеgold54/54,62/62,54/54 иquotes/roles/status/revisions целы;42RP289unresolved guarded/unverified,0gaps. [Контракт/пример](OBLIGATION-PREMISES.md). Fullunit7720pass/0fail/5TODO,297files,27runtime+3reportnew;TypeScript/diff-check0. Isolated Edge4/4pass/0fail/0flaky,181.81s,102localPOST,contextsclosed.3ZIP23/23/765entries/canonicalSHA256checked,notesупакованы;live model/nativeFirefox/fullE2Eнепроверены,installedcopy прежняя. [QA](benchmarks/rp291-qa-results.json).

Следующее:новый preregistered independent audit на других сюжетах/формулировках. First reports/gold/seals/RP290b/RP291seen не переписывать;2RP290snapshots фиксируют его runtime. Личныймир/installedcopy прежние,push не запрошен. General semantics/RP-05/true delta открыты.

## RP290 — доставка и короткие обещания

Исправлены2runtime files по найденным11 потерям RP289. Delivery/repair prose tasks и shipping inquiry получают whole source-backed conditions,EN known-name possessive не часть label. Reference candidate cap4 считается после accepted-scene scope:иначе старые посторонние обещания блокировали новый сюжет. Scan16tasks/128rows/whole-budget/неоднозначность/исторические роли и неизменность канона сохранены. Final seen RP28954/54,204/204,0loss/integrity;RP28762/62,RP28354/54,все192outputs прежние. Fullunit7690pass/0fail/5TODO,45runtime+3reportnew;TypeScript/diff-check0. Native Edge4/4pass/0fail/0flaky,133.25s,90localPOST.3ZIP23/23/757entries/canonicalSHA256 проверены,notes упакованы. Live model/nativeFirefox/fullE2E не проверены,installedcopy прежняя. [Контракт/пример](MIXED-OBLIGATION-REPAIR.md), [QA](benchmarks/rp290-qa-results.json).

Final reports — `rp290b-*`;rp290/rp290a предварительные сохранены,первый native2pass/2fail выявил настоящий scope bug. First RP289/RP287/RP283 gold/report/seals не менять. Следующее:12explicit guard gaps swapped-owner/invented-object,затем новый независимый frozen audit;RP-05/general semantics/true delta открыты. Личный лор/installedcopy прежние,push не запрошен.

## Текущий этап RP289 Новые типы обязательств проверены

Первый новый audit на неизменённом RP288:96inputs/3новыхplots/RUEN/до6000scenes,54scored43complete,187/204gold,17missing в11cases. Все6paraphrases и5proved-reference теряют access/destination/preparation evidence;named delivery/repair/two-jobs/payment/cancelled/secrecy/scale полны.0integrity/false-complete,42/42UIunverified и12missingexplicitguards(swapped owner/invented object). [Результаты](MIXED-OBLIGATION-RESULTS.md), [protocol](MIXED-OBLIGATION-EVALUATION.md), [первыйreport](benchmarks/rp289-mixed-obligation-results.json). Будущий fix оценивается только как seen на этих данных.

Runtime/UI/storage/settings/model и old reports/seals не менялись. Initial preflight self-runner-path metadata issue исправлен ДО первого compiler новымv2manifest;исходныйmanifest/snapshot/input/gold сохранены,414fingerprints. QA:1068/1068tests в12files,100новых;TypeScript/diff-check0.3ZIP пересобраны,финальная проверка содержимого — CODEX-HANDOFF. Fullunit/native/live не запускались:runtime/UI прежние. Личный лор/аккаунт не использовали,push не запрошен.

Дальше:прочитать фактические11 missing cases,доказать причину a1 по exact delivery bridge и paraphrase a1/a2/a3,отдельно12guard gaps;не переименовывать первый43/54 в зелёный. Fix в следующей итерации с отдельным seen report и старыми RP283/RP287 tests,после него новый независимый корпус. Минимум действий игрока/whole sources/условия/source roles/canon/ambiguity/budget safeguards обязательны. General semantics/RP-05/true cross-turn delta пока открыты.

## Выпуск RP274–RP288: публикация в main

Выпуск публикуется через [PR #2](https://github.com/NEONARCHY/DeepRole/pull/2) из `codex/rp274-rp288-memory-safety` по запросу пользователя;актуальный статус слияния доступен в PR. После обновления `main` начинать с RP288 ниже: новые независимые истории/формулировки и обязательства,сначала protocol/input/gold/runtime freeze,затем замер. Фиксы коротких ссылок уже готовы,7542unit pass/0fail/5TODO и10/10 synthetic Edge подтверждены;RP-05 остаётся открытым. Исторические «push не запрошен» ниже относятся к прежним этапам.

## Текущий этап RP288 — исправления коротких ссылок готовы

`game-context.ts` добавляет guard до всех passes и сохраняет unverified при fallback/успешном literal match;guard учтён в required/whole budget. `story-obligation-recall.ts`:source-proved longest prefix на том же span,не отдельная новая сущность из общих прилагательных. Exact accepted text/quote/source/roles нужны по-прежнему;другое самостоятельное вхождение блокирует narrowing. [Примеры/границы](SHORT-REFERENCE-SAFETY.md).

Seen RP287 **62/62,250/250,0missing/integrity/confidence gaps,48/48 guard+unverified**.26outputs/7coverage changes;lostPrior2 толькоENtheatre c1/c2 про посторонний жилет,канон не удалён.82others/6budget прежние. Seen RP28354/54,312/312,0loss/rejection drift;1reference output изменён,83others/allcoverage прежние. [RP287 report](benchmarks/rp288-rp287-reference-seen-results.json), [RP283 report](benchmarks/rp288-rp283-reference-seen-results.json). First58/62 и39/54/seals/gold/input неизменны;это seen,не independent/live proof.

RP288:full unit7542pass/0fail/5 прежнихTODO из7547,74 новых checks;ранние260+71pass. TypeScript/diff-check0. Native isolated synthetic Edge10/10pass/0fail/0flaky за166.02s:expanded obligation2+contextual2+recap2+UI4(RUEN320/900,keyboard/axe/no overflow);новые scope/roles/quotes/retry503/fetch/XHR/reload/raw-only fallback,46POST. Первыйnative8pass/2test-fixture ID errors сохранён;mock helper исправлен поreadyevent,assertions не ослаблены. Frozen inputs/gold/protocol/firstseals прежние;412/414 fingerprints unchanged,2expected runtime edits. Chrome/Firefox build+ZIP0,старый>500KB warning. Live DeepSeek/nativeFirefox/fullE2E не проверялись,installed copy не обновлялась. 23/23 runtime и735 source entries проверены byte/CRC;3 canonical download copies SHA256 match,финальные notes повторно упакованы. Source ZIP исключает tests;для QA нужен Git checkout/Node22.

**Следующее после QA:** новый independent preregistered audit с новыми сюжетами,разными самостоятельными вхождениями общих названий,свободными ссылками/другими обязательствами. Сначала gold/input/runtime freeze,затем evaluation,без редактирования первого результата. RP-05/общий semantic поиск/любые местоимения/true delta открыты. RP274–288 local atop7005aa6,push не запрошен;личный мир/installed copy прежние. [QA](benchmarks/rp288-qa-results.json).

## Текущий этап RP287 — новый audit завершён, дальше короткие ссылки

108 frozen inputs на неизменённом RP286:4 новых сюжета/RUEN/до5000background scenes,62scored/40controls/6budget. **58/62,244/250records,6missing в4 proved-reference cases**;0 source/role/status/budget/input/cache integrity issues.23/48 unresolved inputs без guard;7 изних complete вместо unverified(1 scored ENradio+6controls). [Результат/примеры](OBLIGATION-HOLDOUT-RESULTS.md), [протокол](OBLIGATION-HOLDOUT-EVALUATION.md), [report](benchmarks/rp287-obligation-holdout-results.json), [seal](benchmarks/rp287-first-report-seal.json), [QA](benchmarks/rp287-qa-results.json).

**Первая задача после pull:** диагностировать short-reference fallback в game-context: при отказе matcher сохранять unverified+guard. Затем source-group losses RUEN garden a1,ENradio a1/a2/a3,ENregatta a1. Причина пропусков ещё не доказана. Не угадывать owner по общему label, не объединять task IDs. Будущий fix отдельным seen report на108 inputs+прежних RP283; **не править first fixture/gold/protocol/manifest/report/seal**. После fixes новый independent набор. RP-05/general semantics/true delta открыты. Synthetic agent-authored accepted-memory audit,не blind external/live DeepSeek;общий шаблон/переводы/фон. RP274–287 local atop7005aa6,push не запрошен,личный лор/installed copy не менялись.

RP287:focused278/278(111новых checks),TypeScript/diff-check0;новый audit108inputs/62scored58complete сохранён. Все414 frozen fingerprints,включая410 runtime,прежние;старые reports/gold/seals проверены. Chrome/Firefox build+ZIP0,старый >500KB warning. Full unit/native/UI/live DeepSeek/full E2E заново не запускались:runtime/UI неизменны. Installed copy не обновлялась. 23/23 runtime и730 source entries проверены byte/CRC;3 canonical download copies SHA256 match,финальные notes повторно упакованы. Source ZIP исключает tests;для QA нужен Git checkout/Node22.

## Текущий этап RP286 — связанные возвраты без точной формулировки

Новый `story-obligation-recall.ts` после contextual literal matcher: source-repeated labels из prose promise title, return/debt/receipt inquiries и exact latest accepted quote для short references. Не назначает object/pronoun ID, сохраняет all candidate owners/statuses/quotes/previous facts, новая semantic coverage unverified/query. Prefix caching request-local; source/scope/budget rollback. [Мануал и границы](OBLIGATION-RECALL.md).

Seen54/54 vs47/54,312/312gold,0loss/integrity/control drift;12 changed inquiries,72others/24rejections/6budget unchanged. Ранние39/54/44/54/47/54 и всеoriginalseals/gold прежние. [Report RP286d](benchmarks/rp286d-obligation-seen-results.json). General semantic search не реализован; новый способ ограничен возвратами и источниками, подробности в мануале.

Финальный full unit7357pass/0fail/5 прежних TODO из7362,78 новых checks pass;focused384/384. TypeScript/diff-check0. Native isolated Edge RUEN12/12pass/0fail/0flaky за190.28s:новые obligation2+прежние contextual2/paragraph2/recap2+UI4(RUEN320/900,5states,keyboard/axe/no overflow). Новые2:26 exact sources/task/roles/revision IDs/conditions,503/retry/fetch/XHR/reload/raw draft/canon unchanged и28 scopedPOST. Дополнительные4 unit cases за5000 scenes прошли.406/411 fingerprints прежние,5 expected edits+3 added modules;72 other outputs/coverage unchanged,old reports/seals/gold прежние. Chrome/Firefox build+ZIP0;старый >500KB warning,live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](benchmarks/rp286-qa-results.json)

23/23 runtime и724 source entries проверены byte/CRC,3 canonical download copies SHA256 match;финальные notes повторно упакованы. Source ZIP исключает tests,для QA нужен Git checkout/Node22.

**Следующее:** новый independent preregistered long-history набор (новые сюжеты, несколько сходных возвратов/owners/terminal и ложные ссылки). Сначала protocol/input/gold/runtime fingerprints, затем измерение; старый seen54/54 не считать новой оценкой. RP-05/true delta открыты. RP274–286 local atop7005aa6, новый push не запрошен; installed copy/личный лор не менялись.

## Текущий этап RP285 — «сани/саней» исправлено

Локальный `story-object-forms.ts` дополняет single/compound/narrative object matching конечными формами короткого plural. Общий tokenizer/index прежние. Только adjacent whole qualifiers в одной части/поле, masked names не пропускаются, дубли через падежи отклоняются; source/scope/budget/canon/draft/roles неизменны. [Мануал](OBJECT-FORMS.md).

Seen47/54 vs44/54,297/312facts,15missing vs18,paragraph6/6. Ровно3 scored c1 +1 budget1800=1631tokens changes;80 результатов/coverage/24 rejections unchanged,0 integrity/prior loss. Legacy controlsDrift1 включает budget, отдельно rejectionControlsDrift0/budgetOutputChanges1. Все historical reports/gold/seals прежние. [Новый report](benchmarks/rp285b-forms-seen-results.json).

Финальный full unit7279pass/0fail/5 прежних todo из7284,53 новых checks pass; focused547/547 и report2/2. TypeScript/diff-check0. Native isolated Edge RU/EN8/8pass/0fail/0flaky за159.48s:новые forms2+paragraph2+natural2+recap2; новые2 проверяют12 whole quotes/task/claim/roles/revision IDs,503/retry/fetch/XHR/reload/unchanged canon и38 scopedPOST.407/411 original fingerprints прежние,4 ожидаемых edits+2 added runtime modules;80 прочих outputs/coverage unchanged,old reports/seals/gold сохранены. Chrome/Firefox build+ZIP0,старый >500KB warning остаётся;live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](benchmarks/rp285-qa-results.json)

23/23 runtime и716 source entries проверены byte/CRC,3 canonical download copies SHA256 match;финальные notes повторно упакованы. Исходники ZIP исключают tests:для QA нужен Git checkout/Node22.

**Следующее:** paraphrase/короткие EN references/оставшийся EN false-complete; потом новый независимый набор. Ограничения общей морфологии перечислены в мануале. RP-05/true cross-turn delta открыты. RP274–285 local atop7005aa6, новый push не запрошен; installed copy/личный лор не менялись.

## Текущий этап RP284 — абзацы поддержаны, остались формы слов и свободные ссылки

Реализован ограниченный paragraph retrieval: новый `story-narrative-action.ts`, интеграция в sequence-priority/game-context.2–4 предложения/1200chars/2–3 предметных действия, finite обстановка/location/companion; все spans проверяются, unsafe/unknown/source/budget возвращают exact prior. Имена защищены до split, Iterable names материализуется один раз; helper spelling не создаёт ID/owner/alias. Draft/canon/settings/model не меняются. Новый paragraph всегда unverified/query по смысловой полноте. [Мануал](NARRATIVE-ACTIONS.md).

[Seen report](benchmarks/rp284-narrative-seen-results.json):44/54 complete вместо39/54,294/312 facts,18missing вместо47; paragraph5/6 вместо0/6,0 prior loss/control drift/integrity. Первый RP283 report/seal/gold прежние. Из411 baseline files изменены только2 runtime files, добавлен1 module. Source `c1` в русском горном сюжете всё ещё теряется; парафразы/EN ссылки и3 старых complete-cases не исправлены. Registered RP272 algorithm теперь проверяется по точному LF snapshot `docs/benchmarks/rp272-final-sequence.txt`, hash08d93b83… прежний. Focused461pass; ранние failures/исправления подробно в CODEX-HANDOFF.

Финальный full unit7226pass/0fail/5 прежних todo из7231,56 новых checks pass;focused461/461pass. TypeScript/diff-check0. Native isolated Edge RU/EN6/6pass/0fail/0flaky за114.69s:новые paragraph2+прежние natural2+recap2;новые2 проверяют12 whole source quotes/roles/revision IDs,503/retry/reload/unchanged canon и38 scopedPOST. Из411 historical fingerprints409 прежние,2 ожидаемых edits+1 added module;все78 non-paragraph outputs/coverage unchanged,старые reports/seals/registration/gold сохранены. Chrome/Firefox build+ZIP0. 23/23 runtime и710 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Старый >500KB warning остаётся;live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](benchmarks/rp284-qa-results.json)

**Дальше:** c1/формы слов и полнота matched-групп, затем paraphrase/EN короткие ссылки и3 semantic false-complete. Новые fixes — отдельный seen runner/report; first39/54 и current44/54 не заменять. После этого следующий independent набор. RP-05/true delta открыты. RP274–284 локально поверх7005aa6, новый push не запрошен; installed copy/личный лор прежние.

## Текущий этап RP283 — новый audit нашёл оставшиеся потери

Новый заранее frozen корпус84 synthetic cases,54scored:39complete,265/312gold,47missing в15 cases. Narrative0/6,paraphrase1/6,reference4/6,plain-three5/6;0 целостности/бюджета/индекса. **3 scored failures всё же получили coverage complete**:ru mountain triple/scale1000,en mountain reference. Runtime/UI/storage не менялись. [Понятные примеры/ограничения](INDEPENDENT-SEQUENCE-RESULTS.md), [первый report](benchmarks/rp283-independent-results.json), [seal](benchmarks/rp283-first-report-seal.json). Не называть этот результат новым60/60 или закрытым RP-05; прежние наборы другие.

Current frozen manifest — `tests/fixtures/story-independent-sequences-v2-baseline.json`. Первая подготовка с invalid b-old kind event/open task и точные -preflight copies сохранены; она не оценивалась compiler. Поменяны только kind task/derived role key, gold неизменен, whole84 input equality подтверждена. Архивный runner не запускать; исходные протоколы/fixtures/first report не подгонять. Это agent-authored accepted-memory audit с повторяющимся фоном, не blind external/live model proof.

Финальный full unit7170pass/0fail/5 прежних todo из7175,89 новых checks pass; fixture/source/gold/seal/report checks сохраняют результат39/54. Первый общий прогон неполный:695pass/1timeout и276 suites с ENOENT временного transform-cache; он сохранён в docs/benchmarks/rp283-unit-first-environment.json. Повтор выполнен с отдельными TEMP/TMP,1 worker,после сборок,без изменения thresholds/runtime. TypeScript/diff-check0;411 RP283 fingerprints/first report/input/gold/seal неизменны, прежние RP280/281 seals также прошли. Chrome/Firefox build+ZIP0. 23/23 runtime и704 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Старый >500KB warning остаётся. Production/UI не менялись; native/browser/live model/full E2E не повторялись. Tests исключены из source ZIP, для воспроизведения нужен Git checkout/Node22. Installed copy не обновлялась

**Следующее:** natural действия внутри абзаца с whole independent sources, затем paraphrase/короткие EN references/c1 и уточнение coverage confidence.15 losses теперь seen; для фикса — отдельный regression runner/report, для независимого proof потом новый frozen набор. RP-05/true delta открыты. RP274–283 локально, новый push не запрошен, личный мир/installed copy прежние.

## Текущий этап RP282 — историческая QA отделена от нынешнего поиска

Исправлены8 historical failures из RP281: явный comparison profile сохраняет старые5→16 и целые input/gold/provenance hashes, не ограничивая нынешний подбор8. Это не эмуляция старой версии. CRLF fixture восстановлены согласно .gitattributes. Production/UI/storage не менялись; отдельные226 checks проверяют current defaults на224 сценариях, lasting16/32 и отсутствие выбора по gold. [Методика](HISTORICAL-SEARCH-QA.md).

Полный unit:7081pass/0fail/5 прежних todo из7086;226 новых pass. TypeScript/diff0;11 historical files и все полные digests прежние,409/411 long-history fingerprints unchanged,только2 ожидаемых RP281 parser edits. [QA report](benchmarks/rp282-qa-results.json). Chrome/Firefox build+ZIP0,23/23 runtime bytes/CRC match. 695 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Native/live/full E2E не повторялись: production/UI не менялись; прежние10 Edge checks относятся к RP281. Tests исключены из source ZIP, для воспроизведения нужен Git checkout/Node22. Installed copy требует ручного reload.

**Следующее:** новый заранее frozen independent набор длинных natural sequences после исправления RP281. Старые RP280 first report54/60 и seen RP28160/60 сохранены; не выдавать известные данные за новый holdout. RP-05 и true delta открыты. RP274–282 локально поверх7005aa6, push не запрошен. Личный мир и installed copy не менялись.

## Текущий этап RP281 — составной разбор исправлен, остался долг исторической QA

Два runtime файла теперь поддерживают comma-separated2–3 object clauses и finite examine/untie/connect/disconnect/move RU/EN формы. Любой unknown/conditional/quoted/negated/personal/third-person clause отклоняет весь разбор; name masking до split, исходные ограничения длины/разных объектов/числа частей и источников прежние. [Мануал](COMPOUND-ACTIONS.md) обновлён. История/настройки/модель/UI не меняются.

RP280 input/gold/first54/60 report сохранены. Новый [seen report](benchmarks/rp281-natural-seen-results.json):60/60 полных наборов,missing/integrity/control drift/prior source loss0. Это повторная проверка известных данных, не новый независимый успех. Новые57pass/TypeScript/diff0; full6847pass/8fail/5todo. Все8 failures воспроизводятся с точными pre-RP281 parser bodies:7 messages одинаковы, lasting baseline уже8 и теперь9 при stale expectation5. [Доказательство](benchmarks/rp281-legacy-comparison.json). Native Edge RU/EN10/10pass/0fail/0flaky; новые natural12 sources/38POST/503/retry/reload/unchanged canon. Chrome/Firefox0,23/23 runtime/693 source entries byte/CRC/3 SHA256 copies, финальные notes включены. Installed copy не обновлялась, live model/Firefox native не проверены.

**Следующее:** исправить historical compiler/provenance coupling в `story-lasting-recall-quality.test.ts`, `story-search-evidence.test.ts`, `story-search-grounding.test.ts`, сохраняя old gold/reports и отдельно проверяя current runtime. Не просто менять5 на9/не урезать нынешнюю память до8 ради зелёного. Потом новый заранее frozen independent набор natural sequences. RP-05 и true delta открыты. Старый RP280 runner/baseline не переписывать; для нового runtime есть separate seen runner. Подробная методика before comparison — CODEX-HANDOFF.

RP274–281 локально без нового push; личный мир/installed copy не менялись.

## Текущий этап RP280 — независимая проверка выполнена, RP-05 открыт

Финально1138 selected unit pass/0fail/80 новых checks, TypeScript/diff-check0;411 frozen fingerprints/first report/baseline unchanged. Chrome/Firefox build+ZIP0,23/23 runtime/690 source entries byte/CRC,3 copies SHA256; финальные notes включены. Independent качество остаётся54/60, diagnostics не заменяет первый результат. Runtime/UI не менялись, native/live/full suites не повторялись.

Пункт4 завершён как audit неизменённого RP279:78 новых synthetic scenarios,54/60 полных gold sets (48/54 основных +6/6 scale),330/348 facts;18 controls отдельно. Во всех78 evidence/status/source/budget/cold-warm/input integrity без нарушений. Все6 failures — три естественных действия: parser не распознаёт запятые/часть глаголов, остаётся cap8 вместо11 при свободном бюджете. [Результат/границы](LONG-HISTORY-RESULTS.md), финальная QA/пакеты — верх CODEX-HANDOFF. Первый отчёт и411 fingerprint manifest неизменны; старые данные не перезаписывать.

**Дальше:** исправление естественных составных действий на этих теперь seen6 regressions, RU/EN separators/verbs, с сохранением condition/quotation/negation/name/source/full-budget guards. Создать отдельный seen runner/report для изменённого runtime; не менять frozen gold/baseline ради прохождения snapshot test. Для независимого proof после фикса нужен новый набор. True cross-turn delta из пункта3 остаётся открыта. RP274–280 локально без нового push; runtime/UI и личный мир этого этапа не менялись.

## Текущий этап RP279 — ограничение третьего пункта и следующий независимый набор

Финальная QA:796 selected unit pass/0fail, TypeScript/diff-check0;16 synthetic installed Edge RU/EN pass/0fail/0flaky. Chrome/Firefox build+ZIP0,23/23 runtime и682 source entries сверены byte/CRC,3 copies SHA256; итоговые notes повторно упакованы. Live model/full suites не проверены; личный мир/installed copy не менялись.

Сделана безопасная self-contained упаковка повторяющихся полей; sparse columns включены в content только когда выигрывают chars и полный meter.128 seen scenarios:данные128/128 exact,102 columns/26 old, около1.3% whole-wire savings; это небольшой mechanical gain. Полная межходовая дельта НЕ реализована: prompt+parent/history/accepted receipt не доказывают, что модель видит ранее отправленную основу. Не выдумывать такое доказательство и не выдавать безопасную упаковку за полностью выполненный пункт3. [Границы](SELF-CONTAINED-MEMORY.md), финальная QA/пакеты — верх CODEX-HANDOFF. Прежние отчёты/gold/protocols сохранять, live quality не заявлять.

**Следующий «продолжай» — пункт4:** до новых правил/весов составить действительно независимый новый набор длинных историй с gold и baseline, затем проверить качество/потери/источники/время/составные действия/местоимения и масштаб. Не переиспользовать seen RP273/RP277/RP279 в роли independent holdout. Проверять новый wire отдельно от качества retrieval; model interpretation не доказана обратимостью JSON. Пункт3 delta limitation оставить открытым в roadmap. RP274–279 локально, новый push не запрошен.

## Текущий этап RP278 — второй пункт

Переподготовка одинаковых storage clones устранена scoped `GameSearchIndex` в content controller. Чистые lexical views переиспользуются, текущие scopes/status/quotes/role proofs/selection/frequency/budget всегда читаются заново. Deletion/disabled/replace/undo/import и world/game/branch/vault clear защищены; title aggregate cache имеет освобождаемый weak owner. [Границы и примеры](INCREMENTAL-SEARCH.md), финальная QA/упаковка — верх CODEX-HANDOFF. Первая подготовка после page reload остаётся cold; индекс не записывается на диск. Прежние gold/protocols/reports не перезаписывать.

**Следующий «продолжай» — только пункт3:** изучить текущую передачу unchanged memory и контракты реального DeepSeek request/history, затем сократить повторы с проверкой reload/retry/failed send/continuation/edit/reset/two tabs. Нельзя считать ранее подготовленный или отправленный контекст гарантированно доступным модели; нельзя терять обязательный лор/цитаты/правки. Нативную историю не объявлять автоматически очищенной. После пункта3 остановиться до отдельного prompt на пункт4 (независимый набор длинных историй). RP277/278 не повторять; RP274–278 локально без нового push.

RP278 завершён:762 selected unit pass/138 новых, TypeScript/diff0;128 cold/warm old cases exact/frozen64 unchanged. Native synthetic Edge6/6pass/0fail/0flaky,66POST, actual edits/delete/restore/manual/world/reload + old whole-source/notice controls. Chrome/Firefox0,23/23 runtime/678 source entries byte/CRC/3 SHA256 copies; итоговые notes повторно упакованы. Head7005aa6 проверен, личный мир/installed copy не менялись. Full import/reset workflows/live model/full suites не проверены. При новом prompt переходить к пункту3.

## Текущий этап RP277 — отдельные четыре запроса пользователя

Сейчас выполнен код первого пункта RP-05: source-backed contextual candidates для «её подарок»/«то обещание» с сохранением ambiguity guard, всех prior sources и атомарного полного бюджета. Подарок без задачи/однословное название, exact quotes/roles/source lineage/terminal status/rename vs replacement защищены. [Примеры](CONTEXTUAL-MEMORY.md), финальные проверки/пакеты — верх CODEX-HANDOFF. Первые64 frozen cases не дали прироста: старый и новый16/16, controls48 exact; отдельные15-record stress tests полезнее cap8, но уже seen. Не называть это независимой итоговой проверкой качества или разрешением любых местоимений.

**Следующий «продолжай» — только пункт 2:** изучить существующие `story-fact-search-index`/retrieval caches и обновлять индекс только изменившихся данных, сохраняя корректность при edit/delete/accept/undo/import/reset/world/branch/rename/reload. Сначала проверить текущую реализацию, не делать новый индекс без необходимости. После этого остановиться и ждать prompt для пункта 3 (повторная передача неизменной памяти), затем пункта 4 (независимые длинные истории). RP276 не повторять. Frozen gold/protocols/reports сохранять; E5/MMR не включать. RP274–277 локально поверх7005aa6 без нового push; чужие изменения не затирать.

RP277 завершён:580 selected unit pass/0fail,96 новых tests, TypeScript/diff0; native4/4pass и на финальном guard/build новые2/2pass за44.4s/18POST. Chrome/Firefox build+ZIP0,23/23 runtime/676 source entries byte/CRC/3 SHA256 copies audit, итоговые notes включены. Browser только isolated synthetic Edge, не live DeepSeek/личный мир; полный регресс не запущен. Installed copy требует ручного reload. Пункт1 не повторять и пункты2–4 не выполнять без очередного prompt.

## Текущий этап RP276

Полный synthetic user flow проверен:10 current RU/EN native cases passed (review/no changes/reload/summary/new home/accepted POST/ownership;503 home, library commit failure, session receipt failure; hidden real wire echo). Реальные race/bypass исправлены: accepted target сохраняется перед commit; UI даёт локальный retry без модели, pending handoff не обходит draft promotion, fetch/XHR блокируют дубликаты независимо от strict preference. Receipt scoped snapshot/token/target; session reload или page-local fallback при session отказе. Старые revision guards сохранены.

Финальный52 targeted browser run34pass/18Edge-only Firefoxskip/0fail/0flaky;11selectedfiles245unitpass иTypeScript/diff0. UI Edge/Firefox RU/EN320/900/360/1280/axe/keyboard, hidden wire recap, текущий native repeat/build/packages — верх CODEX-HANDOFF. Новый `playwright.continuation.config.ts` повторяет точный набор, не весь runtime-sync. Личный аккаунт/реальная модель/full suite не проверены. RP274–276 локально поверх7005aa6 без нового push.

**Дальше:** independent free-language corpus/scale ДО новых retrieval changes, full regression/performance/RP-08. Не повторять текущий full-chain этап. Отдельно может потребоваться accepted receipt recovery после закрытия вкладки/browser restart; текущая session/page-local отметка этого не гарантирует. Snapshot хранится отдельно. Frozen gold/protocols/E5/MMR не менять; native переписка DeepSeek не сжимается этой логикой.

RP276 упакован: latest native10 repeat10pass за50.2s/28POST с local-retry/fetch/async+syncXHR controls; Chrome/Firefox0,23/23 runtime/669 source entries byte/CRC и3 copies SHA256 match. Итоговая передача повторно обновлена в source ZIP. Полный Git checkout нужен для повторения tests; source ZIP их исключает. Installed copy обновляется вручную.

## Текущий этап RP275

Исправлен двойной scene reference: prepared recap заменяет automatic old transcript fallback в compiler/content и recentStory следующего сегмента. Оригинальные records/facts/roles/episode IDs/задачи/время/ручные правки не удаляются.11 selected files241unitpass,4 усиленных long checks повторно pass, TypeScript/diff0;12 browserpass/4 Edge-only Firefoxskip/0fail/0flaky (UI RU/EN360/1280 и native saved recap/retry/2 chats). Текущие packages — верх CODEX-HANDOFF. Личный лор/installed copy не менялись, push не запрошен, RP274/RP275 локально поверх7005aa6.

**Далее:** полный synthetic flow analysis→review→summary→fresh chat с управляемым модельным ответом, ошибка открытия и post-HTTP local receipt failure. RP275 native начинает с готовой сжимки, длинная история проверена storage интеграцией; это не live full flow. Не переписывать механизм, не ослаблять shared revision/source guards, не обещать очистку native DeepSeek history. Потом independent free-language corpus/full regression/scale/performance/RP-08. [Руководство](SAFE-CHAT-CONTINUATION.md).

Упаковка RP275 завершена:Chrome/Firefox0,23/23 runtime и668 source files byte/CRC проверены,3 copies SHA256 match; итоговые notes обновлены в source ZIP. Не повторять этот этап, переходить к full synthetic service flow. Tests повторять из Git checkout, source ZIP их исключает.

## Текущий этап RP274

После pull7005aa6 реализован отдельный сигнал дефицита важного набора: observer не меняет запрос/выбор/report/exact rollback, но передаёт transient memoryCoverage в состояние страницы. Подтверждённый budget deficit и required overflow видны спокойно без модального окна; complete/source/query объясняются в подробностях как подготовка, не доставка. Полный текст/канон/историческая квитанция неизменны. Новый статус пересчитывается после reload и входит в сигнатуру sidepanel updates. [Примеры](IMPORTANT-MEMORY-STATUS.md), финальные QA/пакеты — начало CODEX-HANDOFF. Личная игра не менялась, текущая работа локальна, новый push не запрошен.

RP274 закрыт:15selectedfiles953unitpass/0fail, TypeScript/diff-check0, baselineUnchanged64;32 UI RU/EN320/900px Edge/Firefox pass и2 native Edge pass/2 штатных Firefox skip на новой сборке. Native28 POST/12 whole sources/sidepanel/reload/неизменность canon,667 source entries и23/23 runtime+3 copies audit; итоговые notes входят в ZIP. Full unit/browser/live account не проверены, ранние failures объяснены в CODEX-HANDOFF, работа локальна без нового push.

**Начать дальше с существующего безопасного continuation:** изучить core/storage story-continuation и story-checkpoint, затем длинный synthetic перенос активной линии с источниками/ролями/claims/tasks/time/manual edits/reload/retry/two tabs/ошибкой открытия. Существующий механизм не переписывать с нуля; не считать уменьшение локальной добавки очисткой native DeepSeek window. Дальнейшие NEW corpus свободной речи/полный регресс/масштаб/RP-08 остаются отдельными задачами. Frozen RP273 snapshot сохранён, протоколы и эталоны не перезаписывать, E5/MMR не включать.

## Передача на рабочий ПК — RP269–RP273

Publication gate:25selectedfiles/1417unitpass/0fail, TypeScript/diff-check;41 frozen indexed files после Git checkout сохраняют эквивалентные registered byte fingerprints/required EOL. Это не full suite/live account. Финальные тексты передачи повторно включены в source ZIP и package audit; base f4a093e, текущую опубликованную вершину сверять `git log` после pull.

Пользователь запросил публикацию всего пакета в main. Актуальная передача — начало [CODEX-HANDOFF](../CODEX-HANDOFF.md), затем [итог15 октября](HANDOFF-2026-10-15.md) и верх [ROADMAP](../ROADMAP.md). Старые «push не запрошен»/«следующее RP272» ниже исторические; не начинать завершённую работу заново.

Уже в игре: приоритет целых содержательных исходников перед доказанно пустыми повторными разговорами; RU/EN одиночные, короткие и2–3 составных действия;9+ источников целиком по полному added-context budget или exact prior rollback. История/канон не удаляются, задачи не завершаются словами игрока, личные/указательные ссылки и разные владельцы не угадываются. RP269/E5/MMR — исследования, не новая модель поиска в расширении. Сохранены все gold/протоколы/первые и исправленные reports; наборы уже seen.3 текущих ZIP и QA обновлены, installed copy обновляется вручную.

Начать следующим запросом именно с понятного сигнала дефицита полного важного набора: complete vs local budget vs unknown source/unsupported query, без засорения нарратива и необходимости ручного review каждой реплики. Сохранять exact fallback/required lore/source integrity; диагностику передавать отдельно. Затем проверить/довести существующий безопасный continuation нового чата на длинной synthetic истории, не переписывать его заново и не обещать сжатие native переписки каждые10–15 сообщений. Минимум вмешательства игрока — приоритет пользователя.

Открыты: свободная речь/новый независимый corpus, настоящая игра с моделью и масштаб, полный актуальный unit/browser регресс, источник/задачи/ручные правки при новом чате и сбоях/двух вкладках, производительность/RP-08. Финальные1279 selectedunitpass/TypeScript и8 unique native synthetic cases не доказательство всего endless RP. Личные аккаунты/миры не использовать для разрушительных проверок. Рабочий ПК: full Git checkout, Node24+, npm ci если dependencies отсутствуют. Frozen `.gitattributes`/gold/registrations не переписывать.

## Текущий этап 15 октября RP273

Завершён:3 canonical ZIP/Chrome+Firefox build, SHA25623/23 runtime/662 source entries match disk/copies, финальные notes включены. Source исключает tests/private-assets/веса/секреты/Git/nested ZIP. Selected1279unitpass, strengthened valid whole quote budget test196pass, TypeScript0;8 unique native cases passed с ранними harness failures объяснёнными ниже. Личная installed copy не менялась, push не запрошен. Не повторять завершённый RP273; дальше видимый дефицит whole bundle/безопасный новый чат, не arbitrary language/E5/MMR по уже seen corpus.

Native QA завершён:8 unique scenarios passed across6 unchanged old RU/EN and corrected2 new RU/EN. First6pass/2fail от old-question assertion, next2fail/isolated1fail от duplicate-text early baseline; trace доказал last batch50/51 was still recording. Test waits exact selected source, DOM matches history on reload; unchanged exact canon assertions passed. Production/input/gold не менялись.26 new actual scoped POSTs/12 whole sources/reload/no extra pages/page errors, all own contexts closed. Source ZIP/audit завершены; финальный статус — верх CODEX-HANDOFF. Личный аккаунт/installed copy не трогали.

Final selected1279unitpass/0fail (196 new), TypeScript/diff-check0; первоначальные failures и отдельно зарегистрированные поправки по регрессу записаны в CODEX-HANDOFF. Все3 сравнения32/32 complete vs0/32,32 exact controls,320 whole-budget/source probes. Old gold/input/registrations неизменны; amended evaluation уже seen, не independent holdout. Native QA завершён, package audit завершён. Локальный бюджет добавленной памяти НЕ равен измерению native свободного окна DeepSeek.

При9+ важных источниках whole matching substantive + prior non-repeat bundle передаётся по полному бюджету либо exact RP272 rollback. Условия/quotes/status/source не режутся/не угадываются; <=8 lanes/8 proposals за ответ unchanged. Decoder128 safety — один request, не лимит мира. UI/DB/schema/settings/model/canon/native chat не менялись. [Пример](DISCUSSION-PRIORITY.md).64 новых input/gold/baseline до интеграции, отдельный protocol до comparison; old gold/core/registrations сохранены, cap8 historical comparator явно выключает budgetPriority, finalized RP272 compiler snapshot сохранён. QA завершён, ZIP audit завершён, финальный статус смотреть в начале CODEX-HANDOFF/ROADMAP. Push/installed copy не запрошены. После QA — сигнал дефицита whole bundle и безопасный новый чат; весь endless RP не обещать.

## Текущий этап 15 октября RP272

Chrome/Firefox build+ZIP и3 canonical copies готовы; SHA25623/23 runtime/648 source entries совпадают с диском/copies, итоговая QA-документация входит в source ZIP. Tests/private-assets/веса/секреты/Git/nested ZIP исключены. Старые проверки/реализацию RP272 не повторять; installed copy нужно обновлять вручную, push не запрошен.

Приоритет для коротких RU/EN действий и2–3 частей подключён в игру. «открываю дверь и достаю ключ» требует содержательных сведений об обоих предметах; вся память/цитаты/условия/status/sourceIDs + prior non-repeat должна поместиться≤8/full render или возвращается exact RP271. Unknown/edited/foreign/ambiguous personal source не угадывается; действие запроса не выполнение, shared labels не identity. История/DB/settings/model не менялись. [Пример](DISCUSSION-PRIORITY.md).

Fresh64cases до интеграции:28positive/36control. Type-only unused fixture import fix separately registered, algorithm/compiler/input/gold unchanged, old protocol/snapshot preserved.28/28 complete vs0/28, controls exact,192 whole-budget probes pass.154 new unit cases, selected931pass, TypeScript0. Native Edge8/8pass/0fail/0flaky, source/conditions/reload/canon сохранность; all own contexts closed. Финальные ZIP итоги — верх CODEX-HANDOFF. Старый RP271 compiler fingerprint привязан к историческому snapshot, прежние эталоны не переписаны; full unit/live account не считать проверенными в этом этапе.

Следующий шаг — NEW corpus и budget allocator для9+ нужных источников; не удалять канон/не объединять условия/не повышать cap без общей проверки. Все RP272 cases seen, arbitrary language/E5/MMR/native chat compression/RP-05–08 остаются открыты. Установленная копия требует ручного обновления, push не запрошен.

## Текущий этап 15 октября RP271

Chrome/Firefox и3 canonical ZIP завершены; SHA25623/23 runtime и640 source entries совпадают с диском/copies, документация после QA входит в source ZIP. Tests/private-assets/модель/секреты/nested ZIP исключены; полный эксперимент повторять из Git. Установленные личные файлы не заменялись автоматически, push не запрошен. Проверки и результаты этого этапа не повторять.

Рабочий приоритет RP270 расширен на конечные более свободные формы повторов (разделители/порядок трёх явно отсутствующих изменений) и прежние одиночные first-person object actions. Полный literal substantive bundle + все prior non-repeat источники должны поместиться≤8/full budget либо exact RP270 fallback. Shared literal-label ambiguity guide остаётся на wire; все разные исполнители/условия/цитаты — отдельные кандидаты, не объединённая идентичность. Unknown source/name/personal/deictic/reference-only/restart защищены; DB/canon/model/settings не менялись. [Пример](DISCUSSION-PRIORITY.md).

Новый baseline90cases перед интеграцией:18positives/72controls; первый15/18, separately registered amended18/18 с прежними gold/input. Старые snapshots/protocol/report сохранены; revised evaluation reused, не fresh holdout.270 full-prompt probes без source/budget ошибок.165 новых unit cases, focused444pass, TypeScript0; полный5871pass/1 legacy100-turn timeout/5todo, unchanged file repeat24pass.8 уникальных native cases прошли; старые reference2 после unchanged sequential rerun, первый combined run имел timing failures. Не выдавать эти первые прогоны за0fail/0flaky. ZIP-проверки — верх CODEX-HANDOFF. Пересборка не обновляет installed copy автоматически; push не запрошен.

Следующая задача — NEW corpus для коротких/составных действий и более свободной речи ДО изменения правил. Все RP271 examples seen; сохранить whole evidence/current status/conditions/uncertainty/cap8/exact rollback, не добавлять модель или стирать канон.9 существенных источников и native chat compression — отдельные открытые задачи. RP270 ниже исторический, не повторять завершённую работу.

## Текущий этап 15 октября RP270

По запросу пользователя реализован ограниченный приоритет важных источников перед **явным повтором без новых сведений/действий/обязательств**. Runtime two-pass/full bundle сохраняет все non-repeat старого подбора и literal topic, либо exact original output/counters. Не удаляет историю/не меняет статусы/не угадывает владельца, не подключает E5/MMR. [Метод, пример, границы](DISCUSSION-PRIORITY.md), текущие QA/упаковка — верх CODEX-HANDOFF. RP269 ниже — исторический этап, больше не считать всё только исследованием.

Следующий RP-05: новый независимый RU/EN corpus более свободных повторов и ordinary actions ДО расширения правила. Все96 RP270 уже seen; повторная оценка после mechanical RU quote punctuation fix не новый holdout. Source/conditions/uncertainty/current status/cap8/whole budget/exact fallback остаются обязательными; проблема9 substantive источников не закрыта. Не добавлять модель/сервис и не стирать канон ради экономии контекста. Новая user setting не нужна; discussionPriority:false — внутренний comparator. Финально5707unitpass/0fail/5 прежних todo, TypeScript/diff-check0,8/8 synthetic Edge native cases. Chrome/Firefox и3 canonical ZIP сверены SHA25623/23/631 files/copies; личные installed files автоматически не менялись. Работу/QA RP270 не повторять, продолжать с нового набора.

## Текущий этап 15 октября RP269

Пакеты пересобраны и сверены SHA25623/23/619 entries/canonical copies. Их игровой алгоритм прежний; установка ради RP269 не требуется. Source содержит `.gitattributes` для portable audit hashes и текущие tools/report/docs, но не tests/private-assets/модель/секреты. Полное исследование повторять из Git checkout.

Новый source-aware эксперимент завершён, но в игру не внедрён. Полнота holdout осталась10/16, первая неверная позиция8→6. Все48 контролей сохраняют прежний выбор; whole source/status/conditions/IDs/cap8/budget проверены. Рабочий поиск RP262 и личный мир неизменны. [Результаты и повторение](SEARCH-GROUNDING.md); верх CODEX-HANDOFF — текущая передача, нижнее задание RP264 уже выполнено этим исследованием.

**Дальше:** создать новый independent RU/EN корпус со свободнее сформулированными запросами, закрепить gold/baseline до изменения правил. Затем отдельно проверить защиту обязательных источников по задаче запроса: нынешнее правило «любой известный speaker обязателен» заполняет восемь мест разговорами и не улучшает полные наборы событий/условий. Не тюнить по уже просмотренным96 cases, не внедрять старые E5/MMR/finite source grammar и не удалять каноническую историю ради места в запросе. Сохранить источники/полные альтернативы/негативные сведения/current statuses/unknown/exact budget fallback. Node24+, модель не нужна. В Git локальная работа поверх f4a093e, push не запрошен.

QA:138 new unit cases; выбранный590pass/0fail, TypeScript/diff-check. Две старые ошибки frozen code SHA от CRLF/LF исправлены только форматированием и `.gitattributes`, без новых gold/правил. Нативный браузер/полный unit/live account не повторялись; установленные файлы автоматически не обновляются.

## Передача 14 октября: RP256–FIX268

Пользователь поручил push всех накопленных изменений в main. Этот раздел является текущим заданием; исторические строки «локально/push не запрошен/main e8f5cba» ниже описывают состояние до этой передачи. После pull сверить git log и верх CODEX-HANDOFF. Если дома есть несохранённые изменения, сохранить их и не применять reset/force для синхронизации.

### Уже сделано, не повторять

- **RP256–262:** подбор нескольких старых поручений, длинных и составных действий, постоянных сведений/результатов, ссылок на предметы, формы коротких RU имён. Исходники, условия, статусы, неизвестность и целый бюджет сохраняются. Ограничения RP-05–08 остаются в ROADMAP.
- **RP263–264:** local semantic/diversity experiments и полные замороженные отчёты включены в Git. Независимый выигрыш не подтверждён; E5/MMR в runtime не подключены. Локальные веса и установленная optional среда исключены из Git/ZIP.
- **UX265–267:** новые меню/настройки, явные состояния/ошибки/предупреждения, диагностика за раскрытиями, сохранность черновиков и готовой проверки сброса. Финально5354 unit pass/5 прежних todo; UX browser227pass/45 явных skip, включая280MiB export/restore24 персонажей/40 фото. [Матрица и ограничения](UX-QA.md).
- **FIX268:** ложный reset-stale при долгом чтении устранён; legacy ready plan поддержан без подмены baseline. Настоящие изменения мира/игры остаются защищены.217 focused unit pass;16 browser pass/8 Edge-only Firefox skip,0 fail/flaky; TypeScript и обновлённые пакеты проходят проверки. Личный мир не сбрасывался.

### Первый следующий шаг: RP-05 — событие и обсуждение

1. Прочитать [SEARCH-DIVERSITY](SEARCH-DIVERSITY.md), текущий RP264 в ROADMAP и предыдущие frozen protocols. Все128 старых примеров теперь являются seen/development, новым holdout они не считаются.
2. До изменения алгоритма создать отдельный независимый RU/EN корпус и зафиксировать его эталон/baseline/хеши. Нужны совершённое действие против намерения/обещания/обсуждения, длинный хвост поздних разговоров, несколько похожих дел с разными условиями, отрицания/отмена/смена кода, чужой или отсутствующий источник и новый человек с прежним именем.
3. На вымышленных данных измерить lexical baseline. Затем провести отдельный source-aware grounding/reranking эксперимент, сохранив исходные подтверждения, полные условия/роли/актуальные статусы, cap8 и общий бюджет. Проверять полноту набора, первый приоритет, drift неизвестных запросов и фактическое попадание в целый контекст раздельно. Не подбирать веса по новому holdout после просмотра результатов.
4. При неизвестном источнике или нехватке места возвращать точный прежний подбор. Обычные роли/авторство/cosine сами не доказывают, что действие произошло. Нынешний E5/MMR в игровую отправку не включать. Production change — только после отдельного доказанного выигрыша и сохранения защит.
5. Обновить ROADMAP/этот файл/CODEX-HANDOFF по фактическому результату. На этом ПК использовался Node24.19.0; Node20 несовместим с Vitest5. Модель/private-assets не приходят с pull: сначала можно сделать корпус и lexical baseline без скачиваний. Исходный ZIP не содержит tests, поэтому исследование запускать из полного Git checkout. Для UX учитывать DESIGN-SYSTEM.

### Установленное расширение

Готовые3 ZIP находятся в downloads. Для Edge заменить файлы Chrome ZIP в прежней папке установленного расширения, затем reload расширения и DeepSeek. Не удалять расширение ради обновления. Старый готовый план сброса после обновления можно подтвердить, только если сам лор/прогресс не менялся. Не сбрасывать личную игру автоматически и не выдавать синтетические проверки за живой аккаунт.

## Последнее исправление FIX268

Готовый reset plan ошибочно устаревал от служебных изменений всей ChatBinding. Исправление сравнивает обе исходные копии без отметок чтения/времени/расположения/локальных media/recovery/notice, но сохраняет контроль настоящего прогресса/лора/анкет/ревизии. Legacy ready jobs поддержаны без подмены baseline и нового DeepSeek-запроса.50 минут ожидания сами ничего не отменяют. Личный мир не сбрасывался. Итог проверок/архивов — верх CODEX-HANDOFF; старый готовый план после ручного обновления расширения пригоден только при неизменившейся игре. Прежняя локальная работа сохранена, push не запрошен. Следующий RP-05 — source-aware grounding из RP264; завершённый UX267 не повторять.

## Последнее изменение UX267

UX265–267 закрыт: исправлены потеря черновика настроек через нижнее меню, ложный конфликт сохранённого факта, ошибки/медленная запись переключателей; повторная подсказка и устаревшие подписи. Весь unit5354pass/0fail/5todo, focused31/31, TypeScript/diff-check0. [Матрица и команды](UX-QA.md):22 файла/272 варианта,227pass/45 предусмотренных skip,0fail/0flaky в окончательном прогоне. Включён отдельный экспорт280MiB с восстановлением24 карточек/40 изображений в пустую БД. Node24, сервер4175, Firefox1worker; старый Node20 несовместим с Vitest5. Пакеты/границы — начало CODEX-HANDOFF. Личный мир/профиль/аккаунт не трогали. Профили test-results-ux267* оставлены: автоматическая проверка запретила очистку; в ZIP их нет. Всё локально, commit/push не запрошены. Дальше RP-05 grounding из RP264, нынешние E5/MMR не подключать. Не повторять завершённый UX.

## Предыдущее изменение UX266

По пользовательскому запросу перестроены «Игра», «Память игры» и настройки: task navigation, явные сохранение/область действия/старый и занятый чат, сохранение черновиков, отдельное управление прогрессом. Технические данные спрятаны в SupportDetails, общая диагностика — advanced/support. Полезные ошибки и успех остаются видимыми. [Краткие пути](MENU-GUIDE.md), точные файлы/проверки и упаковка — в начале CODEX-HANDOFF. Unit/E2E этой итерации не запускались, installed/live не проверялись; полное UX QA не закрыто фиктивно. Лор/память/алгоритм RP262 не менялись. Следующий RP-05 остаётся независимым grounding-экспериментом из RP264. Ничего не пушили по этому запросу; не затирать прежнюю локальную работу.

## Последнее исправление UX265

Пользователь сообщил: готовый reset plan24/ready/cleanup done, но после закрытия временного окна не увидел подтверждений. Исправлены наблюдение сохранённого плана вне диалога, общая форма вне вкладок меню, уведомление исходного чата и два видимых шага подтверждения. Исправленные invalid-evidence теперь находятся в «Истории проверки ответов» с явным статусом. Проверки цитат/применения не ослаблены, личный мир не сбрасывался. QA: TypeScript/diff-check и ручной локальный UI RU/EN320/900px; unit/E2E/live account не запускались. Пакеты/подробности в актуальном CODEX-HANDOFF; обновить установленную копию вручную. Следующий исследовательский RP-05 ниже остаётся прежним, E5/MMR в игру не подключать. Всё локально, push текущим запросом не разрешён.


## Текущий приоритет RP264

Завершены два read-only сравнения: diversity MMR и обязательное сохранение исходных доказательств. В рабочий поиск НЕ подключены; текущий runtime RP262. Новых загрузок/сервисов/production deps/изменений личного мира нет. Сначала40 новых RU/EN запросов выявили потерю разных условий похожих поручений. После этого они стали development; до проверки защиты отдельно зафиксированы ещё24 новых, включая90 обсуждений с явным автором. Наборы и алгоритмы до своих запусков зарегистрированы раздельно.

С защитой: seen50/50 vs42/50 lexical, development26/30 vs23/30, второй независимый fresh14/20 vs14/20. Общие90/100 включают просмотренные примеры и НЕ означают независимую точность.14/28 прежних/dev controls меняют подбор, новые4 сохранены;24/100 wrong-first прежние. Mandatory source loss0, whole-context audit224 actual case/budget0 violations; малый бюджет возвращает точный prior context. Source attribution/conditions/current status/code сохраняются, similarity не объединяет предметы/владельцев/действия.

Начать с [актуальной передачи](../CODEX-HANDOFF.md), [метода и команд](SEARCH-DIVERSITY.md), benchmark reports rp264/rp264b в benchmarks. CLI --experiment rp264b требует полный Git checkout с tests и уже согласованную локальную E5 runtime/model в private-assets; они не появятся с pull и не входят в ZIP. Никакой новой модели выбирать пользователю не нужно. QA/пакеты — в CODEX-HANDOFF; только3 canonical ZIP, installed copy меняется вручную.

**Дальше RP-05:** независимый source-aware reranking/grounding замер, различающий сыгранное действие/обсуждение/отсутствие нужного события. Авторства или cosine недостаточно. До изменения — новый корпус; все128 текущих cases уже seen. Сохранить обязательные доказательства/альтернативы/бюджет; нынешний MMR в игру не включать. Не повторять RP239–264. Main e8f5cba; RP256–264 локальны, push не запрошен.

## Предыдущий этап RP263

Локальный read-only смысловой эксперимент завершён с отдельного согласия пользователя на скачивание. В игру НЕ внедрён: на50 positive запросах текущие lexical top8 находят все нужные источники42 раза, выбранная E5-small q8 —28, fixed RRF hybrid —35. Hybrid меняет8/14 контролей; даже direct20/20→18/20. 64 RU/EN запроса (40 development+24 заранее размеченных holdout),424 входа; параметры/эталон после результата не подгонялись. Runtime RP262/лор/исторические ID/актуальные статусы/общий бюджет сохранены.

См. [актуальную передачу](../CODEX-HANDOFF.md) и [команды, метод, скорость, пределы](SEMANTIC-SEARCH-PROTOTYPE.md). Case-level отчёт benchmarks/rp263-search-results.json; fixture baseline tests/fixtures/story-search-baseline.json. Модель135392183 bytes и отдельные зависимости остаются только private-assets, не входят в ZIP/production deps. Пользователь разрешил этот локальный эксперимент, не внешний сервис/передачу библиотеки/поставку модели всем пользователям. На другом ПК веса не появятся после pull; перед новым скачиванием учитывать это разрешение и контекст. Node offline probe0 обращений, повторные424 вектора идентичны; cold load0.923s + inference4.160s, кэш18.75ms отдельно. Это не браузерная/живая проверка. Выбранный unit242/0; финальные проверки/пакеты указаны в CODEX-HANDOFF.

**Продолжать:** новый изолированный подбор с сохранением точных совпадений/исходных событий и защитой от заполнения мест повторными обсуждениями. Сначала зафиксировать ещё один свежий корпус до настройки; RP263 holdout уже просмотрен. Сравнить lexical/dense/hybrid при одинаковой ёмкости, полноту нескольких источников, wrong-first/unknown controls, затем real whole-prompt admission. Не подключать текущий dense/RRF и не повторять RP239–263. RP-05 остаётся открытым. Git main e8f5cba; RP256–263 локальны, push не запрошен.

## Предыдущий этап RP262

RP262: независимый замер поиска по смыслу и ограниченная форма вопроса о данном слове. 40 RU/EN запросов, 96 поздних обсуждений, вручную заданные источники; прежний выбор и top3 сохранены в tests/fixtures/story-semantic-baseline.json. Прямые запросы 16/16→16/16, перефразы 4/8→6/8, неверный первый кандидат среди перефразов 4→2, полный набор для общих ссылок 3/8→3/8. 8 контролей сохраняют прежний состав/порядок. Это проверка локального подбора, не качество модели.

Основная форма вопроса в story-owner-query.ts: ограниченное «данное Норой Мире слово» / “Nora’s word to Mira” использует прежнее ранжирование по source-bound promisor. Оба названных человека должны разрешаться однозначно; получатель не становится владельцем или отдельным фильтром. Исторические ID/версия V1/условия/статусы/бюджет/канонические данные не менялись. Нет нового словаря подарков, настроек, скачивания весов или дополнительных сетевых запросов. Исходная фикстура English recipient превышала возможности V1; исправлена фикстура без изменения источниковой грамматики. Контроль неоднозначного получателя тоже исправлен на фактически употреблённое имя/прозвище. 105 новых unit-проверок, включая 16 для коротких имён; финальные общие проверки ниже. [Примеры и пределы](SEARCH-QUALITY.md).

По дополнительному запросу пользователя сразу исправлены короткие русские имена в текущем поиске: query-only retrievalQueryNames достраивает регулярные формы трёхбуквенных имён/прозвищ на а/я, включая Ева→Евой/Еве и Аня→Аней/Ане, в том числе однозначную короткую форму полного имени. storyRetrievalQuery и storyOwnerQuestion используют новые формы; V1 source reader продолжает использовать прежнюю retrievalNames. Проверены коллизии, чужой мир, замена человека, целый исходный запрос и неизменные исторические source IDs. Это не пересмотр сохранённых источников и не общее склонение всех русских имён.

RP262 QA: 105 новых unit-проверок. Перед дополнительной правкой коротких имён весь unit-набор пройден двумя запусками: 4972 основной + 24 batch = 4996 passed / 0 failed / 5 прежних todo. После query-only расширения: 17 связанных файлов, 701 passed / 0 failed, включая новый 16-case short-name набор, все owner/source/retrieval/reference/long-history корпуса; независимый Semantic40 остаётся 16/16 direct, 6/8 paraphrase, 3/8 ambiguous, 8 exact controls. TypeScript/diff-check прошли. Первый общий запуск дал 4994 passed / 2 timeout (batch100 и повторный синхронный goal48); оба файла отдельно 73/73. Goal-сводка теперь использует готовые результаты тех же 48 проверок, batch24 прошёл отдельно при прежнем 5s лимите. Производственные проверки/таймауты не ослаблены.

Финальный выбранный браузерный набор после исправления Ева→Евой: 32 passed / 8 намеренных installed-Firefox skips. Synthetic Edge RU/EN actual POST проверил nominal word до и после переименования в Еву/Eva и перезагрузки: сохранённый promisor ID/sourceName, исходный запрос, неизменные факты, исключённую альтернативу, 7 явных отправок на язык, отсутствие лишних вкладок/ошибок. Context-budget UI: Chromium/Firefox RU/EN 320/900, keyboard/overflow/scoped Axe. Исходный браузерный запуск (31/8/1) выявил короткое имя; промежуточный rename Елена прошёл 32/8, затем пользователь попросил исправить ограничение сразу. Изменение сделано только для current-query forms; замена персонажа/коллизии/историческая V1-грамматика проверены. Живой аккаунт/DeepSeek/Brave/полный E2E не проверялись; свои контексты закрыты. RP262 packages: Chrome/Firefox/sources ZIP SHA256 entry-to-disk audit 23/23/580 files; all 3 canonical download copies match, no dated duplicates. Current source includes SEARCH-QUALITY and first RP262 handoff; tests/private data/.env/Git/node_modules/nested ZIPs excluded. Source repacked after final QA/package notes. Existing >500KB chunk warning remains RP-08. Installed extension was not replaced or reloaded automatically.

Следующий конкретный шаг RP-05: отдельный прототип смыслового поиска кандидатов и сравнение с frozen RP262 baseline плюс новые holdout-примеры до настройки алгоритма. Не добавлять словарь под каждый подарок/спасение. Сначала проверить пользу, неверный приоритет, передачу всех альтернатив, задержку и размер/работу без сети; затем выбрать внедрение. В этой итерации векторная модель не сравнивалась и не подключалась. Не скачивать веса и не отправлять библиотеку новому сервису без пользовательского выбора. Разработчик выбирает модель сам, пользователь не должен выбирать техническую модель. Источники/владельцы/актуальность/целый бюджет остаются за текущим компилятором. RP-05–08, постоянные ID предметов, произвольные местоимения, масштаб и живая проверка остаются открыты. Не переделывать RP239–262. Личный мир/установленная копия не менялись; main e8f5cba, RP256–262 локально, commit/push не запрошены.

## Предыдущий этап RP261

RP261 fixes partial priority of independent same-label alternatives. storyReferenceCandidates retains all eligible source-bound open duties and persistent details for the literal group, and rejects the extra lane if a matching CURRENT task/persistent record is unavailable or unproved. Unified compiler admits every whole candidate plus recent anchor within cap8/rendered budget, or resets facts/omission/attempted/protected sets to guarded fallback exactly. A shared label is explicitly NOT an object ID; sources/owners/places/codes/conditions remain separate. Exact single-object literal collisions across current independent task slots get their own guard; the existing draft fact ranking/compaction was moved before guard costing; recent-context ranking remains separate. Supported special goals/compound actions retain their rules. No canonical/schema/settings/model/provider/DB/object-ID changes; drafts, source provenance and currentness unchanged. referenceBundle:false is a private prior-selector comparator.

Fixed independent34 RUEN corpus,300 newer scenes per fixture: whole target sets0/10→10/10; incomplete extra priority20→0;8 normal recall and16 guarded fallback cases. Code replacement, completed/cancelled tasks, explicit Day4→20 and earlier temporary circumstances checked separately.69 new unit cases; focused4 files159 pass/TypeScript pass. Initial bare-key wording correctly blocked the old lane; a semantically equivalent different-objects phrasing exposed partial priority, while the bare-object case remains a fallback control. Extra workshop source initially had a speaker instead of its explicit promisor; fixed the fixture, not evidence policy. Large synchronous rollups were split into per-scenario/budget checks without changing production/native timeouts. Final QA/packages follow below. RP256–260 local work preserved; no push requested, main e8f5cba; personal world/installed copy untouched.

RP261 final QA:69 new unit cases; full251 files4907 passed/0 failed/5 prior todo; final TypeScript/diff-check passed. Fixed34 RUEN corpus uses300 later scenes: target-set0/10→10/10 and incomplete extra priority20→0,8 normal and16 guarded-fallback cases. Broad browser98 passed/26 intentional installed-Firefox skips; first new-only10 passed/2 such skips. Actual synthetic Edge RUEN POST/reload starts with an open copper duty, accepts its completed result and replaces old code1133 with current4926;56 stored current facts/role seeds/selected source order remain identical after reload,24 explicit sends per locale/no extra tabs/errors. Source alternatives stay separate in the intercepted prompt for both this-key and literal blue-key requests; source roles/conditions/current claims/time status preserved, no old code record resurrected. Native fixture uses48 later scenes and configured6000 budget; unit checks1500–4300 verify exact guarded fallback and whole cap. Chromium/Firefox RUEN320/900 keyboard/scoped Axe/overflow,4 screenshots inspected. Initial full run cancelled after extending literal-label coverage, then final complete suite rerun. After test-only metric/cancellation-evidence refinements, focused quality35/35 rerun passed; production code unchanged. Test rollup and budget loops split per scenario, no production/native timeout or evidence guard relaxation. Live model/account/Brave/full E2E not tested; own contexts closed.

Next concrete RP-05 task: an independent semantic-search comparison for medallion/promise/alias/old event requests with source/owner gold, missed-evidence and wrong-priority metrics. Compare against the current local lexical selector before choosing another implementation. Do not install a heavy model, download weights or transmit the library without user choice; external quality/cost/offline behavior need explicit handling. Object IDs/pronoun resolution/incremental indexing/inter-turn reinforcement and RP-06–08/old-chat rewind/live quality remain open. Do not redo RP239–261. Only3 canonical downloads; installed copy update/reload stays manual.

RP261 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/579 files and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff RP261. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads and no dated duplicates. Existing >500KB chunk warning stays RP-08. Installed browser copy was not automatically replaced/reloaded.

## Предыдущий этап RP260

RP260 adds explicit unresolved-reference guards for ordinary personal references, not just topic questions. Finite single-action this/that references may reserve a whole recent accepted anchor plus one eligible source-owned open duty and matching persistent detail. Qualified labels reuse storyTaskObject; the full latest scene must contain the exact accepted anchor quote, agree with its text on ONE label, and have every bare-object occurrence inside that same label. Unknown/unbound/other bare objects also block narrowing. Missing/edited quote/selected source, ambiguous names, unavailable IDs, reference-only/restart and incomplete whole budget retain fallback. Whole selection/omission/attempted/protected-set rollback; guard remains required. No pronoun binding, ownership/knowledge transfer/consent/permission/completion inference, schema/settings/model/provider/DB/canonical writes. Current historical IDs and original draft/source conditions remain. referenceRecall false/guard are private comparators; source title extraction is shared with natural recall.

Independent40 RUEN corpus: guard coverage0/20→20/20, whole source target sets0/6→6/6,20 exact controls. Initial21 failing assertions reproduced missing guards and wrong object recall.83 new unit cases pass; full/native/browser/package checks follow below. Core story-reference-recall/game-context/shared title helper; fixture/quality/reader/runtime/UI; OBJECT-REFERENCES.md. RP256–259 local work preserved, no push requested, main e8f5cba; personal world/installed copy untouched.

RP260 final QA:83 new unit cases; full249 files4838 passed/0 failed/5 prior todo; TypeScript/diff-check passed. Independent40 corpus guards0/20→20/20 and whole-target0/6→6/6 with20 exact controls. Broad browser88 passed/24 intentional installed-Firefox skips; separate new-only10 passed/2 such skips. Actual synthetic Edge RUEN POST/reload preserves41 accepted facts/frozen role seeds/episode-source order;19 explicit sends per locale, no extra tabs/errors. Both unresolved-personal guards and unique qualified source-owned task/code conditions appear on wire, full original draft retained. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and four screenshots inspected. Initial missing scaffold markers and one misplaced branch brace were fixed before broad checks; no source/evidence/budget/lifetime/identity/timeouts weakened. No canonical writes or extra model requests. Live account/model/Brave/full E2E not tested; own contexts closed.

Next corpus must also include two distinct objects with the same full literal label: a label is not an object ID. Current priority is candidate recall with a retained unresolved-reference guard, not disambiguation or a binding. Measure false priority separately before introducing object identity or widening grammar.

Next: evaluate RP-05 retrieval quality on a fixed mix of real-shaped long scenes before another grammar expansion; record missed evidence and false candidate priority separately. Personal/pronoun ownership remains unresolved locally; standalone deictic knowledge without an eligible title and arbitrary language remain open. RP-05–08/calendar/overdue/scale/live-model quality/old-chat rewind/UX onboarding/editors remain open. Do not redo RP239–260. Only3 canonical downloads; installed copies require manual update/reload.

RP260 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/578 entries and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff RP260. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads, no dated duplicates. Existing >500KB chunk warning remains RP-08. Installed browser copy was not replaced/reloaded automatically.

## Предыдущий этап RP259

story-lasting-recall.ts supplements existing balanced selection with whole accepted persistent knowledge and completed/cancelled task results, without requiring an open task title. Finite present/past query clauses reuse storyActionBalance; raw object tokens preserve stop-word/name barriers. Ordered one-clause text/title matching, no quote/key/claim-value tags. Persistent candidates retain frozen active speaker/believer + selected-source + lifetime proof; closed tasks require a bound active reporting speaker and selected source, never become open or persistent. Latest current compacted sources; recent anchor, cap8/full rendered budget and exact prior facts/counters/attempted/task/persistent-set rollback. No schema/settings/model/provider/DB/canonical writes; full draft/conditions/source identities remain. Local shared noun lexicon and ephemeral action.object only. Existing RP256–258 local work preserved.

RP259 final QA:83 new focused unit cases pass; full247 files4749 passed/0 failed/5 prior todo, followed by6 additional passing cap/identity/stop-word cases (4755 distinct passing cases across these checks). Final TypeScript/diff-check and documentation7 pass. Independent48 RUEN whole-target5/16→16/16 with32 exact controls. Broad browser78 passed/22 intentional installed-Firefox skips; separate first new-only run10 passed/2 such skips. Synthetic Edge RUEN actual POST/reload preserves44 stored facts/frozen role seeds/source order,27 explicit sends per locale, no extra tabs/errors. Native ingestion starts with an open key duty, then accepts its completed result; status/quote/owner/source and persistent permission conditions remain whole. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe, four screenshots visually inspected. Production source/identity/lifetime/budget/timeouts unchanged. Initial runtime generation marker/type errors corrected in test scaffolding, no production guard relaxation. Live account/model/Brave/full E2E not tested; own contexts closed.

Concrete next task: prepare an independent RUEN corpus with two same-kind objects, renamed/deleted/replaced identities, and possessive/deictic references (её/этот, her/this). Compare current selection against fixed whole-source gold; unresolved referents must retain fallback. Identify a measured gap before changing retrieval; do not append another broad regex or infer possession/knowledge from a reporting speaker.

Next: independently measured broader phrasing and identity/pronoun comparison before widening lexical forms. No universal semantics, inferred object possession/knowledge transfer or guessed owner. RP-05–08 remain open, including calendar/overdue, scale/live-model quality, old-chat rewind and UX onboarding/editors. Do not redo RP239–259; personal lore/installed copy untouched. No commit/push requested; main remains e8f5cba. Only3 canonical archives. Final QA/packages: current CODEX-HANDOFF.md and ROADMAP.md.

Начните с AGENTS.md, текущего верхнего раздела CODEX-HANDOFF.md и ROADMAP.md. Этот файл — передача работы, а не разрешение сбросить личный мир пользователя.

RP259 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/576 files and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff section RP259. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads, no dated duplicates. Existing >500KB chunk warning stays RP-08. Installed browser copy was not replaced/reloaded automatically.

## Предыдущий этап RP258

Обычные сообщения больше не требуют уложиться в2–3 действия для дополнительной предметной памяти. story-natural-recall uses literal eligible open-task title anchors, source-owned whole conditions/IDs and all recognized objects within cap8/full budget. Conditional/negative prose stays full query, never performed-event proof; ambiguous personal references remain unresolved. Legacy supported paths preserved; local3 noun-form groups, no global stemming/schema/DB/model calls. Independent50 corpus7/18→18/18,32 exact controls,111 new unit/full4672 pass/5 prior todo/TypeScript. RP258 final QA:111 new unit cases; full245 files4672 passed/0 failed/5 prior todo, TypeScript/diff-check. Independent50 corpus7/18→18/18 whole-target recall with32 exact controls, no changed gold. Browser68 passed/20 intentional installed-Firefox skips; synthetic Edge RUEN actual POST/reload retains45 facts/frozen role seeds/source order,22 explicit sends per locale, no extra tabs/errors. Four+ actions/>480-character input/conditions/negation sent verbatim, all conditional duties and persistent direct-speech quote/source IDs remain. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and4 screenshots inspected. First2 native failures came from a fixture without a parser-supported named knowledge quote; replaced with explicit named direct speech and added2 actual source-role grammar checks. Production identity/lifetime/evidence/timeouts unchanged. Prior compound runtime now explicitly expects supplemental object recall for conditional/multiline prose, with whole draft/quote/open statuses; old compound parser itself still rejects those forms. Live account/model/Brave/full E2E not tested; own contexts closed. RP256–257 local changes retained; no push requested or personal world/installed-copy changes.

Следующее: опорные предметы из самостоятельных длительных сведений без открытого дела; независимые естественные RUEN/identity/pronoun примеры перед расширением. Текущий механизм не universal NLP; literal title prefix/noun table and ambiguous ownership limits explicit. RP-05–08/old-chat rewind/UX onboarding/editors open. RP239–258 не повторять. Only3 canonical downloads.

RP258 packages: Chrome/Firefox/source ZIP SHA25623/23/574 entries match build/source bytes and all3 canonical copies. Final source repacked after QA/package notes, first handoff section is RP258. Private/test/.env/Git/nested ZIP exclusions verified; no dated duplicates. Existing >500KB chunk warning remains RP-08. User-installed extension not reloaded; update/reload remains manual.

## Предыдущий этап RP257

Завершён ограниченный подбор для2–3 разных предметов в составном действии/цели. Источники, владельцы, условия и целые цитаты обязательны для каждой части; при любой неудаче прежние результаты/счётчики. Память не отключается, события/статусы не переписываются. Core story-compound-action/game-context/action orderedTerms; quality/parser/native runtime/UI и COMPOUND-ACTIONS.md. Локальная работа RP256 сохранена. Финальная QA — верхний CODEX-HANDOFF/ROADMAP. Final QA:113 new unit cases; full243 files4561 passed/0 failed/5 prior todo, TypeScript/diff-check. Independent48 complete-target0→16/16 with32 exact controls. Additional RUEN valid long>240 requests preserve all3 whole conditional duties; valid-schema whole-budget tests and duplicate/name/cross-field guards pass. Broad browser58 pass/18 intentional installed-Firefox skips; final rebuilt repeat46 pass/6 such skips after the newline-prefix guard. RUEN actual Edge POST/reload preserves43 stored facts/role seeds/source order,20 explicit sends per locale/no extra tabs/errors. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and4 screenshots inspected. No product evidence/scope/timeouts relaxed; own contexts closed. Live account/model/Brave/full E2E not tested. Личный мир/installed copy не менять; новый commit/push не запрошен.

Следующее: независимый естественный RUEN corpus для падежей коротких предметов и более сложных явных фраз. Сначала измерить ошибки и fallback, затем расширять только подтверждённые случаи; не угадывать условия/местоимения/владельцев. RP-05–08 и UX onboarding/editors открыты. RP239–257 не повторять.

Пакеты RP257: Chrome/Firefox/source SHA25623/23/572 файлов и canonical копии проверены, source повторно упакован с финальными заметками. Только3 актуальных downloads; chunk-size warning остаётся RP-08. Первый раздел CODEX-HANDOFF — текущий RP257; архивные RP256 и ранее ниже.

## Предыдущий этап RP256

RP256 после pull e8f5cba и «го»: подбор нескольких дел по явной короткой цели. Repair/return/delivery RUEN syntax; минимум2 source-bound open duties с владельцами из текущего состава/фокуса. Только ordered literal object prefix после goal action в task.title; старый и новый источник получают до2 целых мест вместе с недавней сценой. Conditions/status/quotes/IDs сохраняются, время не означает urgency/fulfillment. One/unknown/unsupported/quoted/conditional/compound requests retain old selection. Files story-task-goal/game-context/helper, quality48 и новые UI/native runtime. QA записана в верхнем CODEX-HANDOFF/ROADMAP; не повторять завершённые RP239–255. Личный мир не сбрасывать. Commit/push не запрошены.

RP256 final QA: full241 files4448 pass/0 fail/5 prior todo, TypeScript/diff-check, browser48 pass/16 intentional installed-Firefox skips и4 inspected RUEN320/900 screenshots. Synthetic Edge whole old/new duty actual POST/reload preserves32 stored facts/roles/source order; no extra model tab, no canonical edits. Chrome/Firefox/source SHA25623/23/570 entry/canonical-copy audit; only3 downloads. Live account/model/Brave/full E2E not checked; installed copy needs manual update. Next long/compound syntax corpus, do not redo RP239–256.

Предыдущий RP255 завершён и опубликован в e8f5cba: no main draft gate for isolated illustrations, model-specific total-prompt limits, catalog→plan instruction, own-boilerplate compaction, local preflight/no paid retry and numeric RU/EN diagnostic. Full239 files4342 passed/5 todo/TypeScript passed; browser/package results в историческом RP255 handoff/roadmap. Module image-prompt-budget and native image-prompt-limit E2E; preserve askSelfie/native service draft protection and frozen old retry. User accounts/data not touched; не повторять исправления.


RP254 добавляет ограниченный подбор для коротких действий первого лица «Я открываю дверь», «Я киваю», `I open the door`, `I nod`, включая запись между звёздочками. Предмет должен совпасть всеми значимыми словами в одном text/title; сохраняются целые recent anchor/direct target и до одного matching open task/persistent detail. Frozen role IDs/selected sources/lifetime и whole-budget rollback прежние. I не назначается владельцем; цитата, ключ, похожее имя, получатель обещания или code не являются доказательством предмета/владения/разрешения/выполнения. Unsupported/compound/quoted/negated/conditional/pronoun-owner syntax и direct topic/owner questions сохраняют прежний путь. Без настроек, новых model calls и записи в канон. Fixed48:24 positives/24 exact controls, full target recall0→24/24,126 новых unit cases; финальная QA (237 unit files/4310 passed/5 прежних todo,38 browser passed/14 installed-Firefox skips) и пакеты в текущем handoff/roadmap. Инструкция docs/ACTION-MEMORY.md; src/core/story-action-balance.ts/game-context.ts и отдельные tests/e2e/fixtures. Не повторять RP239–254.

RP253 исправляет подготовку полного сброса: отдельные подписи служебного окна, точный существующий roster вместо открытия новых лиц, корректная однократная entry correction и понятная ошибка проверки. Два ручных подтверждения и защита исходного лора/изображений сохранены. QA и пакеты читать в текущем handoff/roadmap. Личный мир пользователя не сбрасывать. Два сценария restart/reset пока не объединены; вопрос пользователя не означает разрешение удалить одну функцию.

RP252 добавляет bounded balance для распознанной короткой просьбы «Продолжай»/Continue, в том числе с известным именем. Whole recent-context anchor, до одного fitting open task и persistent detail; exact frozen role/current IDs/selected lineage required. Source order не urgency/calendar, recipient не owner, speaker не proof of hearing/knowledge transfer. Unknown proof остаётся fallback. Если дополнительная целая lane не вошла, прежние selection/counters; required/manual lore intact. Optional lasting-detail reason в существующем RUEN preview, no setting/model call/schema write. Fixed48:24 positives/24 unchanged controls, full target-set recall0→24/24. Короткие ordinary actions подключены отдельно в RP254, не для любого текста.

Основные файлы текущего этапа: src/core/story-continuation-balance.ts, game-context.ts, context-budget-i18n.ts и ContextBudgetSummary; tests/story-continuation-quality/balance, fixtures/story-continuation-quality, context-explanation и расширенные e2e/story-content-relevance-runtime/context-budget-ui. Инструкция: docs/CONTINUATION-MEMORY.md. Итоговые проверки и архивы — в текущем CODEX-HANDOFF/ROADMAP и day log2026-10-14. RP239–252 не повторять. Полный сброс мира уже реализован с двумя подтверждениями; агенту нельзя сбрасывать личный мир. Личная библиотека и аккаунт пользователя не менялись.

Проверки используют фиксированный RU/EN корпус и изолированные браузеры. Installed Edge получает вымышленные страницы и реальный перехваченный POST; это не проверка живой модели/аккаунта. Установленное пользователем расширение нужно обновить и перезагрузить вручную. Исходные факты, лор, возраста, цитаты и изображения сохраняются. Подробные числа QA читать в текущем верхнем handoff.

## Что уже сделано для длительного ролплея

- RP223–237: обработка сцен порциями, статусы задач/обещаний, общий бюджет запроса, защита отправки и поздних ответов, локальный подбор памяти, компактный протокол.
- UX238: четыре основных раздела и понятное оглавление настроек. Первый запуск и редакторы ещё не полностью переработаны.
- RP239–242: явно названные роли, сохранённые исторические ID и цитаты, вопросы о владельцах обещаний, точная пара запроса/ответа и поздние квитанции без дубликатов.
- RP243: восемь локальных RU/EN групп перефразирования действий. Это ограниченный словарь, не универсальный семантический поиск.
- RP244: пересчитываемые сводки из принятых фактов по 12 реплик с точными источниками. Это порядок записанных сцен, не сюжетные главы.
- RP245: явные метки игрового времени и временные/постоянные состояния. Нет вычисления календаря или автоматического закрытия обещаний от прошедших дней.
- RP246: явно сыгранные завершения временных обстоятельств, возобновление и защита от устаревших описаний.
- RP247: отдельная подготовка полного сброса мира, редактируемый план/два подтверждения, атомарный архив и новая игра в чистом чате.
- RP248: пересчитываемый краткий текст эпизода из целых цитат и переходы к источникам; независимый корпус48 RU/EN сценариев. Исходные факты и outgoing memory прежние.
- RP249: обратимая request-local упаковка metadata/value/person refs с оплатой всей легенды; два одинаковых mixed eight-fact requests меньше на11,6%/12,0% по символам. Native tokenizer/live interpretation не измерены; неизвестное остаётся неизвестным.
- RP250: bounded topic relevance из whole fact text/task title, excluding names/framing/actions, frequency rebuilt each request; fixed48 corpus24→48/48 и installed actual old-topic/terminal-title/reload. Не inference или broad semantic understanding.
- RP251: conditional topic-only fact admission, whole-budget coverage/rollback, shared-topic open tasks; fixed48 admission corpus и actual compound/owner/unknown/continuation next POST/reload. Не ограничивает библиотеку и не сжимает native transcript.
- RP252: ограниченные short-continuation lanes для недавнего anchor/owned open task/lasting source, точные источники/ID/бюджет и причина lasting selection. Fixed48/installed POST/reload/RUEN narrow UI; arbitrary narrative actions не подключены.
- RP253: отдельные reset плашки, exact existing roster и entry repair, strict complete JSON; две ручные проверки и защита личного мира сохраняются.
- RP254: ограниченные одиночные действия первого лица и жесты, whole object coverage/filter, source-bound task/lasting lanes и точный budget rollback. Это не свободный интерпретатор действий.

Один лор имеет одну актуальную игру, сохраняемую между чатами. Возврат в старый чат не перематывает историю. Исходный лор, возраста, изображения и точные цитаты сохранять. Исторические «следующие задачи» в старых разделах не повторять.

## Следующая реализация RP-05

Короткие обычные действия RP254 и первый измеренный выбор нескольких дел RP256 уже реализованы; не повторять их corpus. Следующий участок — независимый RUEN corpus длинных и составных действий/целей: несколько явно названных предметов, последовательность и условия; сначала измерить пропуски и опасные ложные совпадения. Third-person остаётся отдельным расширением без вывода владельца из текста запроса. Не включать lanes для любого текста и не угадывать intent/owner/fulfillment. Latest/oldest source не равен важнейшему или просроченному делу. Narrated persistent facts без frozen speaker/believer не спасаются этой lane; historical repair не делать через fuzzy names. Source/role/time/scope/whole budget прежние; heavy/external provider молча не подключать.

Не сохранять вторую самостоятельную память, не обрезать цитаты ради метрики и не заменять unknown догадкой. Compact transport реализован; не повторять его и не выдавать экономию выбранной добавки за сокращение native transcript или универсальное понимание лора.

Отдельная измеренная граница прежнего lexical topic search: русское «коде» не совпадает с коротким «код» (stemmer не сокращает слова короче5). «Напомни код» работает. Native action runtime проверяет оба поведения; RP254 не меняет global stemming. Возможное расширение коротких форм делать по независимому RU/EN collision corpus, не общим отрезанием последней буквы.

РП-05–08 остаются открытыми: широкое семантическое извлечение, качество связных сводок, произвольные условия окончания/календарь/просрочка, масштаб и сопровождение реального сайта. Historical identity repair, полноценная перемотка старых чатов и UX-02 отложены. Новый внешний provider или тяжёлая модель не подключаются молча. Не обещать бесконечное собственное окно контекста DeepSeek.

## Проверка на другом компьютере

Используйте доступный локальный Node; стандартные npm-скрипты проекта и AGENTS.md. Для сброса есть world-reset*.test.ts/tsx, e2e/world-reset-ui.spec.ts и e2e/world-reset-runtime.spec.ts; для RP предыдущие story-episode/source-role/paraphrase/late-dispatch tests. Изолированные профили тестов не являются пользовательским профилем Edge. Текущие рабочие отчёты и вспомогательные private-assets scripts не входят в Git.

Не запускать тяжёлый полный unit-набор вместе с пересборкой или installed-browser тестами. Проверять RU/EN, узкую/широкую панель, клавиатуру/Axe, затем Chrome/Firefox/source ZIP и точное содержимое пакетов. Если порт 4173 занят другим приложением, выбрать отдельный порт, не останавливать чужой процесс. Сборка не перезагружает установленное расширение сама. После следующей итерации обновить этот файл и основной handoff.
