import {spawn} from 'node:child_process';
import {readFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {FORMAT,noLinks} from './isolation.mjs';

// node_repl intentionally has no global process. Keep OS/process ownership in
// the normal Node worker; expose the same constrained UI methods over stdio.
export class DeepRoleBrowser{
 #configPath;#config;#child;#starting;#pending=new Map();#next=0;
 constructor(configPath){noLinks(configPath);this.#configPath=configPath;this.#config=JSON.parse(readFileSync(configPath,'utf8'));if(this.#config.format!==FORMAT||!this.#config.nodeExecutable||!existsSync(this.#config.nodeExecutable))throw Error('Browser configuration has no verified Node executable');}
 async #ensure(){
  if(this.#starting)return this.#starting;if(this.#child)return;
  this.#starting=new Promise((resolve,reject)=>{
   const child=spawn(this.#config.nodeExecutable,[fileURLToPath(new URL('./worker.mjs',import.meta.url)),this.#configPath],{windowsHide:true,stdio:['pipe','pipe','pipe']});this.#child=child;
   let buffer='',errors='',ready=false;const timeout=setTimeout(()=>reject(Error('Browser worker did not become ready')),10000);
   child.stderr.setEncoding('utf8');child.stderr.on('data',chunk=>{errors=(errors+chunk).slice(-3000);});
   child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{
    buffer+=chunk;if(buffer.length>24*1024*1024){child.kill();return;}let end;
    while((end=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,end);buffer=buffer.slice(end+1);let response;try{response=JSON.parse(line);}catch{continue;}
     if(response.ready){ready=true;clearTimeout(timeout);resolve();continue;}
     const pending=this.#pending.get(response.id);if(!pending)continue;this.#pending.delete(response.id);clearTimeout(pending.timer);response.error?pending.reject(Error(response.error)):pending.resolve(response.result);
    }
   });
   const ended=()=>{clearTimeout(timeout);if(this.#child!==child)return;this.#child=undefined;if(!ready)reject(Error('Browser worker failed: '+errors));for(const p of this.#pending.values()){clearTimeout(p.timer);p.reject(Error('Owned browser worker closed; inspect before repeating any action'));}this.#pending.clear();};
   child.once('error',ended);child.once('exit',ended);
  }).finally(()=>{this.#starting=undefined;});return this.#starting;
 }
 async #call(method,args){
  await this.#ensure();const child=this.#child;if(!child)throw Error('Browser worker is not connected');const id=++this.#next;
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.#pending.delete(id);reject(Error('Browser action result is unknown; inspect before retrying'));},25000);this.#pending.set(id,{resolve,reject,timer});child.stdin.write(JSON.stringify({id,method,args})+'\n',error=>{if(error){const p=this.#pending.get(id);if(p){clearTimeout(p.timer);this.#pending.delete(id);reject(error);}}});});
 }
 start(){return this.#call('start',[]);}status(){return this.#call('status',[]);}tabs(){return this.#call('tabs',[]);}
 open(url){return this.#call('open',[url]);}openDeepRole(){return this.#call('openDeepRole',[]);}inspect(tabId){return this.#call('inspect',[tabId]);}screenshot(tabId){return this.#call('screenshot',[tabId]);}
 act(input){return this.#call('act',[input]);}grantFile(path){return this.#call('grantFile',[path]);}navigate(tabId,action,direction){return this.#call('navigate',[tabId,action,...direction?[direction]:[]]);}
 restart(){return this.#call('restart',[]);}openManualLogin(){return this.#call('openManualLogin',[]);}returnToBackground(){return this.#call('returnToBackground',[]);}
 async close(){if(!this.#child&&!this.#starting)return;const child=this.#child;await this.#call('close',[]);if(child){child.stdin.end();await new Promise(resolve=>{if(child.exitCode!==null){resolve();return;}child.once('exit',resolve);});}}
}
