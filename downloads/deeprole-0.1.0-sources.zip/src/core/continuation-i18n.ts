import type { Locale } from "./types";

export function continuationPickerText(locale: Locale) {
  return locale === "ru" ? {
    intro: "Выбери, откуда взять сцену для нового чата.",
    review: "Сначала сверить переписку",
    reviewDetail: "Подходит, если последние события ещё не сохранились. DeepSeek сверит доступную переписку с памятью. После проверки DeepRole откроет новый чат и сам отправит первую реплику.",
    saved: "Взять последнее сохранение",
    savedDetail: "Откроется последнее сохранение без запроса в старый чат. Сначала посмотри сцену: более свежие события могли ещё не сохраниться. В новом чате первую реплику отправишь сам.",
    savedUnavailable: "Продолжение из сохранённой памяти сейчас недоступно.",
    reviewUnavailable: "Сверка переписки сейчас недоступна.",
    back: "К выбору способа",
  } : {
    intro: "Choose where the new chat should get its starting scene.",
    review: "Review the conversation first",
    reviewDetail: "Use this if the latest events have yet to be saved. DeepSeek compares the available conversation with memory. After review, DeepRole opens a new chat and sends the first message.",
    saved: "Use the latest save",
    savedDetail: "Uses the latest save without contacting the old chat. Preview the scene first. Newer events may be missing. You send the first message in the new chat.",
    savedUnavailable: "Continuing from a save is currently unavailable.",
    reviewUnavailable: "Conversation review is currently unavailable.",
    back: "Back to transfer options",
  };
}

export function continuationActions(locale: Locale) {
  return locale === "ru" ? {
    title: "Перенос игры и пересказы",
    transfer: {
      detail: "В окне выбора можно сверить переписку или взять последнее сохранение.",
      example: "Если разговор у маяка уже виден в сохранённой сцене, можно перенести её и написать следующий ход. Если разговор ещё не сохранился, сначала сверь переписку.",
    },
    recap: {
      label: "Сохранить пересказ на потом",
      detail: "DeepSeek подготовит пересказ. Ты останешься в текущем чате.",
      example: "Сохрани пересказ встречи у маяка. Позже открой чат с тем же миром и нажми «Применить» у пересказа. Он добавится к следующей реплике один раз.",
    },
  } : {
    title: "Game transfers and recaps",
    transfer: {
      detail: "Choose whether to review the conversation or use the latest save.",
      example: "If the saved scene already shows the conversation at the lighthouse, move it over and write the next turn. If the conversation has yet to be saved, review it first.",
    },
    recap: {
      label: "Save a recap for later",
      detail: "DeepSeek prepares a recap while you stay in the current chat.",
      example: "Save a recap of the lighthouse meeting. Later, open a chat with the same world and select Apply on the recap. It is included once, with your next message.",
    },
  };
}

const copy = {
  ru: {
    unconfirmedTitle: "Перенос не подтверждён",
    sendUnconfirmed: "Перенос пока не подтверждён. Перед повторной отправкой проверь ответ DeepSeek.",
    returnUnconfirmed: "Первую реплику ещё не удалось подтвердить. Её текст сохранён до закрытия вкладки. Вернитесь в чат попытки и проверьте ответ перед повторной отправкой.",
    returnMessage: "Вернуться к реплике",
    checkReply: "Проверить ответ DeepSeek",
    checkingReply: "Проверяем ответ…",
    cancelRecovery: "Отменить перенос и убрать черновик",
    commitTitle: "Нужно завершить сохранение переноса",
    commitPending: "DeepSeek принял реплику. Осталось сохранить перенос на этом устройстве.",
    commitSaving: "Сохраняем перенос на этом устройстве…",
    commitRetry: "Завершить сохранение переноса",
    commitFailed: "Сохранение пока не завершено. Проверьте доступность хранилища и попробуйте снова. Если игра изменилась в другом чате, вернитесь в актуальный чат.",
    title: "Продолжение истории", hint: "Сначала DeepSeek сверит историю с памятью. Подтвердите нужные изменения — затем подготовится скрытая сжимка последних сцен и откроется новый чат. Лор, портреты и прогресс остаются в том же мире.",
    detail: "Сжимка передаётся в контексте первого запроса; в чате видна только просьба продолжить. Недоступные события не додумываются. Старый чат остаётся доступен.",
    analysis: "1/3 · Сверяем историю с памятью…", review: "2/3 · Подтвердите изменения памяти",
    reviewAction: "Проверить изменения", readyToSummarize: "2/3 · Память актуальна",
    startSummary: "Подготовить сжимку и продолжить", summary: "3/3 · Сжимаем последние сцены…",
    summaryArchived: "Служебный запрос переноса истории", summaryFailed: "Сжимка не завершена. Перенос остановлен.", summaryDone: "Сжимка готова. Открываем новый чат…", cancel: "Отменить перенос", cancelled: "Перенос остановлен.",
    reviewHint: "Можно продолжить с текущей памятью или сохранить выбранные записи. Затем DeepSeek подготовит краткое содержание и откроется новый чат. Если закрыть окно, перенос встанет на паузу.",
    keepMemory: "Продолжить без изменений памяти", saveContinue: "Сохранить и продолжить", tooLarge: "Весь лор не помещается в запрос на сверку. Откройте «Продолжить в новом чате» и выберите «Взять последнее сохранение».",
    continuePrompt: "Продолжи игру с того же момента по переданному контексту последних сцен. Сохрани язык и стиль переписки. Не повторяй пересказ, не выбирай за игрока и не разыгрывай заново завершённые события.",
    saved: "Состояние сохранено", creating: "Сохраняем историю…", continue: "Продолжить в новом чате", recap: "Подготовить пересказ с DeepSeek",
    ready: "Сначала сохраните или отправьте черновик, затем повторите перенос. Черновик не изменён.",
    failed: "Перенос не завершён. Старый чат доступен, подтверждённые изменения памяти сохранены. Попробуйте ещё раз.",
    partial: "Часть переписки не вошла. Лор и прогресс сохранены; полная переписка остаётся в исходном чате.",
    history: "История получена из чата", page: "Только доступные на странице сообщения", source: "Открыть исходный чат",
    warnings: "Предупреждать о заполнении чата", warningHint: "Приблизительно при 90% и 97% выбранного объёма — один раз на каждом уровне для этого чата. Сообщения не блокируются.",
    capacity: "Ориентировочный объём чата, токенов", capacityHint: "Это ориентир для индикатора и предупреждений, не лимит подключённой памяти. DeepSeek может иметь другой предел.",
    warning: "Чат близок к заполнению", critical: "Места в чате почти не осталось",
    warningBody: "По нашей оценке, история занимает около {percent}% выбранного объёма. DeepSeek может перестать принимать продолжение. Лучше перенести историю заранее.",
    uncertain: "Это приблизительная оценка, не сообщение от DeepSeek. Точное число оставшихся сообщений неизвестно.",
    notNow: "Продолжить здесь", disable: "Не предупреждать", waiting: "Дождитесь завершения ответа — тогда можно перенести последнее событие.",
    carried: "Продолжение подготовлено. Первое сообщение отправьте сами — автоматическая отправка недоступна.",
    retry: "Отправить продолжение", pending: "История подключена к следующему сообщению. Если отправка не удалась, она остаётся готова к повторной попытке.",
  },
  en: {
    unconfirmedTitle: "Transfer not confirmed",
    sendUnconfirmed: "The transfer is still unconfirmed. Check the DeepSeek reply before sending again.",
    returnUnconfirmed: "The first message is still unconfirmed. Its text is kept until this tab closes. Return to the attempted chat and check for a response before sending again.",
    returnMessage: "Return to message",
    checkReply: "Check DeepSeek response",
    checkingReply: "Checking response…",
    cancelRecovery: "Cancel transfer and discard draft",
    commitTitle: "Transfer still needs to be saved",
    commitPending: "DeepSeek accepted the message. Finish saving the transfer on this device.",
    commitSaving: "Saving the transfer on this device…",
    commitRetry: "Finish saving transfer",
    commitFailed: "Saving has not finished. Check that storage is available and try again. If the game changed in another chat, return to the current chat.",
    title: "Continue your story", hint: "DeepSeek first compares the story with memory. Approve the changes you want, then a hidden summary of recent scenes is prepared and a new chat opens. Lore, portraits and progress stay in the same world.",
    detail: "The summary goes into the first request context; only the continuation request is visible in chat. Missing events are not invented. The original chat remains available.",
    analysis: "1/3 · Comparing story and memory…", review: "2/3 · Review memory changes",
    reviewAction: "Review changes", readyToSummarize: "2/3 · Memory is up to date",
    startSummary: "Prepare summary and continue", summary: "3/3 · Summarizing recent scenes…",
    summaryArchived: "Story transfer service request", summaryFailed: "The summary did not finish. Transfer stopped.", summaryDone: "Summary ready. Opening a new chat…", cancel: "Cancel transfer", cancelled: "Transfer stopped.",
    reviewHint: "Continue with your current memory or save selected changes. DeepSeek will then prepare a summary and a new chat will open. Closing this window pauses the transfer.",
    keepMemory: "Continue without changing memory", saveContinue: "Save and continue", tooLarge: "The full lore exceeds the memory review limit. Open “Continue in a new chat” and choose “Use the latest save”.",
    continuePrompt: "Continue the roleplay from the exact moment in the supplied recent-scene context. Preserve the conversation's language and style. Do not repeat the recap, decide for the player, or replay completed events.",
    saved: "Story state saved", creating: "Saving your story…", continue: "Continue in a new chat", recap: "Prepare a recap with DeepSeek",
    ready: "Save or send your draft, then try the transfer again. Your draft is untouched.",
    failed: "Transfer did not finish. The old chat remains available and approved memory changes are saved. Please try again.",
    partial: "Some messages did not fit. Lore and progress are preserved; the full conversation remains in the original chat.",
    history: "History read from the chat", page: "Only messages available on the page", source: "Open original chat",
    warnings: "Warn when a chat is filling up", warningHint: "At approximately 90% and 97% of your chosen capacity, once per level in this chat. Messages are never blocked.",
    capacity: "Estimated chat capacity, tokens", capacityHint: "A guide for the meter and warnings, not the attached-memory budget. DeepSeek may use a different limit.",
    warning: "This chat is nearly full", critical: "Very little room left in this chat",
    warningBody: "We estimate that the history uses about {percent}% of your chosen capacity. DeepSeek may stop accepting continuations. Consider moving your story first.",
    uncertain: "This is an estimate, not a notice from DeepSeek. The exact number of remaining messages is unknown.",
    notNow: "Stay in this chat", disable: "Turn off warnings", waiting: "Wait for the answer to finish so its latest event can be carried over.",
    carried: "Your continuation is ready. Send the first message yourself — automatic sending is unavailable.",
    retry: "Send continuation", pending: "Your story is attached to the next message. If sending fails, it stays ready for another attempt.",
  },
} as const;
export function continuationText(locale: Locale, key: keyof typeof copy.en, vars: Record<string, string | number> = {}): string {
  return Object.entries(vars).reduce((text, [key, value]) => text.replaceAll(`{${key}}`, String(value)), copy[locale][key] as string);
}
