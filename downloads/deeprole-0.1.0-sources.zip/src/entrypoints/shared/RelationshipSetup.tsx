import type { Locale } from "../../core/types";
import type { RelationshipCastDraft } from "../../core/relationship-setup";
import { relationshipText, type RelationshipCopyKey } from "../../core/relationship-i18n";
import { RelationshipPresets, RelationshipScores } from "./Relationships";
import { Plus, Trash2 } from "lucide-react";
import { progressText } from "../../core/progress-i18n";

export function RelationshipSetup({ locale, value, onChange, disabled }: { locale: Locale; value: RelationshipCastDraft; onChange: (value: RelationshipCastDraft) => void; disabled?: boolean }) {
  const t = (key: RelationshipCopyKey) => relationshipText(locale, key);
  return <details className="dr-bond-setup"><summary>{t("setupTitle")}</summary><div><p>{t("setupHint")}</p><label className="lm-create-field">{t("heroName")}<input maxLength={80} value={value.hero} disabled={disabled} required={value.people.length > 0 || !!value.heroAttributes} onChange={event => onChange({ ...value, hero: event.target.value })} /></label>{value.people.map((person, index) => {
    const update = (patch: Partial<typeof person>) => onChange({ ...value, people: value.people.map((p, i) => i === index ? { ...p, ...patch } : p) });
    return <section className="dr-bond-block" key={index}><label className="lm-create-field">{t("personName")} {index + 1}<input required maxLength={80} disabled={disabled} value={person.name} onChange={event => update({ name: event.target.value })} /></label><RelationshipPresets locale={locale} disabled={disabled} onChange={update} /><RelationshipScores locale={locale} value={person} disabled={disabled} onChange={update} /><label className="dr-bond-toggle"><span>{t("romance")}</span><input type="checkbox" role="switch" disabled={disabled} checked={person.romance} onChange={event => update({ romance: event.target.checked })} /></label><button type="button" disabled={disabled} onClick={() => onChange({ ...value, people: value.people.filter((_, i) => i !== index) })}><Trash2 size={16} />{t("removePerson")}</button></section>;
  })}<button type="button" disabled={disabled || value.people.length >= 8} onClick={() => onChange({ ...value, people: [...value.people, { name: "", trust: 20, affinity: 20, romance: false }] })}><Plus size={16} />{t("addPerson")}</button><label className="dr-bond-toggle"><span>{progressText(locale, "setup")}</span><input type="checkbox" role="switch" disabled={disabled || !value.hero.trim()} checked={!!value.heroAttributes} onChange={event => onChange({ ...value, heroAttributes: event.target.checked })} /></label><p className="dr-character-hint">{progressText(locale, "setupHint")}</p><p className="dr-character-hint">{t("consent")}</p><p className="dr-character-hint">{t("setupNext")}</p></div></details>;
}
