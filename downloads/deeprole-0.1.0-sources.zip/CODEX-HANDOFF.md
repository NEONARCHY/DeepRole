# Передача Codex — 21 октября 2026

## RP356 — вкладка меню и восстановление состояния подготовки

21 октября 2026. Пользователь сообщил: после смены вкладки меню теряет статус,
служебное окно остаётся на «Ожидаем ответ», хотя job уже error/cleanup failed
и содержит 3 подготовленные анкеты. Исправленная stats-ошибка из журнала —
не доказательство текущей причины остановки. Старый диагностический экспорт
вообще не содержал job.error; точную причину этого конкретного запуска не установили.

Исправления кода:
- Embedded App читает вкладку своего iframe через DR_MENU_TAB/sender.tab.id,
  а не активную вкладку/окно. Тот же адресат используется для действий App.
  Самостоятельная панель сохраняет выбор текущей активной вкладки.
- Возврат видимости/фокуса обновляет контекст меню и сохранённый reset job.
- Cast worker получает read-only status своей задачи каждые20сек и при возврате.
  Конечное состояние останавливает ожидание; ошибка потери ownership показывает
  проверку временного чата, не запускает новый запрос и не разрешает удаление.
- Временное окно и карточка подготовки показывают число сохранённых анкет.
  Cleanup ловит исключения и завершает экран состоянием cleanup-failed.
- Таймаут ответа:7мин видимого времени, до30мин скрытого на один ответ;
  после возврата есть минимум15сек для отрисовки, прежний checkpoint сохранён.
  Это не гарантия работы при заморозке браузера/сне ОС.
- Диагностика v3: текущий безопасный код ошибки, updatedAt, build timestamp.
  Лор/ответы/источники не добавлены в экспорт. Два подтверждения сброса,
  exact binding, ownership, проверка ответа и запрет дублирования отправки сохранены.

Проверка: TypeScript и Chrome/Firefox ZIP пересобраны; unit/E2E не добавлялись
и не запускались. Локально просмотрен production service screen RU/EN320px:
остановка и счётчик3/24 видны, горизонтального переполнения нет. Это просмотр
заданных состояний, не воспроизведение браузерного переключения/живого DeepSeek.
Установленная копия не обновлялась; личный лор не сбрасывался.
Архив: downloads/DeepRole-RP356-tab-resume-20261021.zip (включает UX355/RP354).

Следующий шаг после обновления установленной копии: на отдельном тестовом мире
начать подготовку, переключить вкладку и свернуть служебное окно, затем вернуться.
Проверить сохранение статуса/счётчика, переход к review после cleanup, отсутствие
повторного запроса. Не применять сброс личного мира ради проверки. Если остановится,
взять новый diagnosticVersion3 с текущим error/build. RP-05/RP-08 остаются открыты.

## UX355 — короткий основной путь и конкретный быстрый сброс

21 октября 2026. Пользователь не понял UX353: два длинных объяснения путают.
Основной экран теперь «Начать историю заново» с одним действием по лору,
короткой подписью о предварительном плане и сохранении изображений/архива.
«Быстрый сброс без DeepSeek» закрыт как дополнительный способ. Его кнопка открывает
read-only просмотр реальных значений сохранённых анкет (не модельный пример):
доверие/симпатия к герою, характеристики, дополнительные стартовые состояния,
исходные завершённые milestones. Текущие сыгранные значения не выданы за начало.
Нет подставленных нулей при отсутствующих числах. Нет изображений в preview DTO.
Для больших списков есть поиск по имени; отдельно видны предупреждение о текстах
анкет/лора и галочка согласия. Открытие просмотра ничего не меняет и не вызывает ИИ.
Preview учитывает canonical roster после очистки seeds и архивации игры через
существующий worldGamePeople. App передаёт slim DTO в StoryWorkspace/WorldGamePanel.
Подтверждение связано с просмотренным characterRevision: expectedBase передаётся
в StoryGameClient, проверяется после ожидания очереди, затем прежним атомарным
storage guard. При обновлении данных просмотр stale и согласие сбрасывается.
Операции сохранения/сброса, два подтверждения сброса по лору и авторизация не менялись.
RU/EN/узкая панель просмотрены локально. Unit/E2E не добавлялись/не запускались.
TypeScript и Chrome/Firefox ZIP пересобраны. Личный лор не сбрасывался, установленная
копия/живой DeepSeek не обновлялись. Архив включает RP354 и UX350–353:
downloads/DeepRole-UX355-simple-reset-preview-20261021.zip.
Следующий шаг: после обновления — повторить RP354 подготовку тестового мира со
свёрнутым окном. RP-05/RP-08 открыты; сохранить весь diff, потом свежий holdout с
ожидаемыми результатами до первого запуска. Не считать UI просмотр живым сбросом.

## RP354 — исправлена остановка подготовки сброса по формату

21 октября 2026. Пользователь прислал ошибки после сворачивания: в трёх попытках
DeepSeek вернул characters.length=3 при batchSize=1; при исправлении вернул
числа в state.stats[*].value (нужны строки). Это реальные отказы валидации уже
полученных ответов, а не подтверждённый reply-timeout или tab-closed.
В reset prompt устранено противоречие «одна анкета» / «prepare ALL existing people».
Полный roster больше не дописывается в конце как competing instruction: финальный
scope содержит только текущие id/name и точное количество, включая repair.
Большой лор использует текущего large candidate; следующий выбирается локально.
Общий batch limit повторяется также для repair. Примеры stats явно требуют строк.
parseCastBatch переводит только явно полученные safe integer stats.value в текст,
без изменения label, числового смысла, единиц или исходного raw. null/объекты/
boolean/дробные/небезопасные числа не приводятся и проходят прежний строгий отказ.
parseCastDraft/validateCastDraftValue и валидаторы хранилища остаются строгими.
Переполненная партия по-прежнему отвергается, анкеты не обрезаются и не теряются;
id, evidence, лимиты, подтверждения и guard мира не ослаблены. Правки не сбрасывают
личный лор; исправленная подготовка требует новой попытки после установки.
TypeScript и Chrome/Firefox ZIP пересобраны. Unit/E2E не добавлялись/не запускались.
Личный DeepSeek и свёрнутая установленная копия не проверялись в этом шаге.
Архив: downloads/DeepRole-RP354-reset-batch-format-20261021.zip (включает UX350–353).
Следующий шаг: обновить личную копию и снова подготовить сброс на тестовом мире,
свернув окно; проверить все анкеты, переход к очистке записей, готовый план/cleanup.
Не считать эти форматные правки окончательной живой проверкой UX352.
RP-05/RP-08 открыты; сохранить весь текущий diff и handoff, затем свежий holdout
с ожиданиями до запуска. Сам сброс — только после двух явных подтверждений юзера.

## UX353 — понятный выбор перезапуска

21 октября 2026. Переименованы оба действия и добавлены постоянно видимые
пояснения RU/EN: «Вернуть мир к началу по лору» — подготовить план DeepSeek,
начальные отношения/показатели и выбранную очистку целей, биографий и записей;
«Перезапустить с начальными значениями» — без DeepSeek, по сохранённому началу,
без очистки текстов анкет и библиотеки. Общие последствия видны до выбора:
сброс прогресса и памяти сцен всего лора, архив предыдущей игры, сохранение
внешности/характера/изображений. Подтверждение быстрого перезапуска остаётся
в явно названном details; до галочки кнопка disabled. Два подтверждения полного
сброса, guards и storage/runtime сброса не менялись. Названия согласованы с
диалогом, launcher, сообщением об ошибке и актуальными руководствами.
TypeScript и Chrome/Firefox ZIP пересобраны; Unit/E2E не добавлялись/не запускались.
Локальный UI просмотр RU/EN не является сбросом настоящего лора или live DeepSeek.
Архив: downloads/DeepRole-UX353-reset-choice-20261021.zip, включает UX350–352.
Личная установленная копия не обновлялась. Следующий шаг: после установки —
живой контроль свёрнутой генерации UX352; RP-05/RP-08 остаются открыты, свежий
независимый holdout с ожиданиями до запуска. Сохранить весь текущий diff.

## UX352 — служебную генерацию можно свернуть

21 октября 2026. По просьбе пользователя добавлена поддержка фонового обновления
страницы DeepSeek в служебных окнах cast/reset/field/profile/repair/discovery/memory.
service-background-render устанавливается только при валидном service URL/marker;
таймер активируется после успешного background claim. Скрытые rAF идут через один
таймер 1с, видимые — через native rAF. Сохраняются отмена callback, очередность
кадров, одинаковая временная метка кадра и возврат к native при показе окна.
Завершение/отмена/ошибка выключают fallback. Обычные игровые чаты не меняются;
visibilityState не подменяется, фокус не захватывается, новых разрешений нет.
RU/EN подсказки и обучение теперь разрешают свернуть, но запрещают закрывать окно.
Сон ОС, browser freeze и интенсивный throttling не обходятся. Реальный свёрнутый
DeepSeek в установленной копии пока не проверен: не считать локальную сборку live.
Unit/E2E не добавлялись и не запускались. TypeScript и ZIP Chrome/Firefox пересобраны.
Общий архив включает UX351 (6 превью, лимит38):
downloads/DeepRole-UX352-background-generation-20261021.zip.
Следующий шаг: обновить личную копию, проверить cast в свёрнутом окне до появления
отчёта и очистки; отдельно отмену и повторное раскрытие окна. RP-05/RP-08 открыты;
сохранить весь незакоммиченный RP344–346/UX347–352, затем свежий независимый holdout.

## UX351 — шесть превью и до 38 действий

21 октября 2026. По просьбе пользователя размер страницы библиотеки уменьшен с9
до6; page count, slice, eager/batch и кнопки RU/EN используют LIBRARY_PAGE_SIZE.
По уточнению пользователя лимит активных эмоций/действий повышен с 32 до 38, включая neutral. Общий валидатор используется сохранением, импортом и настройками; RU/EN подсказки берут лимит из константы. Длина имени остаётся 32 символа. Кэш, сжатие и запись оригиналов не менялись. TypeScript и обе ZIP-сборки пересобраны.
Unit/E2E не добавлялись и не запускались. Личная установленная копия не обновлялась.
Архив downloads/DeepRole-UX352-background-generation-20261021.zip. Сохранить незакоммиченные
RP344–346/UX347–351. RP-05/RP-08 по-прежнему открыты; следующий шаг — независимый
holdout с ожидаемыми результатами до запуска и отдельный live большого мира.

## UX350 — быстрые превью, сохранение большой библиотеки и сжатие прежних фото

21 октября 2026. Пользователь попросил ускорить библиотеку, сохранить надёжность
«Сохранить персонажа» и добавить сжатие уже загруженных картинок.

Добавлен display-only PhotoPreviewCache: миниатюры256/512/1024 создаются рядом с
оригиналами в extension context и возвращаются через отдельный readPhotoPreview RPC.
В RAM только ограниченный LRU16MiB/96 миниатюр, дедупликация одновременных запросов,
максимум2 декодирования. Это НЕ лимит числа/размера фото пользователя. Проверка
доступа/наличия оригинала выполняется и на cache hit; lock очищает кэш. Декодирование
идёт вне library lock. Full viewer/export/compression читают оригиналы. Нет новой
БД, миграции, изменения оригиналов при просмотре. Если thumbnail API недоступен,
сохраняется прежний путь загрузки. Base64 декодируется циклом без callback на байт.

PortraitLibrary монтирует только страницу9; выбор сохраняется между страницами,
«Выбрать видимые» относится к текущей странице. Map/Set вместо повторного indexOf/
includes при отрисовке. Сохранение не зависит от готовности превью. Общий
prepareCharacterSave компактирует и дедуплицирует уникальные originals перед RPC,
неизменённые image fields по-прежнему опускаются для three-way merge. PhotoAssets
также дедуплицирует повторные назначения в пределах одного compact/save. Ни BlobURL,
ни миниатюры в анкету не подставляются; транзакционный save/конфликты сохранены.

«Сжать всю библиотеку»: отдельное окно RU/EN, выбор configured WebP92% или compact
до1280px/82% (с учётом maxEdge). По одному оригиналу, без upscale, только если файл
уменьшился. Полный sheet публикуется только после успешной пачки; cancel/error не
публикуют частичный результат. Save заблокирован до окончания/отмены. Сохраняются
назначения, общие фото в selfieCategories и обе referenceKey через remap на новые
IDs; одинаковые результаты дедуплицируются. Применение к персонажу — явный Save.
Прежние unreferenced assets могут остаться в БД; уменьшение размеров выбранных
изображений НЕ обещает немедленного освобождения всей разницы на диске. Защищённые
исходники других анкет/резервных записей не удаляются. Copy настроек обновлён.

Ручной local Chromium:40 вымышленных PNG1920×1080,32223607B, отдельная IndexedDB,
реальные DeepRoleRepository/prepareCharacterSave/saveCharacter. Save во время2
preview jobs:102ms, payload1089 символов, после повторного read40 original addresses
и обе ссылки ref. Warm return:9 preview requests, originalReads18→18. Cancel сжатия
оставил неизменённые image fields (второй save1111 символов). Compact:40 фото,
30.73MiB→2.51MiB; Save48ms/payload9720, reopen40 и обе ref. Это локальный набор,
не личный мир200MB и НЕ установленный runtime-port/живой DeepSeek. RU/EN modal,
EN320 client/scroll231/231; на странице только9 articles. См. benchmarks/ux350-*
и docs/UX350-LIBRARY-PERFORMANCE-AND-COMPRESSION-20261021.md.

TypeScript и Chrome/Edge+Firefox ZIP пересобраны; CRC/source hash verification.
Unit/E2E не добавлялись и не запускались. Firefox UI/vault migration/performance
на личном мире не проверялись. Архив
downloads/DeepRole-UX350-library-performance-compression-20261021.zip; generic
Chrome/Firefox/sources обновлены. Установленную копию обновляет пользователь.

Далее RP-05: независимый holdout с gold/notice ДО первого запуска; отдельно live
большого мира. RP-05/RP-08 открыты. Сохранить незакоммиченные RP344–346/UX347–350.
Push/merge в этой итерации не запрошены.

## UX349 — включение записи на месте и объяснение двух функций

21 октября 2026. Пользователь не нашёл включение записи из «Памяти» и попросил
объяснения в «?» у «Запись сцен» и «Сопровождение игры».
StoryReview показывает основной start прямо в неактивном состоянии раздела,
а не только ссылку-пожелание включить запись где-то ещё. Та же возможность
доступна в «Делах», «Сводках», «Персонажах» и «Записанных сценах»; сохранён
единственный смонтированный ActiveStoryReviewCard. Начальная точка и отсутствие
автоматического разбора старой переписки объясняются перед кнопкой. Start вызывает
существующий onGame/start и перечитывает результат. Секция не переключается,
ошибка не выдаётся за включение, старый чат/readOnly и генерация блокируют кнопку.
После успешного старта в этой секции показано «Запись включена».

MemoryGuide расширен темами recording/automation; «?» есть у обоих заголовков
в обзоре и у нового пустого состояния. Подсказки RU/EN объясняют цель, пример с
обещанием/ключом, разницу журнала и принятия фактов, три режима, начальную точку,
отдельный разбор старой истории и ограничения модели. Нативный диалог со скроллом,
Escape и возвратом фокуса. Ключевые последствия оставлены видимыми до включения.

Проверка: TypeScript и Chrome/Edge+Firefox build/ZIP; ручной local Chromium
RU380/EN320, native help/scroll/Escape/focus, start через синтетический callback,
отказ callback оставляет кнопку и ошибку, readOnly отключает start. Это НЕ живая
проверка установленного расширения/DeepSeek; unit/E2E не добавлялись и не запускались.
Firefox UI не просматривался. См. docs/UX349-SCENE-RECORDING-HELP-20261021.md и
docs/benchmarks/ux349-verification.json. Архив
downloads/DeepRole-UX349-recording-help-20261021.zip; generic Chrome/Firefox/sources
обновлены. Сборка сама установленную копию не обновляет.

Дальше RP-05: независимый holdout с gold/notice ДО первого запуска, отдельно live
большого мира. RP-05/RP-08 открыты. Сохранить незакоммиченные RP344–346/UX347–349.
Push/merge в этой итерации не запрошены.

## UX348 — лимит в окне памяти, единая карточка и девять превью

21 октября 2026. Добавлен MemoryBudgetEditor в «Подключённую память»: поле500–16000,
подстановка большего значения (обязательная память +25%, округление500) и явное
сохранение. Это бюджет добавляемой памяти выбранного мира, сохраняемый при
продолжении. Само открытие/подстановка ничего не сохраняет. RU/EN, busy/error/
success/conflict. Новый узкий saveMemoryBudget RPC проверяет текущий URL чата,
привязку мира и expectedBudget; атомарный CAS мира+binding сохраняет только бюджет
и updatedAt поверх актуального мира. Остальные настройки/лор не переписываются.
Content reload реально пересчитывает следующий запрос; конфликт обновляет данные.

«Контекст» и предупреждение теперь внутри общей рамки, без внешнего зазора:
разделитель и тёплый акцент остаются внутри того же movable/minimizable WidgetTile.
PortraitLibrary помечает группы по9, первые9 eager. Photo-loader при появлении
любого превью группы подготавливает все9; декодирование по2 одновременно,
невидимые группы освобождаются. Оригиналы/назначения/объём библиотеки не менялись.

TypeScript, Chrome/Edge и Firefox build+ZIP прошли. Ручной локальный Chromium:
RU872/320, EN320 без горизонтального переполнения; подстановка/сохранение на
синтетическом callback, invalid499 запрещён. Реальный photo-loader с27 тестовыми
адресами: сначала9 blob-превью группы0; переход к10-му —9 группы1 (всего18 чтений),
группа0 освобождена. Это локальный просмотр, не живая проверка RPC в установленном
DeepSeek. Unit/E2E не добавлялись и не запускались. Firefox UI не осматривался.
См. docs/UX348-MEMORY-BUDGET-AND-PREVIEWS-20261021.md и benchmarks/ux348-verification.json.

Архив downloads/DeepRole-UX348-memory-budget-previews-20261021.zip; generic
Chrome/Firefox/sources обновлены. Пользователь обновляет установленную копию.
Далее по RP-05: независимый holdout с ожидаемыми результатами ДО первого запуска;
отдельно live большого мира. RP-05/RP-08 открыты. Сохранить весь незакоммиченный
RP344–346/UX347–348; push/merge в этой итерации не запрошены.

## UX347 — подключённая память в центре и перемещаемое предупреждение

21 октября2026. Пользователь попросил центральное окно с лёгким затемнением и
устранение неподвижной плашки поверх панелей. См. docs/UX347-CONNECTED-MEMORY-DIALOG-20261021.md.
PageMemoryDialog — native top-layer viewport modal720×780 max, адаптивный,
фиксированный header/scroll body; Esc/крестик/фон, focus return, сохранение
смонтированных form drafts при скрытии. В формах отдельное «К памяти» вместо
второго неразличимого крестика. Полный GameMemoryNotice внутри окна; компактная
строка в memory WidgetTile участвует в drag/collision/minimize вместе с ним.
Проблема была в GameMemoryNotice вне WidgetDeck. Budget logic/storage не менялись.
requiredSize RU/EN показывает реальные required/limit; это локальный бюджет мира.

Ручной local IAB/Chromium просмотр RU872 и RU/EN320, Esc/focus/backdrop/draft,
перемещение x8→16. TypeScript/Chrome/Firefox ZIP и package hashes — verification.
Новых unit/E2E нет и они НЕ запускались; RP3469855/0/5 и8+8 — исторические числа.
Личное расширение/живой DeepSeek сами не обновлялись, Firefox UI не просматривался.
Архив downloads/DeepRole-UX347-memory-dialog-20261021.zip; generic Chrome/Firefox/
sources пересобраны. Установленную копию обновляет пользователь.

Далее — независимый holdout RP-05 с gold/notice ДО запуска, отдельно personal live
большого structured-source мира после обновления. RP-05/RP-08 открыты.
Незакоммиченные RP344–346 и UX347 сохранить. Push/merge в этой задаче не просили.


## RP346 — пропуски и история закрытых дел исправлены локально

Сначала docs/RP05-TASK-HISTORY-REPAIR-20261020.md и
docs/benchmarks/rp346-verification.json. Исправлены query-only intent/narrative
fallback, literal multiword titles, partial head/recent references; без словаря
предметов набора и без пересчёта frozen V1. Закрытые task chains передаются
атомарно с historical guard/latest accepted state. Канон остаётся compact;
readTaskArchive читает checkpoint seeds/selected accepted events строго в
подтверждённой episode/game/branch lineage. Content готовит archive при load.
OOC instruction запрещает выводить неизвестного recipient из подписи/другого долга.

Итог: full9855pass/0fail/5todo; SEEN RP344576/RP342480/RP340576/RP336432,
2064 измерения/688 пар,0 missing/falseComplete/integrity/stability/mutation;
registered notice0 mismatch. Gold/первые red/helper прежние. Это SEEN,не fresh.
Runtime8/8: четыре1024-source мира compact в1023 current facts,44 новыхPOST
(40sources+4OOC) плюс4 старых confidence POST=48 synthetic, ещё2 prefix tests.
UI8/8 RU/EN Edge/Firefox320/900; tsc/diff/оба build+ZIP0. Source hashes одинаковы.
Полный first9815/18/5 и runtime first4/4 сохранены, причины/исправления в отчёте.
Legacy RP263/RP268 comparator явно taskHistoryRecall:false; старые digests pass.

Архив downloads/DeepRole-RP346-task-history-20261020.zip и generic Chrome/Firefox/
sources обновлены. Пересборка НЕ обновляет личное расширение. Личный live нового
кода НЕ проводился. RP344/345/346 local work не пушился; main прежде2208778.
Не откатывать эти незакоммиченные изменения при pull.

Далее: новый независимый holdout на других историях с gold/notice ДО первого run;
отдельно после ручного обновления живой DeepSeek с большим structured-source world.
Не считать prompt-инструкцию доказанным устранением hallucinated recipient.
Active-tab guard НЕ ослаблять: RP345 отказы автоматизации не доказали retrieval bug.
RP-05/RP-08 остаются открыты.32labels/128sources/query4000/budget/opt-outs сохранены.

## RP345 — живые ответы проверены; отдельная неточность адресата

Сначала docs/RP05-LIVE-ATTRIBUTION-CONTROL-20261020.md и
docs/benchmarks/rp345-verification.json. На реальном DeepSeek12/12 закреплённых
OOC вопросов в «Условия Норы», включая reload; без manual seed. Это существующий
небольшой lore world, НЕ1024 structured sources и не свежий independent holdout.
Новый чат85a73980-6550-44a5-8e44-7996b5d8a247 («Нет памяти»): сжимку НЕ применяли.
Три автоматических отправки без памяти: activation-tab-inactive182/34/56ms,
включая один повтор после user-selected; fresh inventory/selected API targetтотже.
Не считать это доказанной ошибкой retrieval или таймаутом. Ручной Enter пользователя
дал6/6 ожидаемых тематических цепочек; до него правильного native ответа не было.
НО модель дописала адресата «Нора обещала Мире» для калибровки, хотя source его
не называет. Targeted follow-up признал неизвестность. Это не code fix.

17 model requests всего:12base+3refused automation+1manual+1attribution. UI world/3
people/50-50/scene unchanged; rawDB/POST не audited. Active guard НЕ ослаблять.
Console revisionRP333 — диагностическая метка, НЕ fingerprint installed binary.
Скриншоты с sidebar только ignored .output; durable crop без sidebar сохранён.
Runtime неизменён, suites/build здесь не повторялись. Browser ZIP всё ещё RP344
rebuild того же RP343 runtime; source ZIP дополнен отчётом. RP344 local+RP345
не запушены; RP331–343 уже main2208778.

Далее всё ещё ремонт RP344 (54missing cases/10notice gaps),SEEN+RP342/RP340/RP336
и регрессии; отдельно unknown promise recipient attribution без угадывания роли
из подписи/соседнего обещания и без переписывания V1. Потом свежий holdout.
Большой structured-source personal live/RP08 открыты. Установленный hash не читался.

## RP344 — новый независимый набор красный,20 октября

Сначала docs/RP05-NOVEL-NARRATIVE-HOLDOUT-RESULTS-20261020.md и
docs/benchmarks/rp344-verification.json. Новые мастерская/карстовая экспедиция RU/EN,
96 запросов,24/1024 facts,576 cold/warm/reopened. Gold/notice,все src/helper/harness
заморожены ДО first run; SHA a86dadc25d8fefb57119c90d1123db0629cc1f5d2c79a9aa436006976a947076.
Первый и единственный scoring9pass/1fail:132/192 всех критериев,54 пары с127
missing source occurrences,10 required notice отсутствуют,4 missing без плашки;
falseComplete/integrity/stability/input/storage mutation0,max2834/6000.
32 missing — прежнее open promise core16 с уже completed task.key: compaction
оставляет latest slot. Это историческая цепочка, НЕ32 забытых активных долга.
Не воскрешать open; подумать об отдельной history/provenance передаче.

Далее ремонт: свободные формулировки, cancelled/privacy chains, recent-version
и неизвестный объект — visible caution; closed task history без смены текущего
статуса. Runtime/gold/helper сейчас НЕ правились. Не добавлять словарь предметов
набора,не менять V1 roles/quotes. Replay RP344_SEEN=1 + новый RP344_REPORT;
потом RP342/RP340/RP336 и регрессии. Первый red/manifest НЕ перезаписывать.
После ремонта новый независимый holdout; RP-05/RP-08 открыты.

tsc/diff/оба build+ZIP0; UI/POST/personal live/full suite здесь не повторялись.
Full9768/0/5 — RP343, личная копия последний раз принята RP338/RP339.
Пересборка не перезагружает установленную копию. Источник runtime всё ещё RP343.
Первый shell observer timeout20s не прервал child: тот же первый run завершён85s,
receipt сохранён,576 измерений; scoring НЕ повторялся. Логированный typecheck0.
RP331–343 запушены в main2208778; RP344 пока локально,push/merge не запрошены.

## RP343 — пропуски RP342 исправлены; далее новый независимый набор

Сначала docs/RP05-UNRESOLVED-MEMORY-REPAIR-20261019.md и
docs/benchmarks/rp343-verification.json. Verified source ≠ bound role: unknown
остаётся unknown; V1/источники/helper не переписывались. Не добавляли словарь
предметов RP342: неопознанный операционный запрос получает bounded open/cancelled
duty candidates с условиями и честной incomplete/model guard. Recent2×2000 chars
только для operative references; общий status question не сужается прошлой темой.
Title prepositions/contrast sources/маскирование имён,32 labels/128 rows/4000 chars,
source/budget/opt-outs/strict single/deictic/history paths сохранены. Это НЕ semantic identity.

Финальные SEEN RP342480/RP340576/RP336432:0 missing/falseComplete/integrity/
stability/input/storage mutation; RP3420 notice mismatch. Gold/manifest/first red
не менять. Full unit 9768pass/0fail/5todo на неизменных src;164/164 final
compatibility и154/154 history/search пересекаются с full. Final binary10/10,32 new820-source POST
+20 old14/618-source POST и2 prefix presentation. Всё synthetic, НЕ personal live.
UI serial8/8 Edge/Firefox RU/EN320/900 +axe/keyboard/layout; первый parallel6/2
Firefox timeout/protocol сохранён, таймауты не увеличивали. Screenshots просмотрены.
tsc/diff/build/ZIP0; Vite4187 PID31516 проверен и остановлен. Ранний full9614/153/5
исправлен без смены old expectations; два прерванных full не выдавать за пройденные.
Старые premise/obligation/ambiguous-name пути и исторические вопросы сохранены.

Архив downloads/DeepRole-RP343-memory-candidates-20261019.zip; generic Chrome,
Firefox/source ZIP обновлены. Последнее личное подтверждение RP338, её не меняли. Следом:
свежий независимый holdout с gold/notice ДО scoring; отдельно большой structured-
source personal live после ручного обновления. RP-05/RP-08 открыты. Не возвращаться
к старым pending установкам RP338. Push/merge не запрашивались; сохранить все
накопленные uncommitted RP331–343 изменения при будущем pull.


## RP342 — свежий независимый набор красный; далее ремонт пропусков/плашек

Сначала docs/RP05-FREE-NARRATIVE-HOLDOUT-RESULTS-20261019.md и
docs/benchmarks/rp342-verification.json. Новые2 сюжета RU/EN,80 запросов,
20/820 фактов,480 cold/warm/reopened измерений; gold/плашки ДО scoring,
SHA2aa3a6b0027cb0ca432b26daa32c8215336bd76a6e8fe6e7232ba42033af64f5.
Первый run1pass/9fail: boundary-kind ошибка МОЕГО стенда,0 retrieval измерений.
До scoring отдельный frozen amendment wrapper boundary→event; исходные gold,
план, цитаты, task, helper/runtime прежние. Первый red НЕ перезаписывать.

Полный run9pass/1fail,480 измерений:32/72 positives и64/88 controls без missing
(включают8/16 empty wanted); непустой wanted72/136. Все критерии76/160.
64 пары теряют214 source occurrences,48 нарушений required notice,28 неполных
пар без preparation warning. FalseComplete/integrity/stability/input/storage0,
max2228/6000. Есть и20-fact red, не только820-fact. Это НЕ personal live/UI/POST.

Ремонт: свободный пересказ вне малого словаря, recent-context short refs,
unknown notice и whole-topic группы отменённых/новых поручений. Post-scoring
diagnostic1/1: у task8/plan9 verified episode, но frozen role unknown; bound-title
gate исключает группу. НЕ расширять V1 historical grammar задним числом,
НЕ угадывать owner, НЕ отменять source/budget guards. Runtime не правили.
После ремонта RP342_SEEN=1 + RP342_HARNESS_CORRECTION=1, новый RP342_REPORT;
исходный gold/plan/first red сохранять. Replay RP340/RP336/регрессии, потом
свежий независимый holdout. RP-05/RP-08 открыты; большой personal live отдельно.

tsc0 (первый20s shell124, повтор0), diff0. Старые suites не повторялись;
предыдущий full-suite RP341 не объявлять зелёным. Browser ZIP RP341 неизменны,
source ZIP с отчётами обновлён. Личная копия RP338 не обновлялась. Push/merge
не запрашивались; сохранить все accumulated uncommitted RP331–342 изменения.


## RP341 — пропуски RP340 исправлены; далее свежий независимый holdout

Сначала docs/RP05-TOPIC-REPAIR-RESULTS-20261019.md и
docs/benchmarks/rp341-verification.json. Source-backed whole-topic recall допускает
вопросы/цитаты/другие глаголы и малый query-only словарь кандидатов. Источник,
task/claim/role/ID не переписывается; вопрос/действие не становится фактом/согласием.
Видимый incomplete используется для нового пути; ordinary legacy unverified
остаётся details-only. Speech-history lane и полный single-action сохранены.
32-label cap относится к связанным кандидатам; unrelated greeting quiet.
No-op grammar конечная, с frozen speaker/source proof; содержательные записи
сохранены, repeatSelection opt-out соблюдён. Query/source/budget guards прежние.

RP340 SEEN576:84/84 positive+108/108 controls; RP336 SEEN432:96/96+48/48.
Missing/falseComplete/integrity/stability/input/storage mutation0. Gold/first red/
evidence helper НЕ менялись. Это не новый независимый результат. Итоговый serial10 файлов623/623,
full2-worker 9664 passed / 64 failed / 5 todo; подробности/повторы/ранние ошибки в verification.
UI8/8 RU/EN Edge/Firefox320/900; synthetic installed22/22 на первой сборке,
8/8 source/prefix после сохранения старых путей; финальный confidence/model-guard
release4/4 на14/618 фактах и20 POST; tsc/diff0, оба ZIP rebuild0.
Первый JSON-only full прерван shell124; первый runtime trace сломан параллельной
очисткой общей папки test-results. Не выдавать их за зелёные, не скрывать первые red.
Playwright параллельно только с разными --output; итоговый Vite4187 остановлен.

Личная копия всё ещё RP338; принятие prefix RP339 сохраняется, но новый retrieval
ещё не personal-live. Архив downloads/DeepRole-RP341-topic-memory-20261019.zip,
generic Chrome/Firefox/source обновлены. Сборка сама установленную копию не меняет.
Далее свежий независимый holdout с gold ДО запуска, плюс structured-source personal
live отдельно. RP-05/RP-08 открыты. Push/merge не запрашивались, всё локальное
RP331–341 сохранять при будущем pull. Не перезапускать старые pending действия.


## RP340 — новый независимый holdout красный; далее исправлять пропуски

Сначала docs/RP05-LONG-COMPOUND-HOLDOUT-RESULTS-20261019.md и
docs/benchmarks/rp340-verification.json. Новые три сюжета RU/EN, 96 запросов,
18/618 фактов, 576 cold/warm/reopened измерений. Gold ДО scoring:
SHA4ddb207ff0ec71018125aa01eefcb39e4fb1f3e4e22e1c4492f5a8d3ef9cf556;
ожидания/первый frozen manifest НЕ менять. Runtime/evidence helper неизменны.

Первый run7passed/7failed: 288 коротких измерений;6 long fixtures отказаны до
retrieval из-за kind=promise у completed side-task. Исправлен только wrapper
на kind=event; отдельный harness amendment, исходный план/first-results сохранены.
Полный run13passed/1failed, все576 измерений завершены. Это не зелёное качество:
9/84 основных +35/108 контролей без пропусков (12 unknown controls с пустым wanted).
512 missing source occurrences,148/192 пары с пропусками,145 без preparation
notice. False-complete0, integrity/stability/input/storage mutation0, max1667/6000.
Это compiler+persisted synthetic graph, НЕ новый live DeepSeek/UI/POST.

Далее исправлять источники/предупреждения: фиксированный verb-gate/question/quote
bypass в narrative recall; базовые8 slots теряют группы условий/запретов;
unverified/query details-only остаётся незаметным. Не снимать guards, не считать
цитату/намерение сыгранным действием. После ремонта RP340_HARNESS_CORRECTION=1
и RP340_SEEN=1, отдельный новый output; перепроверить RP336/прежние регрессии,
потом новый независимый holdout. Точные команды/хеши/первый red в result/verification.

RP-05/RP-08 открыты. Личный prefix-fix RP338 уже принят в RP339, повторная
установка НЕ нужна. Runtime/browser ZIP здесь не менялись; source package
обновляется отчётами. Сохранять накопленную uncommitted RP331–340 работу;
push/merge не запрашивались. Большой structured-source personal live отдельно.


## RP339 — RP338 принят в живом DeepSeek; повторная установка не нужна

Сначала docs/RP05-LIVE-RP338-ACCEPTANCE-20261019.md и
docs/benchmarks/rp339-verification.json. Пользователь установил RP338, перезапустил
расширение и «Условия Норы»6cd8d028-3790-46f1-81d3-b269c50ff3e1. Ранние Nora/Mira
и поздние access/crossplot сообщения теперь визуально без технического prefix.
Один неизменный crossplot без seed прошёл: ключ у Норы, пломба не проверена,
передачи не было; ремонт другого фонаря не смешан с пломбой. Ещё один reload:
новое сообщение чистое, ответ сохранён, мир/3персонажа/50/50/сцена прежние.
Видимых предупреждений подготовки нет, composer пустой. Меню iframe не открывали.

Plan rp339-live-plan.json создан до первой отправки; проверка только visual/UI
и ответ модели, не raw DB/POST/console. Скрытый raw wire может присутствовать
в AX/DOM snapshot: не считать каждое совпадение <deeprole_context> визуальной
утечкой, проверять screenshot и пузырёк. Исходный native текст не удаляется.
Личные screenshots только .output, не коммитить sidebar. Вымышленный мир обычных
lore entries, не614 structured-source facts; existing chat не независимый поиск.

Код/browser ZIP не менялись, новые tests/tsc/build НЕ запускались. 150unit/8UI/
20synthetic runtime относятся к RP338. Browser hashes сохранены; source ZIP
обновлён документацией. Личный prefix-fix теперь live PASSED. Не просить ещё
переустанавливать RP338 ради повтора; вкладка пользователя оставлена на ответе.

Далее RP-05: новый независимый holdout других историй/формулировок с gold ДО
первого scoring. Большой личный live с валидными source/task records отдельно;
RP-08 replay отдельно. Оба этапа открыты. Не выполнять старые pending действия
RP338 ниже: новый фикс уже принят. Push/merge не запрашивались, все накопленные
uncommitted изменения RP331–339 сохранять при pull.


## RP338 — живые8/8 на RP337; исправлен видимый префикс после reload

Сначала docs/RP05-LIVE-RP337-RECHECK-20261019.md и
docs/benchmarks/rp338-verification.json. Пользователь установил RP337 и выбрал
«Условия Норы»: https://chat.deepseek.com/a/chat/s/6cd8d028-3790-46f1-81d3-b269c50ff3e1.
Тот же вымышленный мир,8 неизменных OOC вопросов RP330 +crossplot после reload
прошли; seed/ответы вручную не добавляли, сверку/настройки не меняли. 50/50 и
сцена сохранились. UI не показал отказов подготовки, network/DB аудит не заявлен.

ВАЖНО: preview четырёхчастного НЕОТПРАВЛЕННОГО хода показал6 lore entries,
5 profile excerpts,0 игровых фактов/задач,2 фрагмента переноса,2528/6000 tokens.
Черновик очищен. Это обычная память в существующем чате, не живой 614-source
индекс RP337 и не независимый holdout. Не приписывать8/8 новому алгоритму поиска.
Новый plan SHA4e95c1ecdaed5dba0be1dd0df78ef1d86c07d54e2c45f930f758971d525cbf1f
заморожен ДО отправки; gold не менялся. Личный sidebar screenshot только .output.

В живом UI найдено: старые префиксы видны; новые скрыты до reload, потом тоже
появляются. injectedUserText не распознавал continuationContext между закрытым
XML block и [User message]. Добавлен строгий известный заголовок+полный JSON
реплик user/assistant. Обычные цитаты/невалидные envelopes не скрываются;
исходный submitted wire не меняется, текст игрока/вложенные маркеры сохраняются.
Это общий parser представления/истории, не миграция базы. Личный DOM не патчили.

Первый regression6passed/6failed, итог150/150 выбранных unit; UI8/8 RU/EN
Edge/Firefox360/1280/reload. Installed synthetic runtime20/20 (2 новых prefix,
12 new-chat,2 old-chat,4 large-index); пакеты/ранние ошибки в verification. Две ошибки нового harness отдельно: отсутствовал UTF-8;
raw newline обычной цитаты сравнили с CSS-normalized innerText. Исправлены
только fixture/assertions, guards/таймауты не ослаблялись. Tsc/diff clean.

Актуальный архив downloads/DeepRole-RP338-hidden-context-20261019.zip.
Chrome/Firefox/source ZIP пересобраны. Личная копия ПОКА RP337, новый фикс
на ней ещё НЕ проверен. Следующее действие — после ручного обновления RP338
перезагрузить этот же чат, убедиться, что старые сообщения без prefix; при
необходимости один crossplot для следующей отправки. Не просить импортировать
старый мир заново. Меню iframe не открывать: для проверок хватает page widgets.
Получение tab handle не выбирает foreground; свежий inventory после действий юзера.

После этого — новый независимый RP-05 holdout с gold ДО запуска; отдельно
большой live мир с валидной историей источников/задач, если нужен personal live
нового structured retrieval. RP-05/RP-08 открыты. Push/merge не запрашивались;
не перезаписывать накопленную uncommitted работу RP331–338 при pull.


## RP337 — пропуски RP336 исправлены; следующий шаг новый независимый holdout

Сначала docs/RP05-NARRATIVE-REPAIR-RESULTS-20261019.md и
docs/benchmarks/rp337-verification.json (точные финальные проверки/ограничения).
Новый story-narrative-recall дополняет контекст целыми source-backed группами
по явно названным предметам. Строгая грамматика не расширена; известные короткие
последовательности сохраняют прежний путь. Bare/personal references дают кандидатов,
не владельца/разрешение/закрытие дела; reference guard сохраняет неопределённость.
Повторы исключаются только через isVerifiedEmptyDiscussion; полные прежние
содержательные записи, evidence/roles/source/budget и opt-outs сохранены.

Видимая плашка incomplete/query/source/capacity отделена от budget, не блокирует
отправку и заменяет безусловную готовность. Обычные старые unverified состояния
остались details-only. UI текст не добавляется в prompt/канон; подготовка не
равна подтверждённой доставке. Мануалы/дизайн-система обновлены.

RP336 SEEN: 96/96 основных и48/48 контрольных,432 измерения,0 missing/
falseComplete/integrity/stability/state mutation. Gold и first red не изменены,
helper SHA сохранён. Max1913/6000 токенов. Это знакомый после исправления набор,
не новая независимая оценка. Audit runner различает реальный budgetWarning и
preparationWarning/warningKind; промежуточные отчёты со старой метрикой сохранены.

Старый compound quality тест обновлён только для intentional topical retrieval
в conditional/negated/personal/unknown-object: source fidelity + reference guard
+ not-complete вместо byte-exact absence. Строгий parser/прочие fallback не ослаблены.
JSON import attribute исправлен только в wrapper для Playwright; gold не тронут.
Ранние red/full-runtime результаты и окончательные повторы различены в verification.

Финальные проверки: полный2-worker unit9646 passed/34 failed/5todo:24
изменённых контракта дополнительных кандидатов +10 timeout. Отдельный serial
повтор ВСЕХ8 затронутых файлов818/818 passed, исходные таймауты сохранены.
Не выдавать это за единый зелёный full run. Installed synthetic runtime18/18
(новых2/16 POST на614 фактах, прежних16), UI8/8 Edge/Firefox RU/EN320/900,
axe/keyboard/overflow passed; tsc/diff clean. Два narrow screenshots просмотрены.
Ранние runtime/context-changed и UI timeout сохранены отдельно; повтор успешен
без изменения production guards или таймаутов. Это не доказывает причину
ранних нестабильных запусков. Исторические gold/digests не переписывались.

Пакеты Chrome/Firefox и source ZIP обновлены; именованный
downloads/DeepRole-RP337-narrative-memory-20261019.zip. Установленная личная копия
остаётся RP333: сборка сама её не обновляет. Проверки этой итерации synthetic,
без нового личного live DeepSeek. Push/merge пользователь не запрашивал.

Далее: независимый holdout на других историях/формулировках; ожидания ДО первого
запуска. Проверять ложные/неоднозначные ссылки, источники, границы и warnings.
RP-05 ещё открыт: конечный словарь/названия,4000 символов,32 labels,128 sources,
бюджет; произвольную речь не обещать. RP-08 replay отдельно. Не начинать заново
RP331–337 по старым историческим «далее» ниже; всё локальное сохранить при pull.


## RP336 — независимый narrative holdout красный; далее исправлять пропуски

Сначала docs/RP05-NARRATIVE-HOLDOUT-RESULTS-20261019.md и benchmarks/rp336-verification.json.
Ожидания ДО первого scoring: tests/fixtures/story-rp336-narrative-holdout.json,
SHA906a8e042884359ecf7bcc8152781373eb28f4c4a3655959298b7b588aa87568.
72 запроса ×14/614 фактов ×cold/warm/reopened =432 измерения. Полнота основных
42/96, защитных18/48;4 нарушения критерия осторожности internal coverage,322
пропущенных sources по cold cases. Integrity/stability/storage mutation0.
Короткие2/3 и простая narrative обстановка5семейств по8/8; отдельные предложения,
четыре действия, паузы, длинный переход, условное будущее — каждое0/8.
На короткой истории тоже есть пропуски, budget6000 не исчерпан (max1608).

Runtime и evidence helper НЕ менялись, fingerprints проверены. Это compiler+
validated synthetic persisted source graph, НЕ live/actual POST/UI нового этапа.
В84 случаях пропуска нет budget warning; не объявлять это отсутствием всех UI
предупреждений.4 coverage breaches — internal criterion, не доказанная ошибка
ответа модели. Dataset/gold НЕ переписывать, red first-results сохранять.
Изолированный audit8 structural passed/1gold failed; tsc clean. Начальный запуск
по ошибке включил общий suite из-за mergeConfig include concat; остановлен,
не завершён и не засчитан. Конфиг теперь подтверждён list: один audit-файл.

Далее: multi-sentence/>3-action/free narrative recall и честное incomplete-query
состояние отдельно от budget. Для повторов после FIX: RP336_SEEN=1, другой
RP336_REPORT path, vitest.rp336.config.ts. Это уже SEEN regression, не новая
независимая проверка; gold/helper hashes защищены. Проверить прежние наборы и
actual POST/reload, потом новый holdout. Browser ZIP RP335, личная копия RP333.
RP-05/RP-08 открыты; пользователь сейчас просил проверку, исправления runtime
в RP336 не делались. Всё локально, push/merge не запрашивались.

## RP335 — длинный сохранённый индекс и составные действия

Сначала docs/RP05-PERSISTED-LONG-RESULTS-20261019.md и benchmarks/rp335-verification.json.
Независимый fixture/gold закреплён до первого run (SHA в плане); два сюжета RU/EN,
89/409 фактов, 56 запросов × cold/warm/reopened =168 измерений. Найден пропуск:
compound отбор не исключал доказанно пустые повторы, поэтому терял условия при
400 повторах. compileRepeatContext использует существующий whole-action parser,
покрытие каждого предмета и прежние evidence/budget/fallback guards.
Новая source fixture проходит assertStoryGraph: 409 фактов, 818 revision sources,
receipts/rosters/derived roles и checkpoint продолжения. Нельзя выдавать ранний
тест loose world/ручных role seeds за подтверждённую импортируемую историю.
Gold/исходная проза не менялись; harness исправлен отдельно, red/trace сохранены.

Финальные automated counts и hashes — в rp335-verification.json; Chrome/Firefox
собраны, docs/source ZIP обновлены. Новый downloads/DeepRole-RP335-long-memory-20261019.zip.
Полный4-worker unit дал9661 passed/3timeout/5todo; новые28 passed. Три полных файла
перепроверены serial без изменения таймаутов; отдельный результат в JSON.
Не выдавать суммарные прогоны за единый зелёный parallel run.
Installed synthetic Edge проверяет actual POST/reload/canon и прежние new/old-chat
guards. Это НЕ личный live DeepSeek. Пользователь всё ещё на RP333; RP334 live
доказывает предыдущий binary. Сейчас не просить обновление ради повторения RP334.
При новом live RP335 нужно сначала обновить установленную копию, но пользователь
в этом запросе просил большой индекс/compound QA, а не отдельную переустановку.

Далее RP-05: новый независимый holdout длинных повествовательных/составных ходов
с ожиданиями ДО запуска; не объявлять произвольную речь и бесконечные действия
покрытыми. RP-08 replay отдельно. Всё локально; push/merge не запрашивались.

## RP334 — живой повтор прошёл, повторная установка не нужна

Читать docs/RP05-LIVE-MEMORY-RECOVERY-RESULTS-20261019.md ПЕРЕД старыми pending ниже.
После установки RP333 восемь неизменных вопросов RP330 дали8/8 правильных ответов,
без ручного seed и warnings. Reload сохранил50/50 и три исходные записи: гипотеза
о звонке/проверке не стала фактом. Восемь вопросов в одном чате — не8 независимых
blank-context проверок и не audit actual POST/DB.

Отдельный background New chat3480fdd1 получил точный detail activation-tab-inactive
и не был засчитан успешным. После ручного выбора пользователя новый inventory
дал tab770. В ней создали ещё один native New chat/тот же мир/«Не сейчас»:
первый nora-вопрос прошёл без сжимки/подсказок; после reload mira тоже прошёл.
Новый активный чат «Условия Норы»:6cd8d028-3790-46f1-81d3-b269c50ff3e1 (tab770).
Прежний49f2623a только прочитан: notice с правильной ссылкой на6cd8d028,
«Продолжить здесь» не нажимали. Guard сохранён, никакие новые анкеты не применяли.

Код/runtime ZIP не менялись, установлена RP333 Chrome SHA265e79f1e8de18f4365d35d487c8aa5f0b349f6727188674133879ba34d1cac2.
152 unit/34 runtime — предшествующий RP333, НЕ новый прогон RP334. Обновлены только
отчёты/передача/source ZIP. Доказательства — docs/benchmarks/rp334-*.
Все прежние RP332 конфликты нельзя ретроспективно объяснить inactive: detail тогда не было.
**Не просить ещё одно обновление установленной копии.** При новом отказе сначала свежий detail.
Далее RP-05: большой сохранённый role-seeded индекс и compound coverage RP325;
RP-08 replay отдельно.80 повторов в4ходах не заменяют большой индекс.
RP-05/RP-08 не закрыты, всё локально, push/merge не просили.

## RP333 — live локализован до activation, причина ещё уточняется

Сначала docs/RP05-ACTIVATION-DIAGNOSTICS-20261019.md. Пользователь корректно
обновил RP332, после reload получен activation/story-binding-conflict за293ms.
После «выбрал» обнаружен дубликат одного URL: cached706 и выбранный680.
Перешли на680/reload; отказ тот же за24ms, после штатного сохранения того же мира4ms.
Это не timeout; дубликат не объясняет оставшийся отказ. Seed не пересылали,
ошибочные ответы не сохраняли; остальные семь gold-вопросов блокированы.

Добавлен только allowlisted detail для семи причин activation: tab URL/chat/active,
наличие world/binding и binding world/URL. Public code и все guards сохранены;
detail безопасно проходит через repository port, log revision RP333. Из общего
предупреждения RU/EN убрано ложное утверждение «вовремя». 152 unit/10files и tsc
прошли; installed synthetic Edge runtime34/34 одним serial прогоном за6.2min,
без retries. Chrome/Firefox/source ZIP собраны и сверены; состав/hashes —
docs/benchmarks/rp333-verification.json.
Следующее: update downloads/DeepRole-RP333-activation-diagnostics-20261019.zip,
reload правильной вкладки → первый gold-вопрос → прочитать точный detail → red/fix/live8.
После каждого ручного выбора вкладки заново inventory: не полагаться на старый ID!
Target49f2623a-1c8e-46f4-9d4a-4fefd0aae369; сейчас tab680, дубликат706.
RP-05/RP-08 не закрыты; live причина НЕ исправлена. Всё локально, push не просили.

## Повторная упаковка RP332 по просьбе пользователя

Пользователь сообщил, что неправильно заменил файлы, и попросил ZIP с нуля.
Сборка выполнена из исходников в отдельный output, ZIP/CRC и все23 файла
побайтово сверены со свежим build. Выдан downloads/DeepRole-RP332-CLEAN-20261019.zip,
SHA256 d357f42f0f36fa99edae279becd477a75e13c750d20049b0db062754a558ef00.
manifest.json находится прямо в корне ZIP. Код не менялся, новые тесты не запускали.
Следующее прежнее: правильная замена файлов/перезагрузка и один live вопрос
с диагностикой RP332 в target49f2623a. Обновление пользователем ещё не подтверждено.

## RP332 — живой повтор RP331 провален, точная диагностика готова

Читать docs/RP05-LIVE-RECOVERY-RECHECK-20261019.md ПЕРЕД историческими next ниже.
Пользователь обновил RP331; первый gold-вопрос повторён четырежды: до/после reload
в старом target51a, затем native New chat/тот же мир/без сжимки и после явного
«Продолжить здесь». Доставка не прошла; остальные семь блокированы. Seed вручную
не передавали, ошибочные ответы новой сверкой не сохраняли. До reload были
Extension context invalidated, после reload они исчезли, но отказ остался.
Не считать RP331 синтетические34/34 доказательством live; точная причина ещё неизвестна.

Новый выбранный тестовый чат49f2623a-1c8e-46f4-9d4a-4fefd0aae369 «Нора флюгер башни».
Нужные записи сохранены, source dd3954a5 прежний. Добавлен безопасный локальный
console журнал RP332: этап/allowlisted code/time, без лора/токенов/URL/ID.
Он не меняет send policy и guards. 143 unit / 9 файлов и TypeScript прошли;
runtime34/34 прошёл одним serial запуском за 5.5 min. Chrome/Firefox/ZIP готовы,
downloads/DeepRole-Brave-memory-diagnostics-20261019.zip; состав/побайтовая
проверка — benchmarks/rp332-verification.json и .output/rp332-package-verification.json.
Следующее после обновления диагностического ZIP: один исходный вопрос →
CUA tab.dev.logs filter '[DeepRole memory preparation]' → red regression по
точной причине → исправление → live8. Не открывать blanking extension menu.
RP-05/RP-08 не закрыты. Все изменения локальные, push не запрашивался.

## RP331 — исправление подготовки памяти после перехода

Пользователь попросил продолжить исправление RP330. Читать
docs/RP05-CHAT-MEMORY-RECOVERY.md: воспроизведены rejected navigation queue,
неполностью завершённое «Продолжить здесь», stale parent base и поздняя XHR
квитанция, сбрасывающая UI presentation epoch во время следующего parent GET.
Исправлены очередь и сериализация scene change; parent/edit не зависит от UI
epoch, а настоящий stale base проверяется заново один раз после fresh reload
в том же scope. Чужой чат/мир/lock/manual guard не ослаблены. Повтор model POST
не добавлен. Исходный red повтор сохранён на прежнем выданном UX328 ZIP.

130 targeted unit / 8 файлов прошли, TypeScript clean. Финальная runtime
матрица 34/34 прошла одним serial прогоном за 5.0 min: новые12 + old-chat2 + bracket20.
Новые Chrome/Firefox ZIP собраны и побайтово сверены с build (23+23 файла).
Архив: downloads/DeepRole-Brave-memory-recovery-20261019.zip. Временные QA logs
из конечного кода убраны. Docs/source ZIP обновлены. Далее пользователь
обновляет установленную копию, затем повторить все 8 gold
вопросов RP330 без ручного пересказа. Личный live после RP331 пока НЕ проведён.
Код и отчёты локальные; push/merge не запрашивались. RP-05 не закрыт.

## Актуальная точка RP330 — сначала исправить доставку памяти

План восьми вопросов закреплён до запуска: docs/benchmarks/rp330-live-plan.json,
SHA F717EF16DF9323BD251500252CAD9F3531BACB03F69719CB3964F46A1809D127.
Live Edge: seed7 → сверка3/проверка всех текстов/save3 → 80 повторов в четырёх
сообщениях → сверка0 прошли. Затем пустой чат с тем же миром, без сжимки:
выбранные записи видны, но два первых вопроса получили посторонние ответы и
предупреждение «Сообщение отправлено без памяти». Шесть остальных блокированы.
Reload/напоминание/«Продолжить здесь» не восстановили обычную доставку.
Пользователь сам выбрал вкладку, контроль в ней тоже не прошёл. Не списывать
это только на фоновые вкладки; точная причина не установлена. Одинаковый UI
текст покрывает timeout И context-unavailable. Не утверждать доказанный timeout.

Подробности и следующий воспроизводимый тест:
docs/RP05-LIVE-LONG-RESULTS-20261019.md. Цель следующей реализации — фактический
POST нового bound-чата: активация, navigation queue, native parent, отказ
подготовки; сначала red regression, затем минимальный fix и полный live8 после
обновления. Не ослаблять active-tab guard и не пересылать gold вручную.
Тестовый target 51a8c94e-3b4a-4077-b463-70ab1c924623, заголовок «Обет Норы» —
побочный результат ошибочного ответа, не личный сюжет. Не сохранять эти ответы
новой сверкой. Source dd3954a5 сохранил три правильные записи.
Код и архивы не менялись; RP-05/RP-08 не закрыты, отчёт пока локальный.

## Актуальная проверка RP329 — живые скобки и перенос, 19 октября

После обновления пользователем UX328 проверен личный Edge с отдельным миром
«ТЕСТ DeepRole — Мастерская у моста». Шесть сообщений + reload подтвердили
whole-bracket OOC, гипотезу без выполнения события, обычный ход, mixed note,
OOC после игры и буквальные скобки в цитате. В OOC нет вариантов; 50/50 и
milestones false сохранены. Затем memory review1→проверка текста→save1→recap→
новый чат→OOC5/5фактов→reload прошли. Target dd3954a5-4fe4-49f0-b5e2-ce0010f48352,
старый37f776f1-8a3f-4c21-bd2b-044314f0b17b показывает правильную ссылку/предупреждение.
Старый чат после переноса только читали, «Продолжить здесь» не нажимали.
Подробный отчёт и пределы: docs/LIVE-QA-2026-10-19.md; proof в .output/rp329-live-*.
Это UI/DOM live на коротком мире, без захвата actual POST/независимого аудита DB.

UX328 пользователь вручную проверил и подтвердил «работает» после RP329.
Автоматизированный live инструментом остаётся ограничен: меню пустое about:srcdoc,
доступа через cua.listWindows нет. Продукт ради обхода автоматизации не меняли.
RP325 long repeats/compound coverage и RP-08 replay также не закрыты. Модель при
первом продолжении добавила журнал/номер партии/дату как новые детали сцены;
это не прежний факт, учитывать при дальнейшей проверке строгости канона.
Код/сборки не менялись; runtime архив UX328 остаётся актуальным. Отчёт пока не pushed.

## Предыдущая точка передачи после push — RP309–UX328

Пользователь попросил отправить работу на GitHub и передать другому Codex
всё сделанное за день и остаток. Краткая полная карта —
`docs/HANDOFF-2026-10-19.md`; читать её ПЕРЕД старыми разделами ниже.
Последний прежний main — 49a4dc3, поэтому пакет включает накопившийся код
RP309–RP322 и сегодняшние проверки/исправления RP323–UX328. Последний browser
архив — DeepRole-Brave-guided-start-20261019.zip, включает предыдущие этапы.

Перед push заново пройден весь актуальный unit набор: 334 файла, 9608 passed,
5 прежних todo, 0 failed; TypeScript clean. Это НОВЫЙ общий прогон после UX328,
а не исторические 9529 RP325 или 200 targeted UX328. JSON в
`.output/ux328-push-unit.json`, локален. Runtime после финальной UX328 сборки
не менялся. Browser матрицы и пределы live описаны ниже и в дневном файле.
Именованный/canonical Chrome SHA прежний; финальный source ZIP включает новые
документы передачи. Пользовательские удаления downloads README/старого QA json
включены в пакет как уже выполненная очистка; `.tmp-*` и старые промежуточные
именованные ZIP остаются только локально и не входят в push.

Следующее: после update пользователя личный bracket live и проход обучения;
далее RP-05 независимая точность/полное покрытие составных действий, затем RP-08
replay. Не считать RP324 учебный live проверкой нового RP325 retrieval;
не считать synthetic browser tests личным Brave live. Подробные критерии и
команды — в новом дневном файле. Не удалять основное расширение ради welcome.

## Текущая работа — UX328: интерактивное знакомство

Новая задача пользователя: приветствие при первой установке и воронка важных
функций. Дополнение: пользователь САМ открывает настоящие кнопки/меню,
подсказка ждёт перехода и ведёт дальше; не просто слайды с «Дальше».

Реализованы WelcomeFlow (3 экрана, RU/EN, сразу выбор языка, skip), каталог
8 глав / 31 шага, кнопка-книга в header, локальный progress/resume/replay.
Background открывает sidepanel.html только при install и незавершённом
onboarding; update не прерывает старую игру. Старым пользователям доступна
книга, принудительно заново welcome не включаем.

LearningGuide не вызывает click/submit/nav/API за пользователя. Action step
ждёт видимую destination по data-dr-guide; read steps имеют «Понятно, дальше».
Недоступные шаги объясняются, можно отложить. Нет backdrop над рабочим
интерфейсом, только pointer-events:none highlight и отдельная сворачиваемая
карточка. Hub — существующий Modal с trap/return focus. Чужие формы/диалоги
ставят подсказку на паузу, не закрываются. Settings/story формы остаются mounted.
Данные tutorial хранятся отдельно от settings/лора, ключ deeprole_learning_v1.
Только этот storage change не запускает полный refresh библиотеки.

Найден и исправлен реальный UI edge: закрытый details может сохранять layout
box у descendants; getClientRects недостаточно. visibility дополнительно
проверяет closed details и разрешает только его первый summary. До исправления
расширенный runtime застрял на continuation-toggle из-за преждевременного
advance и перекрытия. Red trace: test-results-ux328-regression/...ru/320/trace.zip;
прогон остановлен после первого timeout, не объявлять его успешным.
После исправления расширенные 4 RU/EN × 320/900 прошли за 31.1s. Затем уточнены
реальные подписи кнопок, lang и пауза на inline form. Полный production прогон
28/28 прошёл за 4 min, test-results-ux328-release: 4 обучения + 20 bracket
runtime + 4 world UI. После этого добавлен только startupDeadline чтения
optional learning progress, чтобы незавершённый storage read не держал весь
App в loader. Новый unit проверяет timeout и игнорирование позднего результата.
Typecheck clean; targeted unit/component/startup/compat 9 файлов / 200 passed.
После последнего bounded-read build все 4 обучения заново прошли за 31.9s,
test-results-ux328-final-bounded. Не выдавать это за повтор всех 28 после guard,
полного unit набора проекта или личный DeepSeek live. Content/injection binary
не менялся: content.js SHA256 4BDBDEA7DD0E8DE709059C750E78AAB2645428BCF4EC945F3CF703899883C898.

Финальный архив: downloads/DeepRole-Brave-guided-start-20261019.zip,
SHA256 0B68AF2D7E21A76205BA451629F65A7BFD3DDEC6480D13943B098B0D94D5C5C8.
Canonical Chrome и .output Chrome ZIP скопированы из этого же build без
повторной сборки. Firefox MV3/ZIP пересобран, UI/live Firefox не проверен.
Runtime ZIP проверяются по байтам с папками сборки; source ZIP актуализирован
финальными документами. Снимки: docs/benchmarks/ux328-welcome-ru-320-20261019.png,
ux328-tour-en-320-20261019.png, ux328-guide-en-900-20261019.png. Проверены обе
локали на 320/900, tight 320×520, keyboard/Escape, reduced-motion, scoped axe,
real navigation/summary, profiles editor pause, отсутствие model POST и
изменений records до отдельного synthetic seed. Собственных headless root
browser processes после тестов не осталось. Личный Brave не использован.

Подробности и источники дизайна: docs/ONBOARDING.md. Lazyweb/Impeccable Onboard,
Operate и Emil motion применены без установки внешних scripts/skills. Skills
ux-copy/i18n/testing-qa: короткий язык, паритет переводов, synthetic/live отдельно.
Личный браузер не использовался, личное расширение автоматически не обновлено.
Тестовые профили создаёт/закрывает Playwright; чаты пользователя не менялись.

После установки пользователем: нажать книгу в меню, проверить welcome на
чистом профиле при необходимости. Не предлагать удалять основное расширение
или данные ради первого запуска. Затем вернуться к RP-05 precision / RP-08
replay и личному bracket live, которые UX328 не заменяет.
До отдельного запроса пользователя о push эту реализацию не коммитили;
сводка пакета передачи теперь находится в новом верхнем разделе.

## Текущая работа — RP327, свежая политика мира перед отправкой

После неуспешного RP326 live пользователь разрешил исправление. Добавлена
репродукция `silent-setting` в tests/e2e/story-bracket-runtime.spec.ts:
открытая страница загрузила false, сохранённая политика изменилась на true
без change notification. На прежнем Chrome binary actual POST содержал normal
character/choice mode вместо read-only: точное assertion failure, не timeout,
`.output/rp327-stale-policy-red.log`. Это доказанная ошибка класса stale snapshot,
но не доказательство единственной причины прежнего live: saved boolean там
не удалось проверить. Пользователь не понял вопрос о выборе мира; не винить его.

В REQUEST_CONTEXT перед updateContext теперь repository.get только выбранного
world. После await проверяются исходный page scope, generation и context scope;
только bracketedOoc заменяется в loaded worlds, игровой snapshot не подменяется
несогласованными sharedGame данными. Полную библиотеку на каждый send не читаем.
Durable capture по-прежнему классифицирует по сохранённому миру и сохраняет
purpose навсегда для данного запроса. Не скрываем choices по стилю ответа.

Новые silent-setting сценарии: on без уведомления -> OOC actual POST/capture;
off до malicious reply -> запрет эффектов и OOC после reload; silent on перед
mixed turn -> notes + обычные updates; silent off -> whole bracket обычный
игровой, старый capture всё ещё OOC. XHR/fetch × RU/EN. Legacy сценарии теперь
действительно включают через UI Save в уже открытом чате (раньше только seed).
Первое UI прохождение 1/1 прошло; матрица UI 3/4, EN XHR не прикрепил notes ко
второму POST, ранее был и startup timeout. Повторить на исправленном binary;
не объявлять эти старые результаты финальными. Assertions/timeouts не ослаблены.

Финальные targeted: 5 файлов / 180 passed; дополнительно capture/client/injection/
service compatibility 4 файла / 98 passed. Всего 278, без изменения assertion
limits. TypeScript clean. Это не повтор полного 9k unit набора. Окончательный
Chrome build 105 s, затем 4/4 новых silent-setting runtime прошли на одном binary
в serial за 1.1 min: `.output/rp327-stale-policy-green.log`. Полная матрица
runtime+production UI также завершён: 24/24 passed одним serial прогоном за
3.8 min, `.output/rp327-runtime-final.log`, `test-results-rp327-final`.
Это 20 bracket runtime (XHR/fetch × RU/EN × managed/legacy/manual/cards-off/
silent-setting) и 4 production UI (RU/EN × 320/900). Прежние 16 отдельных
story-ooc-runtime НЕ запускались заново в этой итерации; не выдавать 24 за весь
набор browser tests. Старые неуспехи до исправления выше не скрыты.

Chrome/Brave архив `downloads/DeepRole-Brave-bracket-send-fix-20261019.zip`,
SHA256 `7F5713887E2F1A355DDD1C4D16C40EA09411F23FF5B4947BF7AC2E8A2835BE9F`.
Создан непосредственно из протестированной .output/chrome-mv3 без нового build;
canonical Chrome совпадает. FF MV3 build/zip прошёл за 13.5s. Runtime ZIP по 23
SHA-matched files; source 974 (добавились 2 RP326 live screenshots), forbidden
paths/duplicates 0. Финальные QA документы синхронизированы в source ZIP
без пересборки проверенного Chrome. FF live/UI не подтверждены.

Личный Brave в этой итерации пока не менялся. Попытка открыть extension sidepanel
напрямую через browser tools отклонена URL security policy; обходов не делали.
Не пытаться читать его через raw CDP/файлы профиля. Можно проверять собственные
synthetic temporary profiles и готовить новую сборку для установки пользователем.
Для личного live после установки использовать НОВЫЙ вопрос; прежние неудачные
bracket sends не переклассифицируются задним числом. Вопрос пользователю о
настройке мира не дал подтверждения её сохранения — не утверждать обратное.
Пакет готов к установке поверх прежней папки, затем reload расширения и DeepSeek;
повторный импорт лора не нужен. Code/runtime после успешной матрицы не менялись.
Следующее — личный live по bracket whole -> mixed -> bracket -> reload после
обновления пользователем; затем прежний RP-05 precision / RP-08 replay.
Ничего не коммитили/не пушили, несвязанные локальные изменения сохранены.

## Предыдущая live-проверка RP326 — скобки НЕ прошли

После сообщения пользователя об обновлении расширения и включении настройки
проверен прежний личный Brave/DeepSeek чат «Проверка памяти», мир
«RP319 — Чистая мастерская (тест)». Новые вкладки/окна не создавали.

- Введён `[Кто сейчас находится в мастерской и было ли передано что-нибудь во
  время последнего обмена кивками? Ответь кратко.]`. До отправки AX показывал
  «Вне игры — состояние сцены не меняется». После ответа — «Обновлено после
  ответа» и четыре игровых варианта. DeepSeek ответил только на вопрос.
- Перезагрузка страницы НЕ устранила наблюдаемое поведение: второй
  `[Напомни, кто сейчас в мастерской. Ответь одним предложением.]` снова
  получил четыре варианта. После перезагрузки уже в черновике не наблюдалась
  внеигровая плашка. Не делать вывод, что boolean точно сохранился/сбросился:
  редактор настройки в этом live не удалось прочитать (меню — белый iframe).
- Смешанный ход `Я, Мира, спокойно киваю Норе, оставаясь на прежнем месте в
  мастерской. [Опиши только короткий ответный кивок, без новых обещаний и
  передачи предметов.]` дал короткий ответный кивок и четыре игровых варианта.
  Это ожидаемый вид ответа, но НЕ доказательство передачи новой инструкции.
- Контроль `OOC: Напомни, кто сейчас в мастерской и передавались ли предметы
  во время последнего обмена кивками. Ответь одним предложением.` работает:
  внеигровая плашка, вариантов 0, после reload это сохраняется.
- После финального reload DOM-зеркала сохранённых пользовательских запросов
  показывают у ОБОИХ whole-bracket запросов normal character/choice instructions,
  read-only блока нет; у mixed нет bracket-notes блока; у явного OOC read-only
  есть, choice instruction нет. Это чтение DOM истории, НЕ перехват actual POST
  и НЕ аудит IndexedDB. Отметка теряется не только на этапе показа вариантов.
- В финале Мира/Нора: в сцене 2, всего 2, обе «Спокойствие», новых людей нет;
  поле ввода пустое, меню закрыто. Хранилище фактов напрямую не проверяли.

Скриншоты: `docs/benchmarks/rp326-live-brackets-before-reload-20261019.png`
и `docs/benchmarks/rp326-live-ooc-control-20261019.png`. Исходный код/ZIP не
менялись: пользователь просил проверить, не исправлять. Эти QA заметки новее
документации внутри прежнего source ZIP. Не объявлять RP326 live зелёным.

Следующее: проверить сохранённый bracketedOoc у ТОГО ЖЕ мира и его прохождение
через refresh / REQUEST_CONTEXT / updateContext / durable capture. Отделить
неприменённую настройку от ошибки отправки; пока причина не доказана. Нельзя
просто скрыть варианты постфактум или угадывать OOC по стилю ответа DeepSeek.
После разрешения на исправление — минимальная репродукция и regression test,
затем новый пакет и повтор live. Общие остатки full runtime/Firefox QA ниже
по-прежнему открыты. Commit/push не выполнялись.

## Новая актуальная точка — RP326, сообщения в квадратных скобках

Пользователь явно выбрал: целое `[сообщение]` — вне игры; пояснение в `[]`
внутри хода не выключает игру; настройка отдельная у каждого мира.
`WorldProfile.bracketedOoc?: boolean`, по умолчанию false/undefined. Никакой
миграции или пересмотра старой истории. Редактор: Миры → Мир и профили → Изменить.
Опция сохраняется только Save, через прежний putIfUnchanged; экспорт/clone
сохраняют boolean. RU/EN copy и видимая область действия, не глобальный settings.

Новый iterative literal-aware parser `story-brackets.ts`: внешняя пара вокруг
всего непустого текста, вложенность/переносы; inline notes не переводят весь ход
в OOC. Quoted text/backtick+tilde code/Markdown links/escapes остаются данными.
Для распознавания старых stand-alone OOC команд скобки маскируются, в том числе
незакрытые и labels: спрятанная внутри них команда не должна выключать весь ход.
Оригинальный транспорт/цитаты/история НЕ режутся. Старый явный `[OOC] text`
и остальные explicit/manual режимы сохранены. Whole `[]` intentionally only opt-in.

Frontend compile + character request gate + durable pre-send transaction используют
правило текущего мира. Режим capture заморожен, его не пересматривают при изменении
настройки; полный OOC не получает roleRoster/accompaniment и не даёт записи даже
при ошибочных metadata модели. Для mixed turn добавляется бюджетируемый короткий
`deeprole_bracket_notes`, normal updates/choices работают. Это инструкция модели,
НЕ гарантированный семантический фильтр любых придуманных в ответе событий.
Поиск целого OOC снимает внешнюю оболочку только локально, прошлый retrieval сохранён.

UI QA нашла существующий конфликт React keys: WorldEditor и соседний CastSetup
получали один world.id. Cancel оставлял orphan form, reopen давал две формы.
WorldEditor key теперь namespaced `world-editor:...`. Проверка не ослаблена:
после Cancel ожидается 0 forms, повторное открытие показывает несохранённое off.

Unit: 332 files, полный прогон `.output/rp326-unit-first.json`: 9 571 passed,
20 timeout (18 × 5s, 2 × 30s), 5 прежних todo. Ровно все 20 timeout затем
повторены serial с прежними timeout и без изменений runtime/tests: 20/20 passed,
`.output/rp326-unit-timeout-rerun.json`. Совокупно все 9 591 прошли, но НЕ называть
это одним чистым полным прогоном. Целевые mode/retrieval/storage/UI 147/147,
включая новые 58 core + 2 control и две дополнительные backend OOC вариации.
UI Chromium RU/EN 320/900 4/4 прошло после key fix. Повторные dev-server UI
попытки (в том числе Firefox 4/4) упёрлись в page/module-load timeout до нового
переключателя. Отдельно добавлена проверка production UI на установленной MV3,
чтобы проверять реальное сохранение/reload независимо от Vite/HMR. Firefox UI
пока не считать проверенным. Не меняли assert/guard/timeout ради зелёного отчёта.

После full прогона уточнена ТОЛЬКО область mixed instruction: ONLY original
draft in [User message], never supplied lore/profiles/memory. Это не смена parser,
retrieval или guards. На окончательном коде повторены targeted 147/147 и TypeScript,
Chrome build clean. Последняя сборка на нагруженном ПК заняла 253 s, не прежние 10.5s.
Первый параллельный installed прогон: новые 16/16 прошли; в прежних OOC сценариях
появились ошибки ожидания, дальнейший прогон прерван (rp326-runtime.log/results).
Найдено несоответствие synthetic fixture: RU composer, но POST следующего хода
жёстко английский. Старый fixture теперь отправляет ТОЧНЫЙ локализованный gameDraft,
как новый, и дополнительно проверяет exact suffix; assertions не удаляли.
Окончательный production UI — 4/4 pass RU/EN × 320/900, Save/Cancel/Space,
world isolation/reload/scoped axe. Скриншоты docs/benchmarks/rp326-brackets-*-narrow-
20261019.png просмотрены. На окончательном Chrome binary serial story дал 5 pass,
но остановлен после ready(false) вместо closed(true) за 15s и startup empty
context за 12s (до работы нового режима). Без Vite повтор также остановился на
startup timeout, НЕ считать прогон зелёным. Логи rp326-story-final / focused-final /
clean и test-results-rp326-* локальные; их нет в Git/source ZIP.

Добавлен `playwright.extension.config.ts` только для трёх absolute-URL production
specs: им Vite не нужен. Для дальнейшего прогона — этот config, workers=1; не
мешать с unit/build. Временные browser profiles лучше держать вне watched project,
но текущий Windows запуск нестабилен и там. Возможную нагрузку watcher не выдавать
за доказанную причину всех failures. Уже использованный обход ESBuild — TEMP/TMP
в .tmp-rp319-esbuild-build: попытка Firefox в системной Temp дала remove Access
denied, повтор упаковки идёт через workspace Temp. Не увеличивали assertion limits.
Остаток QA: чистый полный installed прогон на стабильной машине и live после
обновления пользователем. Firefox UI не подтверждён. Нельзя писать «всё прошло».

Пакеты ГОТОВЫ: Chrome/Firefox по 23 entries, исходники 972. Browser entries
побайтово совпали с output, forbidden entries 0; финальные docs синхронизированы
в source ZIP отдельно, без повторной пересборки проверенного Chrome. Chrome
23/23 runtime files неизменны относительно production UI/serial проверок.
Новый архив: `downloads/DeepRole-Brave-bracket-messages-20261019.zip`, SHA256
`F1D967FCC4A24C6EC9CCDFD682497E6931CCCB208FCE5A4ED74E040EE29FD28B`.
Canonical Chrome/Firefox/sources обновлены; установленный Brave — НЕТ.
Финальный TypeScript после добавления test config clean. Firefox workspace-TEMP
повтор build/zip прошёл за 22.5s; первоначальный Access denied сохранён в log.
Ни Code/UI, ни assertions не переписывали после этого ради успешного пакета.
Нет нового live в личном DeepSeek. Реализация готова к пользовательской проверке,
но чистый полный browser run остаётся отдельной незакрытой QA задачей.
Новый browser fixture
проверяет XHR/fetch × RU/EN × managed/legacy/manual/cards-off, read-only actual POST,
malicious scene/fact/choices, reload и следующий mixed game turn. Личный DeepSeek
не трогали. Документ пользователя: docs/BRACKET-MESSAGE-MODE.md.

Следующий основной этап остаётся RP-05 precision и RP-08 replay; новые скобки —
отдельный запрос пользователя, не закрытие всех задач бесконечного RP. Push не просили.

## Предыдущий этап — RP325, новый осторожный отбор памяти

Реализован `src/core/story-repeat-selection.ts` + `compileRepeatContext` перед
старым task-progress recall. `repeatSelection:false` — внутреннее сравнение,
не пользовательская настройка. Frozen RP268 opts явно отключают новый этап.
Новый этап не меняет прежние classifiers/digests/fixtures/gold.

Только точная целая прямая речь с доступным frozen speaker, episode и явным
отсутствием новых сведений/действий/обязательств считается пустым повтором.
Task/claim/пересказ/неизвестная роль/код/новое условие/«новых событий не было»
не подходят. Все неповторные matching + прежде выбранные substantive sources
сохраняются атомарно до 128 rows и полного бюджета, иначе exact prior.
Хранилище, авторский лор, история и фактическое выполнение задач не меняются.
У вопроса о целом многословном предмете есть literal fallback, даже если вся
память об одном предмете; имена/местоимения/числа/команды не дают такого proof.
Одиночное действие использует прежний parser, ambiguity guard остаётся на wire.
Составные действия без полного покрытия остаются старым fallback.
После принятия нового набора obsolete budget warning прошлого большого bundle
заменяется на unverified/query, не на обещание полного понимания сюжета.

Независимый fixture (создан до реализации): RU/EN маяк/занавес, Ирис/Лев,
семь источников: разные владельцы обещаний, два условия, частичный прогресс,
отдельное completed, belief, новое условие в разговоре, revoked claim.
0/80/400 повторов. 16/16 целевых вопросов/одиночных действий с повторениями
содержат все семь sources. 36 сравнений: 51878 → 42392 estimated tokens
добавки, 8 более коротких запросов, 238 повторных выбранных строк не переданы.
Некоторые запросы ДЛИННЕЕ: полные факты дороже прежней неполной выборки.
Старые 588 RP323 extras НЕ удалены/не объявлены пустыми. Не API tokenizer.

Тестовые assets RP319-world/probe/RP324-probe перенесены из прежнего sources ZIP
в tests/fixtures; все три byte-identical. Ни один тест больше не читает downloads.
Пользовательские D downloads/README.md и deeprole-live-qa-2026-10-16.json остаются.

ФИНАЛЬНЫЙ unit: 330 файлов, 9 529 passed, 5 прежних todo, 0 failed,
`.output/rp325-unit-final.json`. Все 129 новых прошли, включая 2 проверки stale
coverage warning. Первый full run сохранён как rp325-unit-first.json: два failure
были ссылками на удалённый downloads/README; RU/EN ссылки переведены на папку,
пользовательское удаление не отменялось. TypeScript повторён после E2E harness,
clean. Runtime/unit fixtures не менялись после финального полного прогона.

Installed MV3: прежние 28 compatibility прошли; новый
`story-repeat-selection-runtime.spec.ts` повторён по 3 раза RU/EN: 6/6 passed,
1,4 min. Actual POST после обычного review/accept 23 facts содержит все 7 важных
sources без 16 пустых повторов: вопрос/действие/OOC, reload. Все facts, frozen role
seeds и episodeSources остаются structurally equal, два promisor ID раздельны.
Всего 30 разных browser scenarios / 34 успешных исполнения в двух прогонах.
Первый общий browser run: 28 passed, 2 новых failed; diagnostic repeat EN passed,
RU failed на последнем OOC. Trace: предыдущий dispatch ready, OOC waiting,
correct 7-source report уже готов; тест слал следующий probe/reload до durable
stream close после XHR load. Исправлен ТОЛЬКО harness: обычный draft fill и
ожидание accepted/closed/sawFinish для ТОЧНОГО native assistant key перед next/reload.
Никаких sleeps/увеличения timeout/ослабления production guards. Все contexts
закрыты finally. First traces в test-results / test-results-rp325-debug,
6/6 final в test-results-rp325-verified; не входят в source ZIP. Живого аккаунта нет.

Chrome/Brave и Firefox MV3 собраны/упакованы; 23/23 файлов каждого browser ZIP
и все 965 source entries сверены SHA с диском, forbidden private/temp/test/nested
ZIP entries 0. Source ZIP перепакован после финальных docs. Chrome НЕ пересобирали
после installed tests; четыре critical binary SHA совпадают с tested build.
FF — build/package, НЕ установленный Firefox E2E.
Новый: downloads/DeepRole-Brave-memory-selection-20261019.zip, идентичен canonical
chrome ZIP. SHA256: 2CF93ADE94CF8DD7F9AEEC82A11FF768AB349CA73FFB0C7FDA5DFA0AB8A62B19.
Старые именованные ZIP не удаляли. Не делали commit/push и не обновляли личный Brave.
Подробности/границы — docs/RP05-REPEAT-SELECTION-RESULTS.md.

Дальше: новые независимые естественные формулировки и составные действия с
полным покрытием ВСЕХ предметов (нынешний непокрытый compound — exact fallback),
затем RP-08 replay. Для нового live нужен update пользователем; старый RP324
live ниже НЕ проверка нового отбора. Не повторять пройденную QA как новую работу.

## Актуальная точка — RP324 LIVE ПРОЙДЕН, 19 октября 2026

Пользователь обновил Brave и оставил тот же чат «Проверка памяти», мир
`RP319 — Чистая мастерская (тест)`. Выполнены три НОВЫЕ пары:
- rows 27/28: составной prefix-table, прежние 8 учебных sources, 6/6 ответов
  верны. UI 2 → 2, вне игры, choices/recovery 0. Этот набор уже был в истории,
  поэтому отдельно не доказывает чтение новой таблицы.
- rows 29/30: обычный игровой ход, Мира и Нора обмениваются спокойными кивками,
  обе остаются на местах. Статус обновления, 4 готовых варианта; НЕ выбирали.
  Нора теперь «Обращается к герою» — допустимое игровое изменение после кивка.
- rows 31/32: независимые НОВЫЕ Эйра/Дан, янтарный диск/карта/колба/бирка/
  антенна, код 7396. Gold задан ДО отправки. 6/6 ответов верны: отсутствие
  согласия при присутствии второго человека запрещает передачу; чехол обязателен;
  завершённая карта не отменена, belief не факт, код не открывает радиорубку,
  бирка не получена, антенна только план. Эти тестовые персонажи не добавились.

Reload сохранил тот же мир, две карточки и их title относительно игрового хода,
внеигровой статус, choices/recovery 0 и пустой composer. DOM server readback:
user row 29 — read_only false/choice_mode true; row 31 — наоборот. Пакет в row
31 имеет новый format, 6 строк и JSON точно равен отправленному свежему packet.
Это DOM readback, НЕ перехват POST. Память подавалась ЯВНЫМ учебным сообщением,
не автоматическим retrieval из канона. Backward metadata refs, auto extraction,
полная DB/events неизменность и память за пределами native context этим live
НЕ доказаны. Runtime/пакеты не меняли; новая установка/импорт НЕ нужны.

5 снимков `docs/benchmarks/rp324-live-{before,ooc,game,fresh,reloaded}-20261019.png`.
Последний снимок показывает все 6 новых ответов/две карточки/пустой composer.
Исходную вкладку оставили открытой, новых вкладок/окон не создавали. Длинный
paste сайт дважды оформил unsent .txt; нажали Paste original ДО Enter, оба раза
отправлен обычный OOC-текст, не вложение. Нажатие Control+End на body не прошло;
не повторяли вслепую. Для финального обзора помогла обычная Shift+Tab навигация.
Отчёт и заранее заданный fresh gold: `docs/RP05-REPEAT-PACKING-LIVE-20261019.md`.

ВАЖНО: loose QA probe-файлы/тест-мир и README в downloads удалены вне этой
итерации. Пользовательские удаления НЕ отменяли. Старый probe прочитан из
source ZIP. Тесты пока ссылаются на эти отсутствующие loose assets, поэтому
9400 passed ниже — результат ДО этой очистки, не новый unit-прогон. Перед
следующим code milestone перенести неизменные QA assets из source snapshot
в tests/fixtures и отвязать тесты от downloads; не восстанавливать удалённый
пользователем мусор без необходимости. Source ZIP остаётся build-time snapshot
ДО этих doc-only live заметок; браузерные пакеты по-прежнему актуальны.

Далее: RP-05 точность отбора/меньше лишних sources (588 в прежнем корпусе),
без потери условий/обещаний/владельцев; затем RP-08 replay. Отдельное UX-наблюдение:
4 готовых игровых кнопки существовали, но на game-снимке нижняя часть была под
composer/краем viewport. Это не ошибка памяти; при следующем UX-проходе проверить.
Не повторять этот smoke/установку без новой причины. Push не запрошен.

## Реализация RP324 — история сборки и автоматических проверок

Ниже статус на момент выдачи пакета; актуальный живой результат — ВЫШЕ.

Запрос: сокращать лишние повторы в передаваемой памяти без потери фактов,
условий/обещаний. Выбран lossless transport, НЕ эвристическое удаление разговоров.
«Новых событий не было» недостаточно для вывода, что сведений/условий тоже нет.

Новый `deeprole-memory-prefix-table-v1` совмещает точные literal text prefixes
с таблицей полей; decoder сначала расширяет text [p,s], затем старый строгий
columns/refs reader. Все выбранные строки и metadata восстанавливаются точно.
Candidate допускается только после decode == inline и полного request-meter.
Тот же admission без prefixes; новая упаковка только в финальном render.
НЕТ изменения выбора фактов, хранилища, авто-выполнения задач/канона. Старые
форматы decoder сохранены. `memoryPrefixTables:false` отключает только новый
кандидат для сравнения; исторический RP268 profile дополнен false, gold не меняли.

Три runtime-файла этой итерации: story-memory-transport, story-fact-context,
game-context. В них уже были старые dirty правки RP319–323; НЕ откатывать целиком.
Новые тесты story-memory-prefix-tables (35) и story-rp05-repeat-packing-audit
(165); e2e transport prefix variant теперь требует новый составной формат.
Вначале TDD 4 expected failures; после реализации 364/364 targeted (включая
старый RP323 long horizon) и ранее 208/208 старые prefix/column + новые decoder.
TypeScript clean. Chrome build готов, ZIP 23/23 SHA matched:
`DCDC21482B39B42D4C54964214749422D74773B1B4947D7E232F74D2B82CA0A4`.
Первый полный unit: 56 failures (52 historical-byte digests + 4 timing waits).
Golden files/registrations НЕ меняли: original format pin с новым encoder OFF,
дополнительное точное сравнение decoded hints и старых selection/counters.
Все 8 файлов: 583/583. Затем весь unit: 329 files / 9399 passed / 5 todo / 0 failed.
После него уточнён audit до ФАКТИЧЕСКОГО профиля `memoryTransport:'columns'` из
content.tsx (165/165, цифры те же) и добавлена проверка нового live probe (1 test).
ФИНАЛЬНЫЙ full unit после этих двух test-only уточнений ПРОЙДЕН: 329 файлов,
9400 passed / 5 прежних todo / 0 failed, `.output/rp324-unit-final.json`.
TypeScript повторно clean. Runtime с Chrome build не менялся.
Installed synthetic Edge MV3 28/28 ПРОЙДЕН, 3,1 min, без параллельного unit/build.
`.output/rp324-e2e-final.log`: RU/EN actual POST/reload с НОВЫМ prefix-table,
8 точных сохранённых facts/roles/episodes, old metadata path, 24 OOC/next-game
regressions fetch/XHR/no markers × managed/legacy/manual/cards-off. Все headless
contexts закрыты finally. Это synthetic site, НЕ новый live пользовательского Brave.

На неизменённых 144 RP323 inputs: все hints/selected/omitted/explanation
точно как при `memoryPrefixTables:false`, цели 144/144. 72 запроса выигрывают,
суммарно 348 276 → 343 156 расчётных tokens (−5 120, −1,47% добавляемого context);
1 390 608 → 1 370 118 chars. RU reef/400/completed: те же 9 строк,
2714 → 2638 tokens. Это локальный estimator добавки без user draft/native history,
не API и не «на 588
записей меньше»: прежние 588 extra records остались точными отдельными строками.
Подробности: `docs/RP05-REPEAT-PACKING-RESULTS.md`, ROADMAP RP324.

Chrome/Brave/Firefox/source ZIP ГОТОВЫ: все 23 файла каждого browser ZIP сверены
по SHA с build directories; source — 14 critical code/docs/probe/package files,
961 entry, forbidden private/temp/test entries 0. Chrome — ровно binary,
прошедший installed E2E; FF — build/package verification, НЕ Firefox live E2E.
Финальные doc-only заметки включаются повторной source-сборкой и той же SHA-сверкой;
Chrome binary после E2E НЕ пересобирается. Canonical Chrome/Firefox/source ZIP
в downloads обновлены; старые именованные архивы не удалялись.
Новый Brave: `downloads/DeepRole-Brave-repeat-memory-20261019.zip`.
Он ещё не установлен; распаковать поверх существующей папки, ↻ карточку
расширения, обновить DeepSeek. НЕ удалять расширение/мир, НЕ импортировать заново.
Старый RP323 ниже УЖЕ проходил live, новый transport — нет.
После поставки нужен живой smoke интерпретации таблицы моделью, decoder/mock не
доказывает её качество. Пользовательский Brave не трогали в этой итерации,
новых вкладок/окон нет. Не закрывать исходный чат, не удалять старые архивы.
Новый probe: `downloads/DeepRole-RP324-live-probe-20261019.txt`. Это тот же
набор 8 вымышленных sources из неизменённого RP319 probe, новый transport;
ручное decode comparison прошло. OOC framing + шестой вопрос о футляре ключа.
При живом smoke ожидать: red tube требует присутствия Норы; blue journal уже
передан, отсутствие Норы не отменяет прошлое; green capsule — belief; code не
открывает подвал/личные комнаты; spare letter не получено; brass key только
в опечатанном футляре. НЕ считать эти тестовые данные каноном текущего мира.
Дальше: после подтверждения обновления — живой smoke нового transport этим
OOC probe, проверить 6 ответов + нейтральную плашку/отсутствие choices/неизменность
сцены; затем обычный ход должен вернуть игровой UI. При отключённом browser
connection не обходить канал, не выдавать mock за live. В последний раз real
Brave connection отключился уже после RP323 smoke. Исходный чат «Проверка
памяти», мир `RP319 — Чистая мастерская (тест)`, два персонажа; Нора сделала
один шаг ближе, предметы не переданы. Ни новых пользовательских вкладок, ни
окна, ни записей в игре эта кодовая итерация не создала.
Затем RP-05 precision (без грубого удаления 588 записей) и RP-08 replay.
Commit/push не запрошены. Существующие чужие/ранние dirty изменения сохранены.

## Предыдущая точка — RP323 live после обновления ПРОЙДЕН

19 октября пользователь подтвердил обновление. В том же Brave-чате «Проверка
памяти», мир `RP319 — Чистая мастерская (тест)`, три НОВЫЕ пары:
1. «Вне игры:» — гипотетическое отсутствие Норы / условия передачи тубуса.
   Ответ отделил гипотезу/разрешение от передачи. Видимый состав 2 → 2,
   нейтральная плашка, нет recovery/готовых вариантов.
2. Игровой ход — Мира разрешает Норе сделать шаг ближе; Нора делает шаг.
   Предмет не передан, обещаний нет. Видимый состав 2 → 2, статус обновления,
   четыре готовых варианта; их НЕ выбирали. Нора теперь «В сцене», не
   «Обращается к герою». Это последнее актуальное игровое положение.
3. `OOC:` — различить разрешение шага, состоявшийся шаг и передачу предмета.
   Ответ: тубус не передавался. Карточки/видимый состав после игрового хода
   не изменились, нейтральная плашка, нет recovery/готовых вариантов.

Reload сохранил тот же мир, две карточки, OOC-статус, отсутствие вариантов,
пустой composer. Readback восстановленного DOM: user rows 21/25 — read-only,
без choice-mode; игровой row 23 — наоборот. Это локальные номера smoke, не
правило продукта и НЕ network interception. Full DB/events до/после в live не
сравнивали; их защита проверялась installed mocks. Ответы используют и текущую
переписку; новый auto extraction/за-контекстная память этим тестом не доказаны.

DOM sampling через read-only API: 100 отсчётов после первого OOC, 250 сразу
после отправки игрового, 250 сразу после второго OOC; пауза 50ms + API latency.
Recovery не наблюдался. В первом отсчёте отправки второго OOC ещё был СТАРЫЙ
игровой host при optimistic row -7, затем исчез. При новом assistant row 26
choices/recovery не было. Старый текст плашки кратко сохранялся до native GET.
Sampling НЕ MutationObserver всех кадров: нельзя заявлять математический ноль
любых однокадровых эффектов в live. Installed observer ранее проверен отдельно.

Снимки: `docs/benchmarks/rp323-live-{before,ooc,game,ooc-after-game,reloaded}-20261019.png`.
После всех проверок/итогового снимка browser connection отключился на попытке
необязательной прокрутки к ответу. Не обходили управление, новых вкладок/окон
не создавали, личный лор не открывали, исходный чат не закрывали. На последнем
снимке видны статус/две карточки, часть последнего ответа перекрыта composer;
сам ответ прочитан DOM до reload. Runtime/архивы НЕ менялись, новая установка
НЕ нужна. Source ZIP остаётся build-time snapshot до этих doc-only live заметок.

Следующее — RP-05: независимая проверка компактности, сокращать лишние повторы
в передаваемом контексте, НЕ канон/одиночные пересказы/первые раскрытия/условия.
В прежнем корпусе остаются 588 extra selected records. Затем RP-08 replay.
Не повторять пройденный smoke/установку как новую задачу. Push не запрошен.

## Реализация RP323 — мигание вариантов и старый прогресс

Запрос: убрать transient recovery после OOC и продолжить точность на длинной
истории. Runtime изменён, установленный у пользователя RP322 сам не обновился.
Новый пакет ГОТОВ: `downloads/DeepRole-Brave-progress-memory-20261018.zip`.
Распаковать поверх существующей папки расширения, ↻ на его карточке, обновить
DeepSeek. Не удалять расширение, не импортировать мир повторно.

Chrome/Firefox/source ZIP и обе build directories обновлены. Каждый browser ZIP
совпадает по SHA со всеми 23 build files; source — с 11 critical code/docs files,
без private/temp entries. Firefox — build/package verification, не Firefox live E2E.
Chrome ZIP создан из tested build; финальные изменения документации включены
в source ZIP отдельно. Push/commit не выполнялись, прежний dirty work сохранён.

Финальный installed MV3 28/28 на окончательной Chrome сборке, 2.1 min;
`.output/rp323-e2e-final.log`. Все 24 OOC/next-game + 4 exact-memory transport,
включая RU/EN delayed native GET с MutationObserver (0 transient insertions),
200 px, malicious JSON, scope/scene/profiles/events unchanged, POST/reload.
Это synthetic Edge MV3, НЕ новый живой тест пользовательского Brave.
Chrome ZIP упакован ИЗ ЭТОЙ проверенной сборки (без нового build timestamp),
все 23 файла сверены по SHA. SHA256 Brave:
`7090E7477C12A582F2848DADEF26CB542FDFEAF698EF34330642A94880B8B038`.

Финальный полный unit: 327 файлов, 9 200 passed, 5 прежних todo, 0 failed;
`.output/rp323-unit-final.json`. TypeScript clean. Это повтор ВСЕГО набора после
всех runtime-правок, включая qualifiedOwners и readiness transitions, не только
выборочный rerun упавшего теста.

Мигание воспроизведено installed Edge MV3: задержать native history GET,
MutationObserver считает вставки recovery/choices, на старом binary получено 1
вместо 0. `StoryGameClient.presentationPending()` закрывает интервал ДО scanner
GET, scope/anchor/reply signature/epoch сохраняют принадлежность. Ошибка/9s
timeout освобождает ожидание для этой попытки; не даёт purpose/write authority.
Content скрывает варианты и блокирует stale direct clicks, пока purpose pending;
неактивная shared game не ждёт scanner, который там не запускается. RU/EN
delayed GET на новой сборке 2/2, ноль вставок; полный installed regression ниже.

Первый общий installed regression 27/28 выявил пропуск возврата recovery на
следующем игровом ответе fetch/RU/cards-off. Поздний accepted ordinary receipt
тоже должен сбросить scan keys/планировать scan, когда имеется OOC. Done-key
теперь не пропускает ещё pending proof. Повтор проблемного случая 3/3; таймауты
не увеличивали. Дополнительный cross-owner TDD показал: нельзя брать владельцев
для completed sources из ВСЕХ selected tasks — только из qualified groups.
Это исправлено; полный финальный regression повторяется после этих правок.

Ещё один общий installed прогон: 27/28, normal EN metadata не принят в историю
до ожидания. Happy-path не ждёт durable wire-finish; тест/timeout не ослаблялись.
Обобщён readiness reset: `storyReplyProofChanged(prior,next)` только для valid
local accepted, при новом accepted или новом closed+finish. И ordinary, и OOC;
дубли/restored/malformed/unconfirmed не дают upgrade. Обычный stream-finish,
пришедший после scan done, также запускает сверку, даже без OOC history.
Readiness НЕ даёт write authority и не посылает сообщение модели. 5 новых
transition unit сначала fail, затем 58/58 client+purpose. TypeScript clean.
Окончательные full unit/installed данные — верх секции; промежуточные ошибки
ниже сохранены как история, не актуальный blocked status.

Поздний общий повтор: 24/24 OOC, но один codec happy-path получил
story-native-line-unavailable в manual resolve (trace подтверждён). Fixture
теперь ждёт наблюдаемое durable wire-finish/обновлённый UI; safety-guards
native-line/stale/binding повторяет только с заново прочитанной очередью в
прежних 10 итерациях. Unknown errors и финальные 8 exact persisted facts/POST/
reload не ослаблены. Runtime/таймауты для этого шага не менялись. Не называть
это ослаблением native authority или полным пропуском errors.

Новый авторский корпус `story-rp05-long-horizon`: 3 независимых сюжета, RU/EN,
0/80/400 повторов, бюджеты 6000/10000, 4 запроса = 144 комбинации (108 тематических
и 36 owner-controls). Найдены потеря старого частичного прогресса и лишние
события у RU «Известно, кому принадлежит…». Добавлен узкий query-only
`taskProgressRecall`: целое короткое название выбранной open-задачи, явные
слова статуса, сохранённые source/owner IDs. Speaker/promisor progress должен
совпасть с сохранённым владельцем, не именем/порядком roster. Дополнение только
полным bundle вместе со ВСЕЙ старой выбранной памятью и полным бюджетом. При
недостатке места старый результат возвращается целиком. Не стирает разговоры,
не закрывает задачи, не выводит отсутствующие условия и не меняет канон.

Итог нового корпуса 144/144, 0 потерь quote/kind/task/role/episode/invariants;
18 tight-budget, 2 OOC-equivalence, 12 helper controls. 588 дополнительных
выбранных записей — компактность не идеальна, следующий RP-05 именно об этом.
Bindings в fixtures заданы явно, НЕ доказательство автоматического извлечения
из живой переписки. Первичный report `.output/rp323-memory-before.json` до
добавления явного promisor в seed согласно исходному обещанию; остальные тексты
и gold не менялись. Полный первый regression нашёл один дефект TEST fixture:
новые clones oversized-group не имели frozen speaker, поэтому тест ожидал
не тот путь. Исправлена только заглушка roles, не production guard/лимит.
Historical RP268 option profile явно выключает новый supplement.

Следующее: независимая проверка лишних повторных обсуждений/разных источников
и снижения контекста без потери substantive evidence; затем RP-08 replay.
Новый live после установки RP323 ещё нужен. Повторно импортировать мир НЕ нужно;
тот же RP319 чат: Мира + Нора, Нора у двери. Пользовательский лор/Brave этим
этапом не трогали, тесты запускались в отдельных synthetic headless контекстах,
закрывающихся в finally. Не говорить, что mocks равны живому DeepSeek.
Подробности: `docs/RP05-LONG-HORIZON-RESULTS.md`. Commit/push не запрошены.

## Предыдущая точка RP322 — живой повтор пройден после обновления Brave

Пользователь подтвердил установку RP322. В том же синтетическом RP319 мире/чате
последняя старая OOC-реплика уже получила нейтральную плашку без recovery.
Затем три НОВЫЕ пары сообщений:
1. «Вне игры:» — гипотетическое возвращение Норы, разрешение не стало передачей.
   Состав 1 → 1, нейтральная плашка, нет игровых вариантов.
2. Обычный игровой ход — Нора действительно возвращается к двери мастерской.
   Состав 1 → 2 (Мира/Нора), статус «Обновлено после ответа», четыре варианта.
3. «OOC:» — гипотетический уход Норы. Состав 2 → 2, плашка нейтральная,
   recovery и готовые варианты убраны. После reload по-прежнему 2, статус OOC,
   нет вариантов; выбранный тестовый мир сохранился, черновик пуст.

Readback DOM восстановленной истории: новые user rows 15/19 содержат
`<deeprole_read_only>` и не имеют choice-mode; игровой row 17 без read-only,
с обычным character/choice-mode. Это readback страницы, НЕ actual POST перехват
и НЕ установление точного fetch/XHR транспорта. Full DB/events до/после live
не сравнивались; их защита проверена прежними installed mock-E2E. Нейтральный
мир не пополняли структурированными фактами: правильные ответы про тубус
используют также прежнюю переписку и не доказывают новое auto extraction.

Переходный UX: сразу после последнего OOC-ответа до окончания GET кратко была
видна recovery-кнопка, затем она исчезла вместе со сменой статуса на OOC.
Установившийся UI и reload корректны. Отдельная необязательная UX-задача —
убрать это краткое мигание без угадывания назначения неподтверждённого ответа.
Runtime в живой проверке не менялся; новый Brave-пакет/повторная установка
НЕ нужны. Кодовую проблему RP321 для settled UI этим smoke закрыли.
Чат оставлен открытым, дополнительных окон/вкладок не создавали, личный лор
не открывали. ВАЖНО: Нора теперь В СЦЕНЕ вместе с Мирой; прежние указания
«Нора отсутствует» ниже — историческое состояние ДО этого теста.
Снимки: `docs/benchmarks/rp322-live-{before,ooc,game,ooc-after-game,reloaded}-20261018.png`.
Следующее — точность необязательного подбора RP-05 на разных сюжетах/бюджетах,
затем нагрузочный replay RP-08. Не повторять уже пройденный smoke как новую задачу.

Пользователь попросил исправить найденный RP321 live дефект до рабочего
результата. `storyReplyPurpose` теперь может сверить завершённую серверную пару
с точным локальным accepted capture: world/binding/chat, native parent, полный
confirmedDispatchText, user/assistant IDs; wire link, если есть, не должен
противоречить паре. Не требуется XHR finish для fetch. TDD два положительных
кейса сначала падали, затем прошли. Не угадывать по словам OOC в ответе.

`StoryGameClient` переиспользует уже прочитанный managed snapshot; legacy при
принятом OOC читает native history через тот же bounded GET отдельно, без
storyGameStatus/runStoryGame и без включения tracking. GET сериализуется с
managed-read; cache привязан к scope/URL/native anchor и версии финального
текста (только invalidation, не identity proof). Генерация, первая accepted
отправка и lock/reset инвалидируют его; late result проверяет epoch/scope/base.
Fetch response не клонировали/не читали, stream parser/transport не расширяли.

Page scanner пересчитывает OOC ПОСЛЕ чтения пары, а не только до него;
accepted OOC вызывает rescan и без XHR closed. Варианты фильтруются также при
выключенных карточках. Native virtual-list identity проверяется тестовой DOM-
обёрткой; обычный следующий ответ возвращает обычный статус/варианты.
`matchingStoryUserCaptures` дополнен локальным OOC без wire link только для
исключения игровых последствий по точному source/parent. Assistant fallback
для XHR требует явно переданную завершённую user-пару. Игровой XHR без wire
link/restored OOC этой поблажки не получает; роли/платные изображения не разрешены.

Полный regression: 325 файлов, 9 013 passed, 5 прежних todo, 0 failed;
`.output/rp322-unit-final.json`. Целевая группа до трёх дополнительных cache
тестов: 160/160. TypeScript clean. Финальный installed MV3: 28/28, RU/EN ×
fetch/XHR/XHR без маркеров × managed/legacy/manual/cards-off (24) плюс прежние
memory transport POST/reload (4). Проверены скрытие recovery И присланных
вариантов, неизменность состава/состояний/собеседников/профилей/событий, следующий
игровой ход. RU/EN 200 px просмотрены. В первом расширенном прогоне 22 passed /
6 failed: стенд ошибочно требовал character_mode при выключенных карточках;
исправлено только ожидание, затем весь расширенный прогон 28/28. Личный Brave
этим этапом не трогали; headless synthetic контексты
закрываются в finally. Подробности: `docs/RP05-OOC-NATIVE-PAIR-RESULTS.md`.

Пакет для установки: `downloads/DeepRole-Brave-ooc-native-pair-20261018.zip`;
сборки Chrome/Firefox/source и canonical ZIP обновлены для этой точки, все 23
entries каждого browser ZIP и критические source-файлы сверены по SHA.
Исходная сборка фиксировала live как pending; актуальный результат — верх этой
секции. Повторно обновлять установленный Brave для теста не требуется.

Запланированный live RP322 выполнен после обновления, см. верх секции.
Конкретный транспорт/причина RP321 не установлены сетевым наблюдением, но новый
native-pair путь работает в проверенном живом клиенте. Не переходить к угадыванию
по прозе при других неизвестных ответах. Дальше RP-05/RP-08.
Commit/push не запрашивались. Ранний RP321 failed сохранён ниже как история.

## Предыдущая точка RP321 — live smoke выявил ошибку UI, не закрыт

После сообщения пользователя «обновил расширение, тот же мир и чат открыты»
проведён live smoke в том же RP319 тестовом мире, личные миры не открывались.
Два новых OOC-вопроса (один через Enter, второй штатной кнопкой DeepSeek):
1. Гипотетическое возвращение Норы/передача тубуса: модель верно разделила
   разрешение, выполнение и настоящую сцену. В панели осталась только Мира (1 → 1).
2. Кому возвращена серебряная печать / передан ли тубус: модель верно ответила
   «Норе», не смешала предметы. В панели по-прежнему одна Мира.
НО оба раза сохранились старый missing-статус и кнопка «Предложить варианты».
После reload та же ошибка. RP321 live НЕ ПРОЙДЕН; прежние 10/10 mock-E2E
не являются доказательством работы в текущем веб-клиенте DeepSeek.

Readback DOM восстановленной истории: обе новые пользовательские записи
(native virtual keys 11 и 13) содержат `<deeprole_read_only>` и read-only
character reference; ответы имеют native keys 12 и 14. Эти номера локальны
только этому синтетическому smoke, не правило продукта. До reload оптимистичная
строка показывала только draft — по ней нельзя судить об отсутствии инъекции.
Это DOM readback, не actual-POST перехват. Full DB/events до/после не сравнивались.
Нейтральный мир не содержит новых структурированных игровых фактов; верные
ответы опираются и на существующую переписку, не доказывают новое извлечение.

Панель доставки всё ещё показывала прежнюю игровую отправку в 21:25:25.
Проверка кода `memoryDeliveryView` объяснила это: он намеренно фильтрует только
purpose=user-turn. Это НЕ доказательство отсутствия OOC capture/памяти. Не чинить
инъекцию на основании одного старого времени. Внешний API/native transport в
живом браузере не установлен. При чтении кода найден важный пробел покрытия:
`storyReplyPurpose` требует closed+finished native link, а stream observer сейчас
только XHR; installed OOC тесты также посылают только XHR. Fetch — кандидат для
следующей диагностики/покрытия, но не установленная причина текущего live-сбоя.
Не ослаблять точную принадлежность до догадки по тексту/текущему draft.

Нужно дальше: установить, где теряется доказательство принадлежности OOC-ответа
в реальном клиенте; добавить релевантный транспортный regression, исправить и
повторить live. Обычный игровой ход в этом smoke не посылался: сначала нужно
закрыть OOC UI. Затем возвращаться к точности необязательного подбора RP-05 и
нагрузочному RP-08. Это диагностическая итерация, runtime/архивы не менялись,
новый пакет пользователю не требуется. Следующая реализация потребует обновления.
Открытый исходный чат оставлен, черновик пуст, добавлены только две тестовые пары.
Служебных вкладок/окон не оставлено. Снимок:
`docs/benchmarks/rp321-live-ooc-failed-20261018.png`.
Подробнее: `docs/RP05-OOC-UX-RESULTS.md`, верх ROADMAP. Push не выполнялся.

## Реализация RP321 — OOC-плашка и поиск без помех от обёртки

Запрос пользователя: исправить плашку после внеигрового ответа и продолжить
roadmap. Новый статус RU/EN: «Вне игры — состояние сцены не меняется» / «Out of
character — scene state is unchanged». Обычный missing/error не переименован.
`storyReplyPurpose` использует одну валидную локальную accepted+finished native-
пару с точными world/binding/chat/assistant ID. Не угадывает по прозе, черновику
или порядку capture; restored/ambiguous/incomplete остаются unknown. Это только
доказательство для UI, не новый допуск к записи. Присланные и ручные recovery
варианты под таким OOC не показываются; прямой вызов также проверяет цель.
При получении позднего receipt scanner повторяется. Следующий игровой ответ
снова получает обычный статус/варианты. Защиты RP320 от записи сохраняются.

Следующий узкий шаг RP-05: `readOnlySearchDraft` снимает только уже распознанную
начальную OOC-обёртку с поисковой копии. `compileGameContext` делает это только
для readOnly, включая лишь начальный draft связанных character references;
recent suffix не переписывает. Исходные draft, dispatch, POST, факты/лоры
не меняются. Естественная команда не продолжать сцену не режется на предложения.
Mixed/quoted/unmarked остаются дословными. Глобальный pruning не включён.

Контролируемая проверка на прежнем сюжете RP316: 12 вопросов × RU/EN × 2
обёртки = 48 сравнений с тем же read-only вопросом без обёртки. До исправления
14 отличий text/report, после 48/48 равны. Это не новый сюжет и не «14 потерянных
условий». Полный unit: 324 файла, 8 975 passed, 5 прежних todo, 0 failed,
`.output/rp321-unit-final.json`. TypeScript clean; целевой прогон 189/189.

Installed Edge MV3 E2E: 10/10, RU/EN × managed/legacy/manual OOC (6), прежняя
metadata/prefix передача памяти (4). Проверены статус до/после reload, отсутствие
recovery, возвращение обычного статуса/кнопки следующим игровым ответом, отсутствие
новых событий/изменений карточек даже при неправильном JSON, исходный draft и
суффикс фактического POST. RU/EN 200 px снимки просмотрены; плашка помещается.
Первый запуск
дополненных E2E выявил неверный mock: reload рисовал старый native ID 41 вместо
выбранного 43. Стенд теперь рисует выбранный ответ и явно ждёт сохранённого
finish перед навигацией; не ослаблялись native-проверки production-кода.
Вся проверка — headless Edge с синтетическим DeepSeek и отдельной БД. Личные
миры/Brave не трогали; тестовые контексты закрываются в finally.

Новый Brave-пакет: `downloads/DeepRole-Brave-ooc-status-search-20261018.zip`.
Chrome/Firefox/source и canonical ZIP в downloads пересобраны для этой точки;
SHA всех 23 entries каждого browser ZIP сверены со сборкой. Source ZIP сверяется
по критическим изменённым исходникам/документам после финализации этой передачи.
Единственные штатные предупреждения сборки — крупные chunks и LF/CRLF.

Для следующего live smoke пользователь должен вручную обновить Brave-копию.
Новый импорт не нужен: тот же `RP319 — Чистая мастерская (тест)`, тот же чат,
Нора после RP320 вне сцены, осталась Мира. Проверить явный OOC-вопрос с гипотезой:
нейтральная плашка, нет вариантов, сцена не меняется; затем обычное действие.
Старая живая проверка RP320 не считается проверкой нового UI RP321.
Дальше — точность необязательного подбора RP-05 на разных сюжетах/бюджетах,
затем отдельный нагрузочный replay RP-08. Не заменять это обещанием «бесконечной
памяти без потерь». Нужны независимые проверки условий/владельцев/продолжений.
Подробности: `docs/RP05-OOC-UX-RESULTS.md`. Commit/push не запрашивались.

## Предыдущая точка RP320 — live smoke пройден после обновления Brave

Пользователь обновил расширение; Codex проверил тот же синтетический мир RP319
и тот же чат, не открывая личные миры. Три живые пары сообщений:
1. `Вне игры:` с гипотетическим уходом Норы — модель сохранила оба условия
   тубуса, в видимой сцене остались Мира/Нора (2 → 2).
2. Обычный игровой уход Норы — отыгран, карточка Норы исключена (2 → 1).
3. `OOC:` с гипотетическим возвращением — разрешение не стало выполнением,
   Нора не вернулась в карточки (1 → 1); после reload по-прежнему одна Мира.
После перезагрузки в DOM восстановленной истории проверены исходные технические
префиксы обеих OOC-реплик: `<deeprole_read_only>` есть, игровой update/choices
режим не добавлен; у обычного хода — игровой режим. Это readback страницы,
не сетевой перехват. В предпросмотре нейтрального мира было 0 игровых фактов:
ответы про тубус опирались на прежнюю переписку, не на вновь извлечённую память.
Полный DB до/после в live не сравнивали; защита от неправильного JSON и
неизменность stored events ранее проверены отдельным installed mock-E2E.

Снимки/результаты добавлены в `docs/RP05-OOC-RESULTS.md`. Чат оставлен открытым,
новых вкладок/окон не создавали; в тестовой игре Нора теперь ушла. Новые
обещания/передачи не разыгрывались. Runtime и архивы в live-итерации не менялись,
снова обновлять расширение не нужно; новые unit/build не запускались.

Следующее: поправить UX для известного OOC-ответа — сейчас статус «DeepSeek не
прислал обновление. Карточки не изменены» выглядит как недочёт, хотя отсутствие
обновлений ожидаемо. Также под OOC остаётся ручная кнопка «Предложить варианты»;
решить её видимость по точной принадлежности ответа, не по словам модели.
Это UI-замечания, в этой тестовой итерации не исправлялись. Затем продолжить
точность необязательного подбора RP-05 и отдельный нагрузочный replay RP-08.

Продолжен замеченный в live RP319 случай: непомеченная проверочная реплика
считалась игровой и могла менять состав сцены. Реализован консервативный
`explicitOutOfCharacter` только по исходящему локальному draft: начальное
`Вне игры:` / `OOC:` / `[OOC]`, целое `(OOC: ...)`, отдельное «Не продолжай /
не развивай сцену» или EN-команда в первом нецитируемом абзаце. Не угадывать
намерение обычных вопросов, не классифицировать цитаты/код/явный mixed IC/OOC.
Историю задним числом не переклассифицировали.

`GameContextInput.readOnly` сохраняет подбор фактов/условий/профилей, но убирает
игровые update/automation/choices/selfie запросы. Read-only character reference
с готовым планом использует существующие компактные инструкции; старые сервисные
запросы без плана сохранены. Проверен полный бюджет 2000 в RU/EN. Назначение пары
сохраняется в dispatch. Managed-story уже исключает OOC; legacy writer теперь
тоже блокирует эффекты по request ID ИЛИ точному native assistant link, даже если
модель убрала request из JSON. Ни одной догадки по похожему тексту.

Installed actual-POST тест выявил дополнительный сбой: снятие ручной одноразовой
отметки в prepare вызывало reload и могло оборвать собственную инъекцию памяти.
Теперь optional `consumeNonStoryMode:true` фиксируется перед отправкой, а снятие
происходит только при первой точной сверке исходящего текста. Неверный source
отметку не снимает; повтор старого подтверждения не снимает новую отметку.
Старые capture читаются без нового поля; восстановленные capture не исполняются.

Проверки: новые unit 26/26; четыре связанные группы 81/81 до последнего
сокращения reference; затем три 87/87. TypeScript clean. Installed Edge MV3
на синтетическом DeepSeek: 10/10, RU/EN × managed/legacy/manual OOC (6), плюс
прежний metadata/prefix POST/reload (4). Проверены чтение памяти в POST,
неизменность сцены/людей/событий при намеренно неправильном JSON с request
и без него, перезагрузка и реальное обновление сцены следующим игровым ответом.
Тестовые контексты закрываются в finally, личный Brave не трогали.
Финальный полный прогон: 322 файла / 8 903 passed / 5 прежних todo / 0 failed,
`.output/rp320-unit-final.json`. TypeScript clean, diff check без ошибок
(обычные предупреждения LF/CRLF). Chrome/Firefox/source ZIP пересобраны для
передачи: `downloads/DeepRole-Brave-ooc-memory-20261018.zip` — актуальный Brave.
Три canonical ZIP в downloads соответствуют этой итерации. Сборки не заменяют
отдельную проверку в живой модели и не перезагружают пользовательский Brave.

Первый полный unit-прогон: 8901 pass / 1 fail / 5 todo — новый негативный кейс
был добавлен, когда процесс уже закэшировал раннюю версию распознавателя.
Стабильный целевой повтор прошёл; финальный полный повтор выполнен отдельно
без сборки/браузерной нагрузки. Первые E2E обнаружили реальную гонку ручного
режима (исправлена), затем один RU-кейс ошибочно спрашивал EN-текстом по RU
smart-памяти; исправлен язык теста, не ослаблялись правила подбора.

Выполненный сценарий после ручного обновления (повторять не требуется):
1. Новый мир не требуется: тот же `RP319 — Чистая мастерская (тест)`, тот же чат.
2. Codex сверяет видимую сцену и задаёт явный «Вне игры: ...» вопрос с
   гипотетическим уходом Норы; гипотеза не должна менять состав карточек.
3. Затем обычное игровое действие должно снова обновлять сцену.
4. Live smoke RP320 выполнен, см. верх этой секции; прежние 9/9 RP319 — другой тест.
5. Далее — OOC UX, точность необязательного подбора RP-05 и replay RP-08.
Текущий код пользователя автоматически не обновляли. Push не выполнялся.
Подробности: `docs/RP05-OOC-RESULTS.md`, верх `ROADMAP.md`.

## Предыдущая точка RP319 — живой probe пройден, 9/9

18 октября пользователь обновил Brave-копию, импортировал нейтральный мир и
выбрал его в пустом чате. Codex отправил синтетический prefix-probe: 5/5 ответов
верны. После перезагрузки того же чата ещё 4/4: ключ требует отдельного
опечатанного футляра, разрешение не означает завершение передачи, мост ждёт
разрешения охраны, печать уже возвращена Норе. Выбранный мир сохранился.
Это проверка понимания формата живой моделью, НЕ доказательство автоматического
извлечения/подбора этих фактов или работы за пределами нативного контекста.
В тестовом сообщении факты переданы напрямую; native POST здесь не перехватывали.
Детали/ответы/снимок: `docs/RP05-LIVE-PREFIX-RESULTS.md`.

Новых изменений runtime и новых сборок в live-итерации нет. Исчезнувший probe
восстановлен из уже собранного source ZIP. Старый RP-05 тестовый мир закреплён
в `tests/fixtures/story-rp05-live-world.json`, чтобы уборка downloads не ломала
проверку; остальные отсутствующие пользовательские файлы не восстанавливали.
После закрепления fixture: три целевые группы 124/124, TypeScript clean;
`git diff --check` без ошибок (только предупреждения LF/CRLF). Полный набор
повторно в этой live-итерации не запускался; его предыдущий итог ниже.
Личные миры/чаты не использовали, дополнительных вкладок не создавали; исходный
тестовый чат оставлен открытым. Следующее — точность необязательного подбора
RP-05 и отдельная нагрузочная проверка replay RP-08. Повторять импорт/probe
не требуется. Дополнительно замечено: после внеигровых проверочных вопросов
видимый состав сцены обновился (Мира/Нора); отделение OOC от состояния сцены
не проверено и не считается закрытым этим probe.

Контролируемая вариация RP316: для каждого вопроса свои недавние реплики,
многотемный пересказ, посторонняя сцена и новый чат без переписки. 96 RU/EN
сценариев, 128/128 целевых источников, 16/16 owner-контролей только с belief.
Число дополнительных появлений одинаково при каждом хвосте, включая пустой:
12 связанных и 84 прочих на 20 вопросов. Это уточняет прежний причинный вывод:
недавние слова влияют на состав/порядок, а количество поддерживает резервный
проход. Глобальное отсечение нулевых совпадений остаётся отклонённым.

Реализован deeprole-memory-prefixes-v1: буквальное общее длинное начало текстов
передаётся один раз, каждая строка содержит точное окончание. Ни одного факта,
условия, роли, статуса или source ID не удаляем. Декодер восстанавливает тексты
дословно; источник/quote refs разрешаются после соединения. Применяется лишь
после окончательного отбора и при сокращении полного запроса вместе с guide;
сэкономленное место не заполняется новыми необязательными строками. Сравнение
memoryPrefixes:false сохранило все выбранные источники/причины в 96 сценариях.
В 80 содержательных вопросах сэкономлено 2 768 оценочных токенов (около 1,3%).

Проверки: полный набор 321 файл / 8 875 passed / 5 todo / 0 failed; TypeScript
чистый; новые группы 123/123; импорт тестовых файлов проверен отдельно.
Installed MV3 на синтетическом DeepSeek: RU/EN metadata + prefix, реальные
POST/reload/точные статусы и неизменные canonical facts, 4/4 последовательно и
4/4 параллельно. Собственные браузерные контексты закрыты. Первый запуск при
одновременных full-unit/build нагрузках дал два RU-несовпадения итогового replay;
оба чистых повтора прошли. Нагрузочная устойчивость этим не доказана; сохранить
это наблюдение для RP-08, не объявлять старый мок полноценной моделью сервера.

Chrome/Firefox/source пакеты пересобраны. Для ручного обновления Brave:
`downloads/DeepRole-Brave-lossless-memory-20261018.zip`. Текущая установленная
копия пользователя этой сборкой автоматически не обновлялась: пользователь
обновил её вручную перед описанным выше live-probe. Личный лор/игра не менялись;
push не выполнялся.

Выполненный живой сценарий (повторять не требуется):
1. Импортировать `downloads/DeepRole-RP319-test-world-20261018.json` и выбрать
   `RP319 — Чистая мастерская (тест)` в новом пустом чате. Он специально не
   содержит готовых ответов/условий в обычном лоре; генерация состава не нужна.
2. Codex отправляет содержимое `downloads/DeepRole-RP319-live-probe-20261018.txt`.
   В нём только синтетические данные с новым форматом, общий префикс несёт два
   важных условия; полного дублирующего sourceQuote нет. От пользователя нужен
   только импорт и выбранный чат, технический запрос отправляет Codex.
3. Проверить 5 ответов: отсутствие Норы блокирует передачу тубуса; прошлый
   факт передачи синего журнала остаётся завершённым; пустота капсулы лишь belief;
   код не разрешает личные комнаты/подвал; запасное письмо не получено Мирой.
   Это probe понимания формата моделью, не доказательство автоматического
   извлечения памяти из длинной игры. Интеграция отправки проверена отдельным E2E.
4. Теперь продолжить точность необязательного подбора RP-05 и отдельную нагрузочную
   проверку replay. Использовать только тестовые миры.

Подробности: `docs/RP05-RECENT-CONTEXT-RESULTS.md`, верх `ROADMAP.md`.

## Предыдущая точка RP318 — предварительная классификация добавок

Проверен и откачен кандидат: не добавлять общие факты с нулевым поисковым
совпадением, когда вопрос уже нашёл свои факты. На RP316 это давало 96 → 42
дополнительные записи и 32/32 целевых факта, но полный регрессионный прогон
показал 222 падения в 13 файлах. Даже более узкий фильтр затронул 50 проверок
цепочек действий/эталонных выходов. Код возвратил прежний fallback; эксперимент
не попал в сборку. Историю и память пользователя не меняли.

Классификация 96 дополнительных появлений по 20 запросам описала совпадения:
38 также имели совпадение с вопросом, 58 совпали только с недавним контекстом.
Во всех случаях `recentMessages` были одинаковы и содержали общий пересказ,
перечисляющий почти все темы. Все 96 получали недавний балл; это 96 появлений
в отдельных запросах, не 96 фактов одновременно. Эти записи сохраняются и при
отключении специальных дорожек — их отбирает обычный резервный подбор. В основном
это разные подтверждённые события, а не дубли для удаления.

Следующий шаг по RP05 — заменить искусственно общий хвост на реалистичные,
разные для каждого тестового вопроса отрывки переписки. Сравнить текущую сцену,
длинный пересказ разных тем и недавнюю постороннюю сцену; отдельно отмечать
поддержку ответа, условия/связанные состояния и случайные совпадения. Лишь потом
проверять узкий резерв недавних фактов для ясных вопросов с найденным полным
ответом. Продолжения игры, открытые задачи, условия, цепочки действий и
неоднозначные ссылки оставить под прежним поведением. Не менять runtime, сборки
или живую игру до безопасного результата на старых контролях. Подробности:
`docs/RP05-COMPACTNESS-RESULTS.md`.

После отката: полный набор — 319 файлов, 8 752 passed, 5 todo, 0 failed;
typecheck чистый. Пакеты не пересобирались, live-синтетический чат не трогался.

## Актуальная точка RP317 — live-проверка доставки памяти пройдена

В синтетическом чате мира `RP-05 — Тихая пристань` до исправления предпросмотр
выбирал нужную запись «Открытое обещание Тарена о подъёмнике», но реальная
отправка иногда уходила без неё. Рост handshake до 12 секунд сам по себе не
помог.

После установки нового Brave-пакета пользователь повторил тот же вопрос.
На приложенном скриншоте первый ответ — от старой версии, второй — после
обновления: DeepSeek назвал обещание, оба условия и правильно указал, что ремонт
ещё не начался. Live smoke для пользовательского сценария пройден.

Проверки: TypeScript clean; полный unit-прогон — 319 файлов, 8 752 passed,
5 todo; actual-POST E2E RU/EN — 2/2, включая попадание внешней правки памяти в
следующий запрос. Chrome, Firefox и source ZIP собраны; SHA-256 совпадает с
копиями в `downloads/`. Brave-пакет:
`downloads/DeepRole-Brave-memory-refresh-fix-20261018.zip`.

Следом: продолжить RP-05 — уменьшать слабые/повторные контекстные добавки,
не теряя существенные факты, условия и связи. Live smoke подтверждает ответ после
обновления, но не закрывает весь RP-05. Использовать только синтетические миры,
не личный лор.

## Актуальная точка RP316 — отдельный сюжет и замер контекстных добавок

Новый сюжет воздушной обсерватории (RU/EN), не переиспользующий предыдущие
RP-05 gold/fixtures: 24 сценария, 20/20 scored, 32/32 требуемых записей; 4/4
owner-контроля сохранили source-backed `belief`; source/quote/kind/task-status/role/
episode integrity — 0. Проверены перемещение тубуса, поздний прогресс причала,
условия обещания, выполненная соседняя задача, раскрытие, цитата и 40 повторов.
Добавлены bounded формы «keep coming back to», «известно, чей» и «есть
подтверждение, что принадлежит».

Важное измерение для контекстного окна: на 20 обычных вопросах выбрано ещё 96
записей. Не считать их автоматически ошибкой или утечкой, но следующий шаг —
понять, сколько повторов/слабых подсказок можно убрать без потери полезных связей.
Полный прогон 319 файлов: 8 748 pass, 5 todo, 0 fail; TypeScript чистый. Chrome и
Firefox MV3 сборки/ZIP прошли. Новая сборка в установленном DeepSeek ещё не
проверена; предшествовавший live smoke test относился к предыдущей версии.

Следом: вручную заменить файлы установленной копии и проверить только отдельный
синтетический мир; затем продолжить оптимизацию компактности memory retrieval.
Личный лор не использовать. RP-05 открыт. Подробно: `ROADMAP.md` / верх
`docs/HOME-CODEX-NEXT.md`, `docs/RP05-INDEPENDENT-PLOT-RESULTS.md`.

## Актуальная точка RP315 — свободные формулировки

Новый независимый сюжет убежища, RU/EN:16 сценариев,14/14 scored и18/18 целевых
записей. Исходный прогон нашёл, что «keep circling back»/«возвращались обсуждать»
отсекало нужный хвост, а «whose»/«чей» смешивало owner-слух с соседними событиями.
Добавлены узкие варианты форм и source-bound admission: запись должна содержать
маркер владения и тему предмета; русский `владелец` теперь распознаётся.
Повторный прогон:2/2 owner-контроля вернули только `belief`, event leakage0,
source/quote/role/task-status/episode integrity0; история/входы не менялись.
Полный прогон317 файлов:8722 pass,5 todo,0 fail; TypeScript clean.

Runtime изменился; browser/source ZIP пересобраны и downloads SHA-256 совпадают
со сборками. Установленная копия, DeepSeek и личный мир не трогались. Следом —
ещё один новый сюжет, затем пользователь вручную обновит расширение и проверит
только синтетический мир. RP-05 открыт. Результаты: `docs/RP05-NATURAL-DIALOGUE-RESULTS.md`;
роадмап — вверху `ROADMAP.md`.

## Актуальная точка RP314 — отделять повторы от нового прогресса

Независимый новый сюжет насосной станции на RU/EN:16 сценариев,14/14 scored
запросов и14/14 ожидаемых записей. Проверены аварийное действие, более поздний
реальный ремонт с общими словами, обещание с двумя условиями,36 повторов,
впервые раскрытые сведения, одиночный пересказ, цитата и непроверенный владелец.
Новые действие/ремонт/информация не потерялись; прямой вопрос о повторах их
нашёл;2/2 слуха остались `belief`. Event leakage0, source/quote/role/status/
episode integrity0; бюджет и входы сохранены. 163 связанных теста и typecheck
прошли. Runtime не менялся, архивы/установленная копия/DeepSeek/личный мир
не трогались.

Следом — ещё один независимый корпус со свободными формулировками; затем нужна
живая проверка после ручного обновления расширения в отдельном синтетическом
мире. RP-05 открыт. Итоги: `docs/RP05-PROGRESS-BOUNDARY-RESULTS.md`; план — вверху
`ROADMAP.md`.

## Актуальная точка RP313 — независимая перепроверка RP312

На отдельном сюжете об обсерватории (RU/EN), не использующем RP311/RP312
fixture, прошли 10 локаль-сценариев:8/8 scored-запросов,10/10 ожидаемых
записей. Проверены действие, обещание с двумя открытыми условиями, хвост из32
повторов, вопрос о самом обсуждении, одиночный пересказ, цитата и слух о
владельце. Два контроля вернули только source-backed `belief`; event leakage0,
source/quote/role/status/episode integrity0; бюджет и входы сохранены.
Все11 новых тестов прошли. Runtime не менялся; архивы/установленная копия,
DeepSeek и личный мир не трогались.

Следом: ещё один независимый сюжет и затем live-проверка только на отдельном
синтетическом мире после ручного обновления распакованной копии. RP-05 не закрыт.
Результаты: `docs/RP05-CROSSPLOT-RESULTS.md`; статус — вверху `ROADMAP.md`.

## Актуальная точка RP312 — retrieval не отдаёт приоритет повторным пересказам

Исправлен RP-05 по результатам RP311: простые повествовательные записи, прямо
говорящие «обсудили снова/вспомнили, новых действий или сведений не было», не
вытесняют сыгранные действия, планы и открытые обещания, если найдено не менее3
таких совпадающих с запросом пересказов. Одиночный источник остаётся; старый
путь прямых цитат не менялся; вопросы о разговорах/словах всё ещё могут вернуть
эти события. История не удаляется.

Для прямых RU/EN-вопросов «кто владеет?» / «кому принадлежит?» добавлен ограниченный
поиск по явным owner-словам и совпадению предметной темы. Сохранённый `kind`
не меняется: слух остаётся `belief`, не объективным фактом. Новый набор:18/18
scored,24/24 ожидаемых факта;4/4 unknown-owner контроля вернули только нужный
belief; source/quote/role/status/episode integrity0. Полный прогон314 файлов:
8673 pass,0 fail,5 todo;typecheck и diff-check чистые.

Chrome/Firefox/source ZIP пересобраны (23/23/922 entries); downloads-копии совпали
по SHA-256 с `.output`. Установленная копия/DeepSeek/личный мир не трогались.
Следом пользователь вручную обновит распакованную копию и проверит
синтетический чат. Затем нужны новые независимые сюжеты; RP-05 остаётся открыт.
Подробности: `docs/RP05-GROUNDING-RESULTS.md`.

## Актуальная точка RP311 — независимый поиск памяти по источникам

Свежий заранее размеченный аудит (2 новых сюжета, RU/EN, 22 запроса, 48 поздних
повторных обсуждений на сюжет): все ожидаемые записи нашлись в15/18 scored
(RU6/9,EN9/9;21/24 факта). Три пропуска в RU вызваны вытеснением исходного плана/
условного обещания повторениями. Во всех4 контролях неизвестного владельца
подбор выдавал повторяющиеся события вместо source-belief записи. При этом
выбранные записи не потеряли source/quote/role/task status/episode ID (0 нарушений),
budget и входы сохранены. Новый focused audit:23/23; TypeScript и diff-check чистые.
Подробно: `docs/RP05-GROUNDING-RESULTS.md`.

В этой итерации runtime не менялся; установленная копия и DeepSeek не тронуты.
Следом исправить ранжирование/выбор: защитить первичный источник и открытые
условия от повторов, не превращать обсуждение/слух в установленный факт при
неизвестном владельце. Затем прогнать frozen RP311 + зелёную регрессию и только
после этого подготовить пакет. RP-05 остаётся открыт.

## Актуальная точка RP310 — естественные вопросы о предметах вне сцены

Расширен ограниченный поиск профиля для явных вопросов о предмете: кроме
«где/у кого предмет?» поддерживаются «что мы знаем о предмете?», “What do we
know about…?”, “Can you tell me about…?”, “Do you remember…?” и явные просьбы
напомнить. Это всё ещё лексический поиск по полным словам темы; он не делает
выводов о владельце/местонахождении. Простое повествование, разговорное
воспоминание и неопределённое «её вещь» не подтягивают внесценные анкеты.

Добавлено шесть позитивных RU/EN unit-кейсов и три отрицательных; близкий набор
173/173. Полный unit-набор:313 файлов,8643 прошло,0 ошибок,5 todo; Chromium E2E
actual POST RU/EN:2/2; `npm run typecheck` и `git diff --check` прошли. Первый
build столкнулся с занятым системным TEMP; повтор через локальный TEMP прошёл.
Порт E2E можно переопределить через `DEEPROLE_E2E_PORT`, поскольку дефолтный
4173 занят посторонним/ранее запущенным сервером. Chrome/Firefox/source архивы
пересобраны; canonical downloads совпадают побайтно, entry counts 23/23/921.
Установленная копия и DeepSeek не тронуты. Следующий большой пункт — независимый RP-05 semantic
retrieval audit; открытые menu/cast/reset/export/images live-сценарии остаются.

## Актуальная точка RP309 — память по предмету владельца вне сцены

В предыдущей live-проверке первый вопрос о блокноте не получил профиль Leon,
потому что Leon не присутствовал и вопрос не называл его. Story facts при этом
имеют отдельный поиск и могут содержать предмет/владельца/обещание, но профиль
ограничивался сценой, фокусом и явным именем. Исправлен только `src/core/game-context.ts`:
для ограниченного object-question (`где/куда` и `where is/are/was/were`, `who has/owns`,
`what happened to/about`) или уже распознанного действия берутся целые абзацы
анкеты отсутствующих персонажей, содержащие ВСЕ нормализованные слова предмета.
Весь предметный запрос должен совпасть в профилях не более чем у двух людей;
при совпадении у двух они передаются оба и отдельно. Местоименные запросы
отсеиваются этой дорожкой. Добавленная инструкция прямо запрещает трактовать
релевантность как доказательство владения или физического присутствия.

Добавлены RU/EN unit-сценарии: Leon вне сцены, архивный блокнот, source-bound
обещание на завтра только после подписи расписки, одинаковое название у двух
людей, общий шум и unresolved pronoun. Дополнительно проверены независимые
RU-компас и EN-ключ с off-scene профилями и условными обещаниями. Targeted:164/164
unit; TypeScript прошёл;
E2E Chromium actual POST RU/EN:2/2. Исторические sealed отчёты и gold не менялись.
Fingerprint-манифесты проверяются как архивные данные, а сохранённые runtime-
snapshots сравнивают компоненты, зафиксированные соответствующими тестами. Полный
прогон:313 файлов,8632 pass,0 fail,5 todo; `npm run typecheck` и `git diff --check`
прошли.
Chrome/Firefox/source ZIP собраны; entry counts:23/23/921
entries,0 mismatches;три canonical downloads копии побайтно совпадают с `.output`.
Предупреждение о chunk >500 kB осталось прежним. Живой DeepSeek/установленная
копия/личный мир не тронуты; пользователь должен обновить распакованную сборку
отдельно.
Затем вернуться к menu/cast/reset/export/images live-проверкам RP306/RP307, после
этого — к независимому RP-05 semantic retrieval. Не объявлять RP-05 закрытым.

## Актуальная точка RP308 — подпись эмоции и показатели портретов

«Спокойствие» в компактной карточке теперь отдельной строкой на полную ширину,
вместо сжимаемой боковой колонки. Первые два показателя floating portrait появляются
при hover/focus-within; на touch видны постоянно, компактная полоса без изменений.
Скрытие сохраняет измеренную высоту, чтобы наведение не двигало состав сцены.
Файлы characters.css/portrait-stage.css; данные и запросы не менялись.
42unit pass,tsc0. Браузерные проверки RU/EN320/1280,hover/leave/keyboard,
геометрии,reduced-motion,touch и прежнего constructor — результат в RP308 ROADMAP.
Первый запуск: неверный порог нового теста150px при полной ширине148px; исправлен
на сравнение с шириной контента. Второй: Firefox teardown protocol error после
успешных assertions; выполнен финальный последовательный прогон.
Пакеты требуют ручного обновления установленной копии. Живой DeepSeek этой правкой
не проверен; без push. Следующие живые задачи RP307/RP306 ниже остаются актуальны.

## Предыдущая точка RP307 — модельный бюджет иллюстрации Venice

Пользователь показал2732символа при лимите1500 (lustify-v8) и попросил заранее
учитывать лимиты всех моделей в промпте DeepSeek. Базовая загрузка constraints
promptCharacterLimit и числовая подсказка уже были в RP255. Теперь добавлен measured
promptComposition: выбранные IDs, расходы style/framing/group и per-person текст/
neutral/suggestive references; полные identities учитываются сверх roster excerpt.
Общие compact helpers используются и счётчиками, и итоговым prompt assembler.
Оба пути content.tsx (initial и changed-reference review) передают данные DeepSeek.
Отдельно исправлено заимствование лимита другого режима у shared model ID, когда
API не сообщил собственный. Каталог применяется динамически, name whitelist нет.

Итог:87unit pass,tsc/diff0. Native prompt-budget RU/EN подтвердили передачу composition,
edit1500/generate3000, reference mapping и сохранение draft на mock API/DeepSeek.
Первый расширенный E2E:2pass/10fail/4skip;8устаревших selectors SupportDetails,
2review fixtures ожидали старый основной чат. Review2fail повторены на прежнем
RP306 ZIP. Fixtures обновлены для isolated worker/cleanup и hydrated photo bytes;
полные поля/исходные dataURLs по-прежнему сравниваются точно. Final E2E12pass/4skip
(Firefox не выполняет Edge MV3 install),0fail/flaky;4native сценария RUEN,8UI320/900px.
Проверены changed-ref promptComposition, selected reference pixels, pending review
reload, cancel, exact frozen retry и отсутствие service turns в основном чате.
Chrome/Firefox/source ZIP пересобраны; CRC/bytes/canonicalSHA сверяются финальным
packaging pass. [QA](docs/benchmarks/rp307-qa-results.json). Пользовательскую
установку/личный лор/платную Venice генерацию не трогали. Push не запрошен.

Важно: если style+полные identities уже превышают1500, подсказка не может это
исправить без потерь. Preflight остаётся, stored данные/состав/изображения не режем,
повтор платного запроса не запускаем. Общий12000cap прежний. Повтор старого запроса
frozen, новый план — через Create illustration. [Описание](docs/IMAGE-MODEL-BUDGETS.md).
После этого вернуться к off-scene profile coverage и открытым live сценариям RP306;
RP05 не объявлять закрытым. Ниже RP306 — история.

## Актуальная точка RP306 — скрытый контекст и компактные действия ответа

Исправлен live дефект: presentHiddenHandoffs скрывал только handoff/notice,
а обычные memory/character/profile/choice prefixes оставались после reload.
Общий injectedUserText узнаёт начальный служебный блок и завершённую границу
[User message]; сохраняет оставшийся текст игрока, включая повторные метки.
Native DOM/wire не переписываются. storyText очищает prefix ДО ограничения истории;
DOM fallback читает assistant main content без отдельного thinking heading.

Пользователь обновил установленный Chrome ZIP с этой правкой. В настоящем target
9a68d51d обычное сообщение и handoff скрыты после повторного reload, по одному
presentation host. OOC намерение/гипотетический возврат не исполнили обещания.
Manual «Предложить варианты» дал 4 хода; выбор заполнил draft без send, draft очищен.
Новая review предложила 2 записи, обе НЕ приняты; предложение об обещаниях сохранило
unsigned receipt/обоих владельцев/оба open. Continue without changes автоматически
создал target125a5a3d-54ec-4171-8321-866ffcee8321 с тем же миром/3 персонажами.
После reload нового target отдельный OOC ответ точно сохранил владельцев, оба
предмета у Алекса, unsigned receipt, notebook tomorrow morning и оба open.
Read-only DOM исходного handoff request подтвердил: recent scenes = 6 чистых
user/assistant turns, без protocol prefix, thinking headings и вариантов как событий.
Старый чат показал ссылку на125a5a3d и «Продолжить здесь»; её не нажимали.

Дополнительная просьба пользователя: компактная «Предложить варианты» справа от
«Создать иллюстрацию», тот же нейтральный стиль, без отдельной большой панели.
Recovery host назначается в scene-choices slot в toolbar IllustrationReply;
без изображений остаётся отдельной компактной кнопкой. Подсказка title/aria-describedby,
на узком экране перенос без переполнения. Генерация/подтверждение/сохранение не менялись.
Пользователь затем обновил архив ЕЩЁ РАЗ. Live toolbar проверен: обе кнопки40px,
background rgb(54,62,70),font12px,radius10px,text rgb(238,243,247),gap8px.
Recovery реально находится в slot справа от image button; Enter запустил запрос,
DeepSeek вернул4варианта без продолжения сцены. Их не выбирали/не отправляли.

Итоговая QA:130/130 unit в8файлах,126/126 E2E RU/EN Chromium/Firefox, один worker,
0fail/skip/flaky; tsc/diff0. Первый расширенный102прогон77pass/25fail сохранён:
16устаревших full-width assertions заменены проверкой compact toolbar,8innerText
на полностью скрытом ancestor заменены retained payload + actual visibility;
1Firefox context-close protocol error без UI assertion failure. Отдельный первый
compact8прогон выявил разные neutral фоны; исправлено общими design effects.
[Поведение и пределы](docs/INJECTED-TEXT-AND-REPLY-ACTIONS.md),
[QA](docs/benchmarks/rp306-qa-results.json). Chrome/Firefox/source ZIP собраны,
23/23/917entries CRC и bytes сверены с runtime/source, canonical downloads SHA
равны исходным архивам. Source ZIP без tests/private-assets; QA нужен Git checkout.
Итоговые docs включены в source ZIP; финальная сверка повторяется после сборки. Ниже RP305 — история.
Следом: off-scene profile coverage; menu/reset/cast/export/images live всё ещё открыты.
Личный Sunset Valley не трогали, chats не удаляли; push/merge не запрошены.

## Актуальная точка RP305 — первый запрос переноса исправлен и проверен живьём

При native переходе с home на ещё не привязанный target ДО completion контекст
терялся. Новый page-local provisional target связывает exact chat/snapshot/token
на 90сек только для подготовки контекста. Binding и active world по-прежнему
меняются после accepted delivery; ранней активации нет. Clear private state,
чужой binding/ID/token/snapshot, source и expiry не получают новый fallback.
Runtime: content.tsx + core/continuation-flow.ts. RP304 recall-файлы не изменялись
этой правкой; весь прежний uncommitted результат сохранён. [Описание](docs/CONTINUATION-FIRST-SEND-REPAIR.md).

QA: до правки новый native RU early-route упал (appliedAt undefined); после —
18/18 chain RU/EN, включая early-route/HTTP503/commit/receipt failures, источник
активен до accepted POST, при сбое нет target binding; retries не повторяют send.
38/38 focused unit, tsc/diff0. UI/recap18pass/2Edge-only skips вFirefox/0fail/flaky,
RU/EN 320/360/900/1280px. Full unit/full E2E не повторяли. Обе сборки успешны;
в системе TEMP первый esbuild Access denied, workspace TEMP решил это без кода.

LIVE ПОСЛЕ ПРАВКИ: пользователь обновил Chrome ZIP и reload установленной копии.
Заново нажали Continue в source1874cefc, получили review4/ничего нового не приняли,
сжимку и automatic target9a68d51d-1958-4a62-9c5b-506d876f73b7 «Архивное утро».
Мир/3 персонажа/50-50 сохранились после reload. Отдельный OOC ответ точно назвал
владельцев Миры/Леона, предметы у Алекса, unsigned receipt, notebook tomorrow
morning и оба обещания open. Старый чат показал напоминание/ссылку на target;
там ничего не отправляли и «Продолжить здесь» не нажимали. Первые два liveFAIL
сохранены ниже/[отчёт](docs/LIVE-QA-2026-10-16.md), не заменены synthetic green.

Следом: видимый служебный prefix после reload и загрязнение recent scenes этим
prefix (он режется вместо user action); затем off-scene profile coverage в первом
вопросе о блокноте. Не расширять RP05 поисковые словари ради этих UI/transport
проблем. Menu Codex srcdoc, cast/reset/export/images/full RU/EN live остаются
отдельными открытыми проверками. Личный Sunset Valley не трогали, chats не удаляли.
Chrome/Firefox/source ZIP подготовлены: 23/23/914 файлов, побайтовая/CRC сверка
и SHA равенство canonical downloads копиям. Установленная
Chrome-копия уже обновлена пользователем до текущего runtime. Push/merge не просили.

## История живой диагностики до RP305 — сбой первого запроса переноса

Актуальный результат: пользователь вручную импортировал и выбрал тестовый мир.
Без меню работают composer и панели чата. Реальные ответы проверены: персонажи
и их состояния обновились, оба обещания/владельцы/условие/срок сохранились после
reload; сверка дала 5 предложений, принят только 1, toast подтвердил сохранение.
Continuation сделал отдельную сверку без дубликата обещания, 4 предложения,
подтверждение пережило закрытие/reload. После подтверждения сжимка подготовилась.

КРИТИЧЕСКИЙ FAIL: новый чат 0aba770f-5bc5-4c76-a11c-f5f52e0edf59 открылся «Без
мира»; DeepSeek сообщил «Контекст не прикрепился». Ручной первый send с той же
queued-сжимкой в новом 0b8e8861-bdf9-43ca-9834-8933a8123871 повторил отсутствие
контекста. Явный выбор мира в нём дал generic save/scene failure. Source chat и
сохранённая память целы; ни один transfer не считать успешным. Также raw служебный
prefix виден в user bubble после reload; исходный off-scene блокнот не попал
в первый ответ. Полные факты/пределы: [LIVE-QA](docs/LIVE-QA-2026-10-16.md).

СЛЕДУЮЩАЯ ЗАДАЧА: воспроизвести в isolated regression смену native route на target
ДО first completion POST/response. В content.tsx currentScene() даёт EMPTY при
chatId без binding, а handleNavigation пропускает promoteDraft при appliedSnapshot;
нынешний chain fixture меняет URL только ПОСЛЕ response. Это рабочая гипотеза,
не доказанная правка. Сохранить accepted-delivery-before-world-activation guards,
не исправлять ранней активацией/удалением защит. После исправления tests/typecheck/
две сборки+ZIP и повторить live на обновлённой установленной копии. Runtime в этой
итерации не менялся; только отчёт/передача/тестовый portable JSON. Menus/reset/
export/images/full cast preparation/RU-EN narrow live остаются непроверенными.

### История диагностики недоступного меню (частично преодолено)

После обновления пользователем прочитаны DOM-атрибуты пустого iframe: правильный
chrome-extension src, но также `srcdoc=""`, который выбирает пустой about:srcdoc.
В src и сгенерированных Chrome content/chunks нет кода srcdoc. Кто добавляет
атрибут, пока не доказано; пользователь связывает это с автоматизацией. Ожидается
ответ, работает ли меню после ручного reload/открытия до действий Codex. Не
удалять атрибут принудительно ради обхода ограничений браузерного инструмента.

Следующая проверка: пользователь подтвердил нормальное ручное открытие меню.
Одно getTab новой пользовательской вкладки 602384194 без кликов уже вернуло
about:srcdoc; read-only DOM подтвердил srcdoc="". Сбой воспроизводится при
подключении инструмента управления, конкретный внутренний инжектор не установлен.
Код расширения не менялся; на этом этапе живые проверки ещё были заблокированы.

Пользователь разрешил сообщения в отдельном тестовом чате. План, ожидания и
ссылка: [LIVE-QA-2026-10-16](docs/LIVE-QA-2026-10-16.md). Контрольное сообщение
получило правильный ответ, после reload история сохранилась. Меню установленного
DeepRole дважды открылось пустой белой панелью (about:srcdoc), в том числе после
reload страницы. Путь/ревизия установленной копии пока не подтверждены. Browser
tool запрещает edge://extensions/; пользователь получил просьбу вручную
перезагрузить DeepRole и сообщить путь. Не обходить запрет другим способом.
После ответа пользователя проверки продолжены на отдельном синтетическом мире,
не Sunset Valley; актуальные результаты и следующий шаг выше. Пересборка для
этой документальной записи не нужна.

## Актуальная точка RP304 — исправление разговорных ссылок и последовательностей

Исправлены 15 неполных входов RP303 и 12 пропусков reference guard. Целевой
SEEN: **40/40 полных, 204/204 записей**, 0 пропусков, искажений, guard gaps и
потерь прежней памяти. Первый RP303 25/40, его input/gold/fixture/protocol/
runner/report/seal сохранены. До правок сверены 414 pins и точные RP302 snapshots.
[Поведение](docs/RELAY-REPAIR.md), QA: docs/benchmarks/rp304-qa-results.json.

Два runtime-файла: story-obligation-recall.ts и game-context.ts. Добавлены
ограниченные формы разговорного readiness-вопроса, короткой анафоры и first/then
sequence с запросом условий. Topic условленность/understanding участвует в
проверке принятой цитаты; raw-only не даёт положительную связь. Последовательность
может передать отдельные группы названных кандидатов, сохраняя неоднозначность.
Caps16/4/128, source/budget fallback и opt-outs прежние. Нет записи канона,
вывода владельца, тождества, разрешения или выполнения из слов пользователя.

Прежние pins RP302 seen-report tests переведены на точные исторические snapshots;
новые relay seen-report tests сверяют текущий runtime. Первые отчёты не менялись.
Текущие отчёты: rp304-*-seen-results.json, SEEN.
Все девять наборов проверены: 650 входов, 388 оцениваемых случаев, 1826 ожидаемых
записей. Полны 388/388, 0 missing/integrity/guard gaps/lost prior. Controls и
budget входят в 650 отдельно; это не 650 независимо сыгранных историй.
Новый корпус теперь тоже известный: дальнейшую независимую проверку делать с новыми текстами и gold
до первого запуска. RP-05/general semantics/true delta остаются открытыми.
Личные миры и установленная копия не менялись, live DeepSeek не проверялся.
Push в этой итерации не запрошен. Ниже исторические этапы и старые next steps.

RP304 full unit: 8600 pass, 0 fail, 5 прежних TODO. Финальные 62 проверки
исправления, новых отчётов и first-score pins прошли отдельно; новый report test
добавлен после старта полного прогона. TypeScript/diff 0, Chrome/Firefox ZIP собраны.
Первый strict запуск вместе с full unit и девятью корпусами:491 pass/1 timeout
в100-portion storage test (30000ms). Попытка сохранена вrp304-first-strict-attempt.json.
Тот же тест отдельно прошёл без изменения кода и timeout. Для этой машины
повторять strict после завершения full/corpus нагрузок; не повышать timeout.

RP304 final QA: strict повтор без внешней тяжёлой нагрузки —492 pass/0 fail,
2427 пар/57 конфигураций; исходный100-portion test отдельно1pass. Runtime между
попытками неизменён, automation test вместе с timeout совпадает с HEAD. Первый
таймаут сохранён, не заменён успешным результатом. Архивы23Chrome/23Firefox/
910sources entries проверены CRC/состав/байты/SHA256 canonical copies. Source ZIP
без tests/private-assets, нужен Git checkout. При4200 tokens новый corpus8/8
во всех четырёх сочетаниях; при1000 остаётся неполным с честным budget status.
Live/native/installed extension в этой итерации не проверялись и не обновлялись.

## Актуальная точка RP303 — независимая проверка новых сюжетов

Рабочий код RP302 не менялся. Два новых авторских сюжета: горное убежище и
учебная регата, RU/EN. Всего 64 входа: 40 оцениваемых, 16 контрольных и
8 бюджетных; 204 ожидаемые записи, до 8 200 фоновых событий.
До первого запуска отдельный --freeze сохранил ручные ожидания и 414 хешей.
Первый результат: **25/40 полных, 181/204 записей**, 23 пропуска в 15 входах,
12 пропусков reference guard, 0 нарушений источников и ложного complete.
[Разбор](docs/RELAY-RESULTS.md), протокол RELAY-EVALUATION.md.
Первый отчёт/seal: rp303-relay-results.json/rp303-first-report-seal.json.

Полны explicit/partial-condition/negative/revoked/replacement во всех четырёх
сочетаниях сюжета и языка. Paraphrase 0/4, accepted-reference 2/4, sequence 1/4,
scale 2/8. Guard отсутствует в 4 paraphrase, 4 reference и 4 raw-only;
UI coverage остаётся unverified. Это два сюжета с переводами и повторным фоном,
а не 64 независимо сыгранных романа.

Следом исправить 15 неполных входов и 12 пропусков guard отдельной SEEN-итерацией
плюс восемь прежних корпусов RP302. Не переписывать RP303 input/gold/fixture/
protocol/runner/report/seal. Точные RP302 obligation/game-context snapshots уже
сохранены по frozen hashes; перед изменением других runtime-файлов сохранить их.
Не угадывать владельца, тождество, разрешение или выполнение; не увеличивать caps.
RP-05/general semantics/true delta открыты. Установленная копия и личные миры не
менялись; живой DeepSeek не проверялся, push не запрошен.
QA: docs/benchmarks/rp303-qa-results.json. Ниже исторические точки.

RP303 QA: 21 тест фиксации первого результата и прежних отчётов прошёл; финальные
7 проверок нового first score повторены. Unified strict: 492 pass, 0 fail,
2427 пар/57 конфигураций. TypeScript/diff: 0. Chrome/Firefox ZIP собраны;
23/23/896 файлов, CRC/состав/байты и SHA256 canonical copies проверены.
Полный unit/native/live в этой итерации не повторялись: runtime/UI не менялись.
Исходный первый результат остаётся 25/40; зелёные QA checks его не исправляют.
Source ZIP без tests/private-assets; для воспроизведения нужен Git checkout.

## Актуальная точка RP302 — исправление публикации и согласия

Исправлены10 неполных входов RP301 и2 пропуска guard. Целевой SEEN:24/24,
114/114 записей,0 missing/integrity/guard gaps/lost prior. Первый RP30114/24,
его frozen input/gold/fixture/protocol/runner/report/seal сохранены. До правок
проверены414 хешей и сохранены точные RP300 snapshots obligation/game-context.
[Поведение и ограничения](docs/EMBARGO-REPAIR.md), QA:benchmarks/rp302-qa-results.json.

Два runtime-файла:story-obligation-recall.ts иgame-context.ts. Добавлены bounded
readiness-versus-publication inquiry иpublication/display compound. Названный
материал допускается только через буквальный source-name/object span из task
title, повторённый вего записи идвух других текстах. Не query-derived identity.
Shared-alias guard сохраняется даже при передаче нескольких candidate groups.
Caps16/4/128, opt-outs, exact-source/budget fallback неизменны; нет permission,
completion, owner inference или canonical writes. Отмена/согласие не выводятся.

Текущие отчёты:rp302-*-seen-results.json, **SEEN**, не новая независимая проверка.
Все8 наборов:586inputs/348scored/1622gold,348/348 complete,0missing/integrity/
guard gaps/lost prior. Среди586 есть отдельные controls/budget, не586полных
историй. Первыеgold/seals не изменены; новые48 repair/report/seal checks pass.
Следом — новый заранее зарегистрированный независимый сюжет/формулировки;
не объявлять RP-05 закрытым. General semantics иtrue delta открыты. Установленная
копия и личные миры не менялись. Push этой итерации не запрошен.
Ниже — исторические точки и прежние next steps.

RP302 finalQA:fullunit8534pass/0fail/5existingTODO,309files. Финальные48repair/
report/seal checks pass отдельно (новые report tests добавлены после начала full
run). Unified strict492pass,2427pairs/57configs;TypeScript/diff0. Chrome/Firefox
ZIP0,старый chunkwarning. Архивы23Chrome/23Firefox/888source entries проверены
CRC/состав/байты/SHAcanonicalcopies;sourceZIP excludes tests/private-assets.
Budget3000/6000=7/7RUEN;900=1/7RU,2/7EN сявнымbudgetstatus. Не live/native,
installedextension не перезагружалась. Все выводы вrp302-qa-results.json.

## Актуальная точка RP301 — свежий аудит, без runtime-правок

По запросу пользователя проведён новый preregistered аудит похожих обязательств,
условий и запретов на научной станции. До первого compiler-run отдельный freeze:
40 inputs / 24 scored / 114 gold / 10 controls / 6 budget / 414 fingerprints.
Первый результат **14/24 complete, 102/114 records**, 12 пропусков в 10 входах,
2 guard gaps, 0 integrity/false-complete. Пропуски: RU/EN парафраз публикации
теряет a2/a3 и guard; compound + шесть scale теряют c1 (низкое разрешение не
заменяет согласия). Прямые/accepted-reference/negative/revoked/terminal cases полны.
[Подробности и следующий шаг](docs/EMBARGO-RESULTS.md).

Дальше: сохранить RP300 snapshots по frozen hashes ДО правок, исправлять эти
случаи отдельным SEEN и прогнать семь старых наборов. Не переписывать RP301
baseline/fixture/protocol/runner/first report/seal. Не увеличивать caps и не
угадывать владельца/согласие. RP-05/general semantics/true delta открыты.
Этот корпус теперь известный; повтор не называть независимым. Личный мир,
аккаунт и установленное расширение не менялись. Push в этой итерации не запрошен.
QA: docs/benchmarks/rp301-qa-results.json; текущий маршрут HOME-CODEX-NEXT.md.

RP301 QA:46 audit/prior-seal tests +492 unified strict checks passed,0fail;
финальные4 seal checks повторно pass. TypeScript/diff0. Chrome/Firefox ZIP0;
первый Chrome esbuild TEMP access-denied, успешный повтор с project-local TEMP.
Старый chunk warning остаётся. Fullunit/native/live не повторялись: runtime/UI
не менялись. Архивы23Chrome/23Firefox/874source проверены по CRC/составу/байтам
и SHA256 трёх canonical copies. SourceZIP без tests/private-assets; нужен Git checkout.

## Публикация RP289–RP300 и смена Codex

По прямому запросу пользователя весь накопленный результат отправляется в GitHub `NEONARCHY/DeepRole`, ветка main. Короткий актуальный маршрут для другого Codex: [HOME-CODEX-NEXT](docs/HOME-CODEX-NEXT.md). Там перечислены выполненное, ограничения проверок, точные команды и следующая задача. Прежние «push не запрошен» ниже — исторические записи, отменённые нынешним запросом на публикацию. Пользователь не просил менять установленную копию, личные миры или аккаунт.

## Текущая точка RP300 — условия запрета до разрешения

Один runtime-файл story-obligation-recall.ts. Accepted task titles пока/без/unless/without допускаются к прежней literal source-bound группе; запрет и task status сохраняются, permission/completion не выводятся. Добавлены finite preparation-vs-completion query, compound request «что нужно соблюсти»/what must be respected, той-договорённостью и earlier-business reference. У пользователя запрос не становится source evidence. Caps/rollback/optouts прежние. [Описание](docs/EXCEPTION-REPAIR.md).

Перед runtime-правкой сохранены RP298 obligation/context snapshots; RP299 first15/22/input/gold/seal/runner/protocol не переписывались. Historical pins routed к снимкам. Before11failed/49pass:7recall cases,2guard-only controls и2новых EN adversarial controls (title-only/two-labels). Всего5guardgaps,3совмещены сrecall. После60/60 новых repair checks; целевой SEEN22/22/100gold,0missing/integrity/guards/lostprior. Budget2800/5600 теперь8/8RUEN;900stillincomplete. Общая QA: docs/benchmarks/rp300-qa-results.json.

Следом новая независимая frozen выборка, не повторный «слепой» прогон известных текстов. General semantics/RP-05/true delta открыты. Не менять первые отчёты/gold/seals; ограниченный lexical matcher не универсальное понимание. Installedcopy/worlds не менялись,push не запрошен.

RP300 final QA: семь SEEN наборов rp300a —546inputs/324scored/1508gold,0missing/integrity/guardgaps/lostprior. Первые5частичныхrp300reports сохранены: Vitewatcher прервался EBUSY на TEMP Cookies параллельного nativebrowser; исходный runner сохранён rp300-attempt-runner.txt, повтор только с watch:null, без runtimeизменений. Fullunit8501pass/0fail/5existingTODO,307files,233.84s. Unifiedstrict492pass/60of60/2427pairs57configs. TypeScript/diff0,ChromeFirefoxbuildZIP0,старыйchunkwarning. Native syntheticEdgeRUEN2pass/0fail/0flaky,88.281s,contextsclosed. НеliveDeepSeek/newplot-modelproof. Финальныеpackagehashes:QA-report.

RP300 finalpackages:23Chrome/23Firefox/868source entries SHA256 againstdisk и3canonicalcopieschecked;финальныеnotes/reports повторноупакованы. SourceZIP excludes tests/private-assets;QA требуетGitcheckout. Installed extension не перезагружалась. Следующая задача остаётся fresh frozen audit; user-push не запрошен.

## Текущая точка RP299 — новый аудит запрета до условия

Runtime RP298 не менялся. Fresh RU/EN затопленный театр: пока/без разрешения/unless/without, отдельные одноимённые плащи, запасной предмет, общие aliases, секретность/ended permission.38inputs/22scored/100gold/10controls/6budget/14uncertainty, до7500background. До первого compiler-run414fingerprints, wx baseline/report/seal. Первый15/22,89/100gold,11missing в7queries,5guardgaps,0integrity/falsecomplete. [Результаты и пример](docs/EXCEPTION-RESULTS.md), [первый отчёт](docs/benchmarks/rp299-exception-results.json).

Прямые/qualified/negative/revoked/scale полны;paraphrase0/2,compound0/2,same-label1/2,freeref0/2. Guardgaps: RU same-label/raw-only/unknown-tail, RU+EN freeref;все14UIunverified. Budget2800/5600still6/8 в обоих языках. После результата только unusedparams i→_i в fixture, frozenoriginal сохранён rp299-first-fixture.txt; тесты проверяют414hashes по snapshot и идентичные сериализованные inputs/gold. Runtime/протокол/runner/firstreport/seal не трогали.

Дальше fix7incomplete/5guards отдельным SEEN плюс6 прежних корпусов. ДО runtimeправок сохранить RP298 snapshots по frozenhashes. Не переписывать15/22/gold/seal. Не capincrease/owner guessing/вывод выполнения условия. Общая семантика/RP-05/true delta открыты. QA: docs/benchmarks/rp299-qa-results.json. Не live model, installedcopy/worlds unchanged; push не запрошен.

RP299 QA887pass/0fail в27files:42new+353oldregressions+492unifiedstrict,old60/60/0gaps. Финальный42auditcheck после snapshot/unusedparams пройден. TypeScript/diff0;ChromeFirefoxbuildZIP0,старыйchunkwarning. Fullunit/native/live не повторяли:runtime/UIunchanged. Архивы/source exclusions: QA-report; installedcopy не обновлялась.

RP299 final packages:23Chrome/23Firefox/847source entries SHA256 againstdisk,3canonicalcopies;финальныеnotes/reports повторно упакованы. SourceZIP без tests;QA требуетGitcheckout. Эта итерация audit-only, не исправление7 новых случаев.

## Текущая точка RP298 — подбор условий принятой задачи

Исправлен один runtime-файл: story-obligation-recall.ts. Условные заголовки теперь дают буквальную группу только при подтверждении другими принятыми текстами, собственной цитатой, ролями и эпизодами. Не новый extractor и не вывод о выполнении условия. Добавлены ограниченные формы вопросов/составных действий и проверка каждой неоднозначной фразы сцены. Два независимых предмета или заголовок без подтверждения — отказ от дополнительного подбора. Caps не повышены.

RP296 snapshots сохранены до правки; RP297 first23/38, gold, seal и runner не переписаны. Новый SEEN38/38/176gold; шесть корпусов:508inputs/302scored/1408gold,0missing/integrity/guardgaps/lostPriorFacts. Добавлены86checks, включая unsafe title/two labels. Unified strict492pass. Полная QA/сборки: [отчёт](docs/benchmarks/rp298-qa-results.json). [Поведение и ограничения](docs/CONDITIONAL-REPAIR.md).

Следом новая независимая выборка с ожиданиями до первого запуска. Общая семантика, RP-05/true delta остаются открытыми. Не live DeepSeek; пользовательские миры и установленная копия не менялись. Push не запрошен.

RP298 final QA: full unit 8399pass/0fail/5existingTODO,305files,238.37s; финальная проверка audit+repair154pass после удаления неиспользуемых imports. TypeScript0. Native synthetic Edge RU/EN2pass/0fail/0flaky,84.675s,contextsclosed; не проверка новых сюжетов на живой модели. Chrome/Firefox buildZIP0; первый Chrome TEMP access-denied устранён отдельной project-local TEMP, старый >500KB warning остался. Финальные архивы: QA-report.

RP298 packages:23Chrome/23Firefox/838source entries, каждый SHA256 сверен с диском,3canonicalcopies; финальные docs/reports повторно упакованы. Tests исключены из sourceZIP, QA требует Git checkout. Installed extension не перезагружалась.


## Текущая точка RP297 — новые conditional commitments: первый замер

НовыйauthorRUENcorpus:вулканическаяпочта/горнаяобсерватория. ConditionalcommitmentsбезI promise to,openA/completedBодноимённыевещи,запасной/малыйqualifiedC,общийкороткийaliasдвухперсонажей,negativeprivacyduty иотозванноеscenepermission(statusended).64inputs/38scored/20controls/6budget,176gold,28uncertainty,до7500backgroundrecords. [Протокол](docs/CONDITIONAL-EVALUATION.md), [результат/пример](docs/CONDITIONAL-RESULTS.md).

Доcompilerfrozen414hashes(schema/input/gold/protocol/ownrunner/helper/all410src),separatefreeze/evaluate,wxfirstbaseline/report/seal,before-afterunchanged. Preflightсначалаотклонилаendedclaim.value;representation исправленнаvalue=text ДОfreeze/первогоcompiler,prose/goldне меняли. RuntimeRP296не менялся. Первый23/38complete,138/176gold,38missingв15queries;0integrity/falsecomplete. Paraphrase0/4,compound0/4,samelabel1/4,freeref0/4. Explicit/qualifiedC/negative/permission4/4,scale6/6.28UIunverified,24guard/4gaps onlyfreeref;20controlsguarded. MissingA0×7/A1×15/A2×12/A3×2/B1×2. Budget900=3/8,2800/5600=5/8RUEN. [Firstreport](docs/benchmarks/rp297-conditional-results.json), [seal](docs/benchmarks/rp297-first-report-seal.json),непереписывать.

QA929pass/0fail в29files:68newaudit+369oldregressions+492unifiedstrict. Старыйunified60/60/0gaps,old34/34сохранены,неопровергаютnew23/38. TypeScript/diff0,414hashes/oldseals/seenпрежние. Fullunit/native/liveнеповторялись:runtime/UIunchanged. [QA](docs/benchmarks/rp297-qa-results.json). Build/packagefinalstatusниже. Пользовательскиеworlds/installedcopy/accountнетронуты,pushнепросили.

Следомfix15incomplete/4guardsотдельнымseen+oldregressions. ДОruntimeправкиsnapshotRP296нужныхsourcefilesпо414hashes,проверятьhistoricalpinsпоним,неудалять. First23/38/gold/sealсохранить. Conditionalsourcegroups,непростоочереднойсловарьглаголов;неguessshortalias/неmergeобычный-запаснойobject/неfulfilусловноепоходувремени. Capsнеповышать/quotesнерезать. Corpusтеперьseen,неexternalblindproof;7500recordsнесыгранныесцены,roles/tasksacceptedgiven,переводы/каркаскоррелируют. RP-05/general semantics/true deltaоткрыты.

RP297 finalpackages:ChromeFirefoxbuildZIP0,прежний>500KBchunkwarning;23Chrome/23Firefox/824source entriesSHA256against disk/3canonicalcopieschecked,финальныеnotes/reportsповторноупакованы. Installedcopyнеобновлялась;sourceZIPисключаетtests,QAтребуетGitcheckout. Все929checks/types/diff/frozenhashes/oldsealsпроверены;этаитерацияauditonly,неfixусловныхобязательств.

## Текущая точка RP296 — условия явных prose-обещаний восстановлены

Изменены2runtimefiles:story-obligation-recall/game-context. Generic affirmative explicit promise suffix вместо добавления каждогоverbвwhitelist;literalprefix должен встретитьсяв2другихacceptedtexts,wholegroup sourceproof обязателен. Неsemanticparser/owner/objectresolver. Negativeне/not/neverнеpositivekey;старыеreturn/delivery/tersepaths/caps/wholebudget/rollback/optouts прежние. Boundedagreement/work/action-recall queryформы,work-inquiryguardдажеприfailedsource. [Описание/пример](docs/ACCESS-REPAIR.md).

Сохранены2точныхRP294snapshots;RP295historical414hashesпроверяютсяпоним,first23/34/gold/seal/report/runnersнепереписаны. Before12failingcases воспроизведены(11incomplete+одинfullбезguard).83newchecks включаяnewverb/negation,quotes/episodes/budget/missingpeople иunsafequeries. Unithelperисправленнаproductioncontractcompactcurrentfacts иполныйrole-reader,не rawsupersededfacts.

SEENreportsRP296:RP29534/34/160gold,oldRP29260/60/306,RP28954/54/204,RP28762/62/250,RP28354/54/312. Всего444inputs/264scored/1232gold,0missing/integrity/guardgaps/lostPriorFacts. [Новыйseen](docs/benchmarks/rp296-rp295-seen-results.json). Budget900still2/7,budget2600/5200теперь7/7RUEN. Старыйunifiedstrict492pass/60/60/0gaps. Fullunit8245pass/nativeEdge2pass завершены;finalQAниже. TypeScript/diff0,ChromeFirefoxbuildZIP0. НеliveDeepSeek,миры/installedcopyнетронуты,pushнепросили.

**RP296 финальная QA:** fullunit8245pass/0fail/5existingTODO из8250 в303files,225.97s c2workers;83newchecks. Unifiedstrict492pass/60/60/0gaps;пятьSEENcorpora264/264scored/1232gold/444inputs,0missing/integrity/guards/lostprior. NativeisolatedsyntheticEdgeRUEN2/2pass/0fail/0flaky,86.26s,outgoingwholeproofs/retry/reload,contextsclosed. TypeScript/diff0,ChromeFirefoxbuildZIP0,старыйchunkwarning. Full/native completed;liveDeepSeek/nativeFirefox/fullE2Eнепроверены. [QA](docs/benchmarks/rp296-qa-results.json). Следомfreshfrozenindependentcorpus,особеннодругиеформыусловий/сложныесценысовпадений,невыдаватьSEENзагeneral semantics. RP-05/true deltaоткрыты. До будущихruntimeправоксохранитьRP296snapshotsпопинамreport.currentDigests;историческиерезультатысохранить.

RP296 finalpackages:23Chrome/23Firefox/815source entriesSHA256against disk/3canonicalcopieschecked,финальныеnotes/reportsповторноупакованы. Installedcopyнеперезагружалась;дляQA нуженGitcheckout,sourceZIPисключаетtests. Новыйruntimeготовдляпроверкипользователем;личныеданныенетронуты,pushнепросили.

## Текущая точка RP295 — новый замер выявил оставшиеся потери

Новый authoredRUENcorpus:луннаяоранжерея/затопленныймузей;калибровка,вскрытие,удостоверение,публикация;одноимённыевещи разныхowners,openvsсancelled,подготовканеcompletion,accessнеpermission.60inputs/34scored/20controls/6budget,160gold,28uncertainty,до7000backgroundrecords. Fixtureнеимпортируетoldcorpora/querymatcher/scorer;roleSeedconstructoronly. [Протокол](docs/ACCESS-EVALUATION.md), [результаты/пример](docs/ACCESS-RESULTS.md).

Доcompilerfrozeninput/gold/protocol/ownrunner/all410src:414fingerprints,separatefreeze/evaluate,wxfirstreport/seal,before-afteridentical. ИгровойкодRP294не менялся. Первый23/34complete,137/160gold,23missing в11queries;0integrity/falsecomplete. Families:explicit4/4,paraphrase3/4,compound0/4,samelabel1/4,freeref1/4,publication-access4/4,permission4/4,scale6/6. Все28UIunverified,24guard/4gaps onlyfreeref.20controls guarded. MissingA1×8/A2×10/A3×1/B1×2/B3×2. Budget900=2/7,2600=5/7,5200=6/7наRUEN. [Первыйreport](docs/benchmarks/rp295-access-results.json), [seal](docs/benchmarks/rp295-first-report-seal.json). Не переписывать!

QA778pass/0fail в27files:64newaudit+222oldreports/repair+492unifiedstrict. Unifiedстарый60/60/0gaps — не опровержение нового23/34. TypeScript/diff0,414hashes/oldseals/seen unchanged. Fullunit/native/browser/live не повторяли:runtime/UI прежние. SourceZIP исключаетtests,QA требуетGitcheckout. [QA](docs/benchmarks/rp295-qa-results.json). Build/package finalstatus ниже. Installedcopy/миры/аккаунтне трогали,pushнепросили.

Следомfix11incomplete/4guards отдельнымseenreport иoldregressions. Сначаласохранить нужныеRP294source snapshots согласноRP295414hashes,проверятьhistoricalpinsпоним. Не удалятьpins/first/gold/seal. Проверитьцелые группыусловийaccess/currentplace/unfinished иfinitefreerefs;unsupportednewverbs—подозреваемыйфактор,не доказаннаяпричинавсехпотерь. Не повышатьcaps/неугадыватьowner/необъединятьsame-labelobjects. Corpusтеперьseen;RP-05/general semantics/true delta открыты. Этоsyntheticagent-authored,не externalblind/liveproof;переводы/каркаскоррелируют,7000recordsнесыгранныесцены.

RP295 finalpackages:Chrome/FirefoxbuildZIP0,прежний>500KBchunkwarning.23Chrome/23Firefox/802source entriesSHA256against disk/3canonicalcopieschecked,финальныеnotes/reportsповторноупакованы. Fullunit/native/live не повторялись;installedcopy прежняя. Зааудит778pass/0fail;все414frozenhashes иoldsealsunchanged. НуженGitcheckoutдляQA,sourceZIPисключаетtests.

## Текущая точка RP294 — условия памяти восстановлены

Исправлены ровно2runtimefiles:game-context/story-obligation-recall. Добавлены handover/replacement prose verbs, bounded delivery paraphrases, finite agreed-restrictions references и action-plus-recall csemicolon. Сохраняются целые source-bound группы с отдельными task/owner/status,не identity inference. Named return queries прежние,source/episode/quote proof и16tasks/4labels/128rows/whole-budget rollback сохранены;action/compound opt-outs работают. Supported reference получаетguard дажеесли bridgeне найден. [Поведение/пример](docs/CROSS-OWNER-REPAIR.md).

До правки сохранены точныеRP291snapshots2files;historical unitpins проверяют их,не новыйruntime. RP292first39/60/gold/seal иoldseenreports/runners прежние. SEEN RP294b:RP29260/60/0missing/0guardgaps,RP28954/54,RP28762/62,RP28354/54;0sourceintegrity и0lostPriorFacts на384inputs. IntermediateRP294 report59/60 сохранён,не переписан.

Unified strict `npm run test:memory -- --strict-recall` exit0:492/492checks,2427pairs/57configs/27factors;60/60goldqueries полны,0missing/0confidencegaps. [Сводка](docs/benchmarks/rp294-memory-summary.json).116новых focusedchecks включают malformedquote/episode/budget иopt-outs. Первый fullrun под конкурирующей нагрузкой имел4timeouts и2реальныхassertionfailures;namedfallback/semicolon исправлены,finalfullrun с2workers прошёл8098checks безfailures иувеличенияtimeouts. TypeScript/diff-check0;Chrome/FirefoxbuildZIP0. Native syntheticEdge2/2pass,liveDeepSeek не проверен;installedcopy/личныймирнеобновлялись,pushнепросили.

**RP294 финальная QA:** fullunit8098pass/0fail/5existingTODO из8103,301files,261.71s c2workers;116newfocusedchecks. Unifiedstrict492pass,60/60complete/0missing/0gaps. Seen384inputs сохраняютвсеpriorselected,0integrity. Native isolated syntheticEdge RUEN2/2pass/0fail/0flaky,93.58s;outgoingwholeproofs/retry/reload,contextsclosed. LiveDeepSeek/nativeFirefox/fullE2Eнепроверены. TypeScript/diff0;ChromeFirefoxbuildZIP0,старыйchunkwarning. [QA](docs/benchmarks/rp294-qa-results.json). Предыдущая строка «идёт finalfullrun» выше относится к промежуточному этапу,финальныйуспех подтверждён. Следом: новый заранееfrozen независимыйcorpus другихситуаций;не выдавать60/60seenзаgeneral semantics. RP-05/general semantics/true delta открыты;пользовательскиймир/installedcopy прежние,pushнепросили.

RP294 finalpackages:23Chrome/23Firefox/793source entries SHA256against disk,3canonical downloads copies проверены;финальныеnotes/reports повторноупакованы. Installedcopy отдельноreload;обновлённыеархивы вdownloads,пользовательские данные не тронуты.

## Текущая точка RP293 — unified memory tests, не runtime fix

Создан `npm run test:memory` (`scripts/test-memory.mjs`):57 детерминированных конфигураций покрывают все2427 пар значений27 факторов. RUEN/3plots/450–6500background/900–16000budget/3transports/14variants/cache/15searchflags плюс lore enabled-disabled-excluded/profile/recap/choices/required. Независимый oracle проверяет каждый pair;каждый ряд проходит настоящий compiler дважды. Дополнительно8multiway/isolation и96defaultRP292observations. [Описание/границы](docs/MEMORY-TEST-SUITE.md).

Тот же запуск включает20existing lifecycle suites:330checks,включая >100длинных синтетических сцен,роли/clock/task statuses/manual correction/alternate branch/continuation/reload/retry/concurrent tabs/backup/encryption/reset. Не Cartesian coverage lifecycle×compiler и не live DeepSeek. JSON каждого запуска отдельно в.output/memory-tests;финальные копии docs/benchmarks/rp293-*.json.

Финал492/492assertions(162+330),22files;strict-recall exit1 ОЖИДАЕМ из-за39/60complete,42missing/6guardgaps. integrityPassed=true,recallComplete=false. Ordinary exit0 означает только инварианты,strict требует и полного recall. Первый ordinary484pass до8extra checks сохранён локально. Historical seals/fingerprints/seen106/106;TypeScript/diff-check0. Runtime src не менялся,RP292first/gold/fingerprints сохранены. Fullunit/native/browser/live API не запускались. Следом чинить21losses/6guards отдельнымseenreport;не называть тестовый набор исправлением памяти. Мир/installedcopy не тронуты,push не запрошен. Build/package status см. финальную QA ниже.

RP293 final packaging: Chrome/Firefox build+ZIP exit0, прежний >500KB chunk warning. Все23Chrome/23Firefox/777source entries проверены SHA256 against disk и3canonical downloads copies;финальные notes/reports повторно упакованы. Source ZIP исключает tests,дляunifiedQA нуженGitcheckout. Installed extension не перезагружалась.

## Текущая точка RP292 — новый независимый audit завершил первый замер

Новые авторские истории: дирижабль, соляной караван и типография, RU/EN, до 6500 фоновых записей. Всего 96 inputs: 60 scored, 30 controls, 6 budget probes; 306 gold records и 42 uncertainty expectations. Новые ситуации: передать/hand over, заменить/replace; одинаковые названия вещей у разных владельцев; отмена второй передачи; отдельные условия доступа, приёма, подготовки и разрешений. Fixture не импортирует старые corpora, matcher или scorer. Игровой код RP291 не менялся. [Протокол](docs/CROSS-OWNER-EVALUATION.md), [результаты и пример](docs/CROSS-OWNER-RESULTS.md).

Первый результат: **39/60 полных запросов, 264/306 gold records; 42 пропуска в 21 case**. Потери: paraphrase — 6 cases/9 records; same-label — 5/10; free-reference — 4/11; composite — 6/12. Именованная передача, замена, две работы, отмена, границы разрешения и scale — каждое семейство 6/6. Source/role/status/quote/revision/episode/input/canon/cache/budget integrity issues и false complete — 0. Все 42 uncertainty inputs имеют UI unverified; 36/42 также explicit guard. Шесть guard gaps — только rephrased-reference RU/EN. Все 12 новых wrong-promisor/unknown-object защищены. Budget900 теряет четыре A-records из семи на RU/EN; 2400/5200 полны, эти probes вне recall.

Schema/input/gold/protocol/собственный runner и все 410 src зафиксированы до compiler: 414 fingerprints; отдельные freeze/evaluate, wx first report/seal, hashes до и после совпали. [Первый report](docs/benchmarks/rp292-cross-owner-results.json), [seal](docs/benchmarks/rp292-first-report-seal.json). Прежние reports/gold/seals/seen не менялись. Это agent-authored synthetic accepted-memory audit, не blind external/live-model proof. Общий каркас, переводы и фон коррелируют; 6500 records — не 6500 сыгранных сцен; роли даны принятыми seeds, не извлечены живой моделью. Новые кейсы теперь seen.

RP292 завершён. QA: 1056/1056 checks в 11 files, 100 новых checks, 57.38s; первый scoped run1055/1055 до дополнительного anchor первого результата сохранён. TypeScript/diff-check0. Все414 fingerprints и old seals/RP291 digests проверены. Full unit/native/browser/live-model/fullE2E заново не запускались: runtime/UI не менялись. Chrome/Firefox build+ZIP0, прежний >500KB warning;23/23 runtime и771source entries SHA256 against disk/3canonical copies проверены,финальные notes повторно упакованы и проверены. Source ZIP исключает tests;для QA нужен Gitcheckout. Installed copy не обновлялась;устанавливать сборку только ради audit не требуется. [QA](docs/benchmarks/rp292-qa-results.json).

Следом: воспроизвести 21 неполный запрос, особенно целые same-label A+B группы с разными owner/task/status/source, затем paraphrase/composite conditions. Проверить prose verbs handover/replacement: нынешний supplement допускает return/delivery/repair, но это ещё не исчерпывающее доказательство причин всех потерь. Для шести free-reference guard gaps нельзя использовать raw/quoted/conditional/action text как положительный bridge. Не повышать caps, не резать условия, не объединять objects ради green. До будущей правки сохранить snapshots нужных RP291 source файлов по RP292 fingerprints;historical unit pin проверять по ним,не удалять целиком. Fix — отдельный seen report на RP292 плюс old RP289/RP287/RP283 regressions; first39/60/306gold/report/seal не переписывать. RP-05/general semantics/true delta открыты. Личный мир и installed copy прежние, браузер/API не использовались, push не запрошен.

## Текущая точка RP291 — предпосылка вопроса не доказывает owner/object

12/12 RP289 swapped-owner/invented-object cases сначала воспроизвели missing warning. Данные/исторические роли при этом были целы;не «исправляли» правильные source bindings под имя из вопроса. `obligationPremiseQuestion` распознаёт finite RUEN explicit obligation+object questions;bare role questions прежние. Новый `UNPROVED_OBLIGATION_PREMISE` говорит,что вопрос не доказательство promise/owner/object,не подставлять другого человека/похожуювещь,не смешиватьsource conditions/status и не считать отсутствие в выбранных источниках отсутствием во всём мире.

Изменены те же2runtime files:story-obligation-recall.ts/game-context.ts. Guard отделён от retrieval reference:не создаёт label/identity,не сужает старый поиск;входитв required/whole meter до optional facts,не дублируетexistingreferenceguard. Complete для такой предпосылки не обещается;budget/overflow/opt-out/restart/reference-only прежние.27новых runtime checks+3report checks. Снимки2finalRP290runtime сохранены;егоreportdigests проверяются поним,не переписаны. [Описание](docs/OBLIGATION-PREMISES.md).

Final SEEN RP291:RP28954/54,204/204,0missing/integrity/confidence gaps,42/42guard+unverified;23outputs изменились только предупреждением/его metering. RP28762/62,250/250,0loss/gaps,1changedoutput;RP28354/54,312/312,0loss/gaps,2changedoutputs. Все288selectedIds/порядок иcoverage прежние;budget иrejectioncontrols прежние. Inputs/gold/firstseals иRP290b reports сохранены. Это seen,не новая независимая/live оценка. [RP289](docs/benchmarks/rp291-rp289-premise-seen-results.json), [RP287](docs/benchmarks/rp291-rp287-premise-seen-results.json), [RP283](docs/benchmarks/rp291-rp283-premise-seen-results.json).

**RP291 завершён:**fullunit7720pass/0fail/5existingTODO из7725 в297files,320.54s;27newruntime+3reportchecks,focused72runtime+6report pass. TypeScript/diff-check0. Native isolated synthetic Edge4/4pass/0fail/0flaky,181.81s,102localPOST:RUEN wrong-owner/invented-object warning вrealoutgoingPOST,wholequotes/tasks/roles/revisionIDs,503retry/XHR/fetch/reload/old delivery-return-gift/unchangedcanon. Contexts закрыты. Live DeepSeek/nativeFirefox/fullE2E не проверены.412/414original fingerprints unchanged,2expectedruntimeedits/noaddedruntime;2RP290snapshots иold first reports/gold/seals прежние. Chrome/Firefox build+ZIP0,старый>500KBwarning;23/23runtime и765source entries/canonicalcopies SHA256checked,finalnotes повторно упакованы и проверены. SourceZIP исключаетtests,дляQA нуженGitcheckout. [QA](docs/benchmarks/rp291-qa-results.json). Installedcopy не обновлялась.

Следом — новый независимый заранее frozen набор других сюжетов/формулировок/противоречивых вопросов. Не повторять уже закрытые17missingrecords/12guardgaps и не выдавать ограниченную грамматику за general semantics. RP-05/true delta открыты. Личный лор/installedcopy не менялись,push не запрошен,новых model/API calls нет.

## Текущая точка RP290 — исправление условий доставки

По запросу пользователя исправляются11 RP289 losses:дополнительный подбор раньше принимал return tasks,не delivery/repair;shipping inquiry не допускался;EN known-name possessive мешал prefix. Расширены2runtime files:story-obligation-recall.ts иgame-context.ts. Имена/сюжеты/ID не зашиты;поддержаны finite RUEN forms,не general semantics. Все whole quotes/roles/status/canon/draft/episode safeguards прежние,shipping/ref coverage unverified/query.

Первый native2pass/2fail обнаружил пять старых labels при6bound tasks/30revision sources;cap4 стоял до accepted-scene scope и блокировал новую delivery. Из trace восстановлен input,два failing RUEN tests подтвердили. Для reference4candidate labels считаются после scope;scan16tasks,4broad labels,128rows,один effective bridge/whole budget сохранены. Assertions накаждую запись не ослаблены. [Контракт/пример](docs/MIXED-OBLIGATION-REPAIR.md).

Промежуточные rp290/rp290a reports сохранены;первый прогон пересекался с добавлением negative shipping-command guard,не считать его runtime provenance финальным. Отдельныйa прошёл неизменные before/after digests,но предшествовал native scope fix. Финальный замер — rp290b на прежних96/108/84inputs. Original RP28943/54,RP28758/62,RP28339/54 и всеgold/seals прежние;снимки2RP289original runtime проверяют исходныеfingerprints.

**RP290 завершён:**seen RP28954/54,204/204,0missing/integrity/lostPrior;12changedoutputs(только6paraphrase+6proved-reference),0coverage changes,всеостальные84outputs/budget прежние.12guard gaps остаются. RP28762/62,250/250 иRP28354/54,312/312,все192outputs/coverage истарые controls прежние. [Final RP289](docs/benchmarks/rp290b-rp289-mixed-seen-results.json), [RP287](docs/benchmarks/rp290b-rp287-mixed-seen-results.json), [RP283](docs/benchmarks/rp290b-rp283-mixed-seen-results.json). Это seen,не новый independent/live proof.

Fullunit **7690pass/0fail/5existingTODO в295files**,231.55s,45newruntime+3report checks;TypeScript/diff-check0. Ранние full7671/7682pass до native scopefix сохранены. Final isolated synthetic Edge **4/4pass/0fail/0flaky**,133.25s,90localPOST:RUEN delivery/oldreturn/gift,whole quotes/tasks/roles/revision IDs,503retry/XHR/fetch/reload/unchangedcanon. Contexts закрыты. Live DeepSeek/nativeFirefox/fullE2E не запускались.412/414baseline fingerprints прежние,2expectedruntime edits,410sourcefiles/noaddition;old frozen reports/gold/seals сохранены. Chrome/Firefox build+ZIP0,старый>500KBwarning.23/23runtime и757source entries SHA256 againstdisk/3canonicalcopies проверены,notes повторно упакованы и проверены. SourceZIP исключаетtests,дляQA нуженGitcheckout. [QA](docs/benchmarks/rp290-qa-results.json). Installedcopy не обновлялась.

Следом:12 RP289 explicit guard gaps для swapped-owner/invented-object без угадывания владельца,затем новый independent корпус. Не выдавать текущие seen данные за новую независимую проверку. RP-05/general semantics/true cross-turn delta открыты. Личный мир/installedcopy не менялись,модель/API не вызывались,push не запрошен.

## Текущая точка RP289 Новый независимый audit разных обязательств

По актуальной передаче RP288 выполнен новый заранее frozen audit на неизменённом runtime RP288/main4e8c06c.3 новых сюжета(пекарня/ледник/планетарий),RUEN,доставка/ремонт/оплата/сопровождение/секрет,96inputs:54scored/36controls/6budget,960main и320/1800/6000scale scenes. **Первый43/54 complete,187/204 gold records,17missing в11cases**:все6paraphrases и5/6proved-reference;все именованные delivery/repair/two-jobs/payment/cancelled/secrecy/scale полны. [Результат/примеры](docs/MIXED-OBLIGATION-RESULTS.md), [протокол](docs/MIXED-OBLIGATION-EVALUATION.md), [report](docs/benchmarks/rp289-mixed-obligation-results.json), [seal](docs/benchmarks/rp289-first-report-seal.json).

Все96 source/roles/status/quote/revision/episode/input/canon/cold-warm/whole-budget integrity checks без ошибок.42/42 uncertainty cases UI unverified,0false-complete;30/42explicit guard,12guard gaps только swapped-owner/invented-object RUEN×3plots. При900 budget omissions RU5/7/EN6/7,2200/5000 полны;budget probes вне recall. Это agent-authored synthetic accepted-memory audit,не blind external/live model proof;correlated translations/backgrounds не равны96 независимым историям. Все новые примеры теперь seen,проценты разных corpora не сравнивать как рост.

До первого compiler выявлена metadata-only preflight ошибка:runner fingerprints ссылались на прежний harness. Initial baseline/preflight runner snapshot сохранены;v2 manifest отдельно frozen с exact same input/gold/rows/runtime и правильным собственным runner,414fingerprints. Compiler импортирован только в отдельном evaluate после проверки v2;первый report/seal wx,ничего не перезаписывалось. Runtime/UI/storage/settings/model не менялись,старые first reports/seals сохранены. Личный мир/аккаунт/installed copy не трогали,push не запрошен.

RP289 QA: **1068/1068tests в12files**,включая100новых checks,161.05s;TypeScript/diff-check0. Все414frozen fingerprints,включая410runtime,и old seals проверены. Fullunit/native/UI/live DeepSeek/fullE2E заново не запускались:runtime/UI неизменны. [QA report](docs/benchmarks/rp289-qa-results.json). Chrome/Firefox build+ZIP0;прежний warning >500KB.23/23 runtime и743source entries проверены SHA256 против диска;3 canonical download copies совпадают,нет вложенныхZIP/private/tests. Финальные notes повторно упакованы и проверены. SourceZIP исключает tests,дляQA нужен Git checkout. Устанавливать сборку ради audit не требуется.

**Следующий этап после QA:** расследовать11 потерь,начиная с a1 access conditions для proved delivery bridge(теперь это не только return),затем paraphrase a1/a2/a3. Отдельно guard12swapped-owner/invented-object без угадывания source/owner. Сначала доказать конкретную причину в matcher,потом fix с отдельным **seen** report и старыми RP283/RP287 regressions;первый43/54/gold/seal не менять. Не сужать scope по hard queries,не терять самостоятельное второе вхождение общего label,не передавать чужие условия,не повышать capacity/обрезать цитаты ради зелёного. General semantics/RP-05/true delta открыты.

## Публикация RP274–RP288 по запросу пользователя

Публикация всего накопленного выпуска по запросу пользователя: [PR #2](https://github.com/NEONARCHY/DeepRole/pull/2), ветка `codex/rp274-rp288-memory-safety`, база `main`/`7005aa6`. Актуальный статус слияния доступен в PR. В выпуск входят код, tests/fixtures, неизменённые первые отчёты и seals, обновлённые Chrome/Firefox/source ZIP и инструкции продолжения. Старые фразы «push не запрошен» ниже описывают состояние на момент соответствующего этапа.

**Домашнему Codex после обновления main:** продолжать с верхнего RP288: новый заранее frozen independent audit на других сюжетах и обязательствах. Фиксы RP288 уже завершены:7542 unit pass/0fail/5TODO,10/10 synthetic Edge,seen RP28762/62 иRP28354/54. Первый independent58/62 сохранён;RP-05 не закрыт. Не начинать повторно исправление4 пропусков и23 guard gaps и не менять зарегистрированные inputs/gold/first reports ради зелёного.

## Текущая точка RP288 — короткие ссылки защищены и целые группы восстановлены

Исправлены2 runtime files: `game-context.ts` определяет поддержанную short obligation reference ДО всех passes,guard входит в required/whole meter и сохраняется при отказе bridge/source/capacity/budget. Unverified/query даже при successful literal matching;required-overflow и referenceRecall:false сохраняют свои контракты. `story-obligation-recall.ts` выбирает longest source-proved prefix,который присутствует в text+quote принятой сцены;short prefix shadowed только на покрытом вхождении. Отдельное второе вхождение остаётся ambiguous;идентичные labels —список разных source/task/owner кандидатов,не object ID.16tasks/4labels/128rows/source/scope/status/draft/canon guards прежние. [Мануал/примеры](docs/SHORT-REFERENCE-SAFETY.md).

Separate seen reports: [RP287](docs/benchmarks/rp288-rp287-reference-seen-results.json) **62/62 vs58/62,250/250,0missing/integrity/confidence gaps,48/48 guard+unverified**;26outputs/7coverage changes. LostPriorFacts=2 честно сохранён:ENtheatre c1/c2 про посторонний жилет больше не подмешиваются к плащу;канонические записи не удалены.82others/6budget unchanged. [RP283](docs/benchmarks/rp288-rp283-reference-seen-results.json)54/54,312/312,0loss/integrity/rejection drift;1reference output/83others+allcoverage unchanged. First RP28758/62/RP28339/54 и frozen inputs/gold/protocol/seals прежние. Не новый independent/live proof.

RP288:full unit7542pass/0fail/5 прежнихTODO из7547,74 новых checks;ранние260+71pass. TypeScript/diff-check0. Native isolated synthetic Edge10/10pass/0fail/0flaky за166.02s:expanded obligation2+contextual2+recap2+UI4(RUEN320/900,keyboard/axe/no overflow);новые scope/roles/quotes/retry503/fetch/XHR/reload/raw-only fallback,46POST. Первыйnative8pass/2test-fixture ID errors сохранён;mock helper исправлен поreadyevent,assertions не ослаблены. Frozen inputs/gold/protocol/firstseals прежние;412/414 fingerprints unchanged,2expected runtime edits. Chrome/Firefox build+ZIP0,старый>500KB warning. Live DeepSeek/nativeFirefox/fullE2E не проверялись,installed copy не обновлялась. 23/23 runtime и735 source entries проверены byte/CRC;3 canonical download copies SHA256 match,финальные notes повторно упакованы. Source ZIP исключает tests;для QA нужен Git checkout/Node22.

**Следующее после завершения QA:** новый заранее frozen independent audit с иными сюжетами/свободными ссылками/независимыми вхождениями общих названий и другими типами обязательств. Не выдавать seen62/62 за новую оценку и не расширять parser по каждому тесту без source/ambiguity guard. Общая семантика/любые местоимения/true cross-turn delta/RP-05 остаются открыты. RP274–288 локально поверх7005aa6,push не запрошен;личный мир/installed copy не менялись. [QA](docs/benchmarks/rp288-qa-results.json).

## Текущая точка RP287 — новый independent audit долгов завершён, короткие ссылки требуют исправления

Новый preregistered audit на неизменённом RP286:4 новых сюжета(театр/сад/радио/регата),RUEN,108 inputs (62scored/40controls/6budget),720 background scenes +scale250/1500/5000. Schema preflight до compiler execution,414 frozen fingerprints; первый report/seal wx. **58/62 complete,244/250 gold records,6missing в4 proved-reference cases**. Все именные/парафразы/два владельца/completed/cancelled/scale полны; короткие ссылки4/8. [Результаты/примеры](docs/OBLIGATION-HOLDOUT-RESULTS.md), [protocol](docs/OBLIGATION-HOLDOUT-EVALUATION.md), [first report](docs/benchmarks/rp287-obligation-holdout-results.json), [seal](docs/benchmarks/rp287-first-report-seal.json), [QA](docs/benchmarks/rp287-qa-results.json).

0 source/quote/role/task/status/revision/episode/whole-budget/immutability/cold-warm integrity issues во108. Из48 ожидаемо unresolved inputs **23 без explicit guard**,7 изних complete вместо unverified (1 scored ENradio+6controls). Остальные16 уже имеют честный UI unverified, но нет model guard. Owners/taskIDs не объединены, terminal statuses не переоткрыты; лишние настоящие кандидаты не считались выдуманной связью. 900tokens stress теряет5records/язык,2200/5000 полны,overflow0; вне recall denominator. Agent-authored synthetic accepted-memory audit, общий шаблон/переводы/фон ограничивают независимость; не blind external/live proof. Старый RP28654/54 —seen другого корпуса, напрямую с58/62 не сравнивать.

**Следующее действие:** диагностировать/исправить short-reference fallback в `game-context.ts`: если ни literal, ни obligation group не сработали,line79 возвращает prior coverage/guard. Распознанная, но недоказанная ссылка должна сохранять unverified+guard. Затем расследовать4 source-group losses:RUEN garden a1,ENradio a1/a2/a3,ENregatta a1. Exact accepted bridge при похожих debts должен добирать whole records без назначения общего object ID. Причина каждого пропуска ещё не доказана. **Не менять frozen fixture/gold/protocol/first report/seal RP287**; будущий fix —отдельный seen report на108 inputs+прежние RP283 controls,затем новый independent набор. RP-05/general semantics/true delta открыты. RP274–287 локально поверх7005aa6,push не запрошен; runtime/UI/storage/settings/model/личный мир/installed copy не менялись.

RP287:focused278/278(111новых checks),TypeScript/diff-check0;новый audit108inputs/62scored58complete сохранён. Все414 frozen fingerprints,включая410 runtime,прежние;старые reports/gold/seals проверены. Chrome/Firefox build+ZIP0,старый >500KB warning. Full unit/native/UI/live DeepSeek/full E2E заново не запускались:runtime/UI неизменны. Installed copy не обновлялась. 23/23 runtime и730 source entries проверены byte/CRC;3 canonical download copies SHA256 match,финальные notes повторно упакованы. Source ZIP исключает tests;для QA нужен Git checkout/Node22.

## Текущая точка RP286 — перефразировки возвратов и короткие ссылки

Новый `story-obligation-recall.ts` дополняет contextual wrapper в game-context ПОСЛЕ старого literal matcher. Full-sentence promise-to-return title получает literal prefix2–6 terms, повторённый в≥2 OTHER accepted texts; task.text Иquote тоже обязаны содержать label. Query-local caches, global tokenizer/index/canon/draft/settings/model не меняются. Information return/debt/nonfulfillment inquiries передают все возможные return groups (≤16tasks/4labels/128rows). Short references/promise verb/arrangement/debt требуют единственный точный accepted latest-turn quote bridge; topic и label допустимы в разных частях этой же цитаты, остаток raw scene может только veto. Names/mixed actions/conditions/unknown clauses/source/roles/budget guards; closed statuses и independent IDs сохранены. New result всегда unverified/query +unresolved guard, previous selection целиком сохранена. Query help RU/EN исправлен: available records prepared, completeness unverified. [Мануал](docs/OBLIGATION-RECALL.md).

Separate seen [RP286d report](docs/benchmarks/rp286d-obligation-seen-results.json):54/54 vs47/54,312/312gold,0missing/integrity/control drift/prior loss. Только12 paraphrase/reference outputs/coverage меняются;72others/24rejections/6budget прежние. Все12 conservative unverified/query; прежний EN false-complete исчез на этом наборе. First independent39/54 иseen44/54/47/54/seals/gold/input прежние. Ранние RP286/b/c reports сохранены, результаты те же; c добавляет request-local token cache, d честный RU/EN help без payload changes. Это seen, не independent/live proof.

Финальный full unit7357pass/0fail/5 прежних TODO из7362,78 новых checks pass;focused384/384. TypeScript/diff-check0. Native isolated Edge RUEN12/12pass/0fail/0flaky за190.28s:новые obligation2+прежние contextual2/paragraph2/recap2+UI4(RUEN320/900,5states,keyboard/axe/no overflow). Новые2:26 exact sources/task/roles/revision IDs/conditions,503/retry/fetch/XHR/reload/raw draft/canon unchanged и28 scopedPOST. Дополнительные4 unit cases за5000 scenes прошли.406/411 fingerprints прежние,5 expected edits+3 added modules;72 other outputs/coverage unchanged,old reports/seals/gold прежние. Chrome/Firefox build+ZIP0;старый >500KB warning,live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](docs/benchmarks/rp286-qa-results.json)

23/23 runtime и724 source entries проверены byte/CRC,3 canonical download copies SHA256 match;финальные notes повторно упакованы. Source ZIP исключает tests,для QA нужен Git checkout/Node22.

**Следующее:** новый заранее frozen независимый long-history audit с несколькими возвратами/владельцами, завершёнными долгами и ложными/неизвестными ссылками. Не ограничиваться прежними3 сюжетами и не выдавать54/54 seen за новую оценку. Общий semantic search/любые типы обещаний/все местоимения/true cross-turn delta/RP-05 остаются открыты. RP274–286 локально поверх7005aa6, push не запрошен; личный мир/аккаунт/installed copy не менялись.

## Текущая точка RP285 — короткие множественные формы предметов

Исправлен подтверждённый пропуск `c1`: global tokenizer даёт сани→сани/саней→сан. Новый `story-object-forms.ts` добавляет только явные plural case пары к action-balance/compound-action; narrative использует тот же matcher, оба multi-action parser отклоняют duplicate objects с разными падежами. Shared text/index неизменны. Full qualified object adjacent in one clause/field; masked names барьер, quote/key/value/status не evidence. Роли/ID/canon/draft/settings/model не меняются. Source/scope/budget rollback прежний. Общая морфология/беглые гласные/adjective instrumental/синонимы не заявлены. [Мануал](docs/OBJECT-FORMS.md).

Separate seen [report](docs/benchmarks/rp285b-forms-seen-results.json):47/54 vs44/54,297/312gold,15missing vs18,narrative6/6 vs5/6,0 integrity/prior loss. Ровно4 output changes =3 scored RU mountain c1 +ru budget1800, где whole1631/1800. Остальные80 outputs/coverage и24 rejection controls прежние. Legacy controlsDrift1 сохранён (budget counted unscored); rejectionControlsDrift0/budgetOutputChanges1 явно разделены без relabel gold. Первый rp285 report также сохранён. Исторические RP28339/54/RP28444/54/seals/input/gold прежние. Новый paragraph semantic status unverified/query, одна EN short-reference semantic false-complete остаётся. Это seen, не independent/live proof.

Финальный full unit7279pass/0fail/5 прежних todo из7284,53 новых checks pass; focused547/547 и report2/2. TypeScript/diff-check0. Native isolated Edge RU/EN8/8pass/0fail/0flaky за159.48s:новые forms2+paragraph2+natural2+recap2; новые2 проверяют12 whole quotes/task/claim/roles/revision IDs,503/retry/fetch/XHR/reload/unchanged canon и38 scopedPOST.407/411 original fingerprints прежние,4 ожидаемых edits+2 added runtime modules;80 прочих outputs/coverage unchanged,old reports/seals/gold сохранены. Chrome/Firefox build+ZIP0,старый >500KB warning остаётся;live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](docs/benchmarks/rp285-qa-results.json)

23/23 runtime и716 source entries проверены byte/CRC,3 canonical download copies SHA256 match;финальные notes повторно упакованы. Исходники ZIP исключают tests:для QA нужен Git checkout/Node22.

**Следующее:** свободные paraphrase/короткие EN references и оставшийся EN semantic false-complete. После исправлений нужен новый независимый набор. RP-05/true cross-turn delta открыты. RP274–285 локально поверх7005aa6, push не запрошен; личный мир/аккаунт/installed copy не менялись. Первый diagnosis сохранил результат, затем получил shell timeout20s; первая focused241pass/2test assumptions (adjective instrumental вне scope,4 c1 включая budget вместо3), typecheck выявил JSON union `.includes` never — заменён на `.some`. Исправления алгоритма ради этих трёх ошибок не расширялись.

## Текущая точка RP284 — ограниченный разбор действий внутри абзаца

После «продолжаем» выполнен первый приоритет RP283. Новый `story-narrative-action.ts` вызывается перед прежним коротким разбором в `story-sequence-priority`; `game-context` сохраняет unverified/query для нового paragraph path вместо semantic complete.2–4 предложения/1200 chars/последний блок2–3 object actions, конечные обстановка/перемещение/наречия/location/companion. Каждый span проверяется; условия/отрицания/цитаты/неизвестные части отклоняют весь новый path. Одно «не торопясь» допускается как наречие. Имена маскируются до delimiters, names Iterable материализуется один раз; companion spelling не создаёт ID/alias/owner. При неподтверждённом source/budget/capacity точный prior. Старые single-sentence480/per-clause240/object6 guards сохранены. Original draft и canonical state/settings/model неизменны. [Мануал](docs/NARRATIVE-ACTIONS.md).

[Отдельный seen report](docs/benchmarks/rp284-narrative-seen-results.json) на прежних84 inputs/gold:44/54 complete вместо39/54,294/312 facts,missing18 вместо47; narrative5/6 вместо0/6. Integrity/control drift/lost prior0; новые абзацы6/6 unverified/query. Остался RU mountain c1, парафразы/EN refs и3 старых false-complete cases. Первый independent RP28339/54/report/seal/fixture/protocol не изменены. Из411 старых fingerprints изменены только game-context/sequence-priority,409 остальных прежние; добавлен1 runtime module. Это seen improvement, не новый independent результат.

First102 unitpass; расширенный461 дал459pass/2fail: неизвестный somebody else добавлен к guard, historical RP272 digest сравнивал изменяемый src. Сохранён точный HEAD алгоритм в `docs/benchmarks/rp272-final-sequence.txt` с прежним registered LF hash08d93b83…; регистрация/gold/reports не переписаны, current tests продолжают компилировать runtime. Промежуточный повтор460pass/1ENOENT из-за ещё не созданного snapshot; snapshot подготовлен, финальные461/461pass. [Методика historical QA](docs/HISTORICAL-SEARCH-QA.md).

Финальный full unit7226pass/0fail/5 прежних todo из7231,56 новых checks pass;focused461/461pass. TypeScript/diff-check0. Native isolated Edge RU/EN6/6pass/0fail/0flaky за114.69s:новые paragraph2+прежние natural2+recap2;новые2 проверяют12 whole source quotes/roles/revision IDs,503/retry/reload/unchanged canon и38 scopedPOST. Из411 historical fingerprints409 прежние,2 ожидаемых edits+1 added module;все78 non-paragraph outputs/coverage unchanged,старые reports/seals/registration/gold сохранены. Chrome/Firefox build+ZIP0. 23/23 runtime и710 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Старый >500KB warning остаётся;live model/Firefox native/full E2E не проверены,installed copy не обновлялась. [QA report](docs/benchmarks/rp284-qa-results.json)

**Следующее:** закрыть RU c1/полноту групп при формах слов, затем paraphrase и короткие EN references; уточнить3 старых complete относительно semantic gold. Новый paragraph улучшен в описанных границах, RP-05/true cross-turn delta открыты. Нынешние84 cases seen: новые fixes требуют отдельного report, first39/54 и seen44/54 не заменять; затем следующий независимый набор. RP274–284 локально поверх7005aa6, push не запрошен. Личный мир/installed copy не менялись.

## Текущая точка RP283 — новая проверка после RP281, найдены15 потерь

Пользователь запросил новый независимый long-history audit. Новый corpus без импорта прежних историй/gold: музей/горный приют/общественная кухня, RU/EN,72 основных +6scale250/1000/5000 +6budget800/1800/4000 =84.54 scored cases:39 complete,265/312 gold records,47 missing в15 cases;24 rejection controls и6 budget probes отдельно. Runtime/UI/storage/model/settings не менялись. [Результат/примеры](docs/INDEPENDENT-SEQUENCE-RESULTS.md), [первый report](docs/benchmarks/rp283-independent-results.json), [seal](docs/benchmarks/rp283-first-report-seal.json), [frozen protocol](docs/INDEPENDENT-SEQUENCE-EVALUATION.md). Это agent-authored synthetic accepted-memory audit, не blind external/live model evaluation; repeats/translations/общая структура ограничивают независимость. Старые RP28054/60 и RP281seen60/60 сохранены, проценты не сравнивать напрямую.

По группам:two6/6,plain-three5/6,narrative0/6,paraphrase1/6,reference4/6,time6/6,named6/6,independent duties6/6,scale5/6.0 evidence/role/source/status/budget/immutability/cold-warm issues во84. Но **3 scored failures получили coverage complete**:ru mountain triple/scale1000 иen mountain reference. Это отдельная проблема полноты/уверенности, не доказанный semantic coverage. Narrative8 selected/~1238–1384 из16000 tokens,unverified/query; большой бюджет не устраняет grammar gap. RU mountain `c1` теряется дважды, причина пока не доказана. Переданные условия точны, нужные условия иногда отсутствуют.

До compiler evaluation preflight выявил invalid kind event у open b-old task во84. Первый baseline/точные fixture+runner copies ссуффиксом-preflight/протокол INDEPENDENT-SEQUENCE-PREFLIGHT сохранены; архивный runner не запускать. Исправлен только kind task и derived binding key; whole84 input equality после поправки и неизменный goldDigest проверяются unit. Current manifest `tests/fixtures/story-independent-sequences-v2-baseline.json`,411 normalized fingerprints; input403a32eb…/gold2e73908b…. First preflight1pass/84fail; повтор85pass/1 comparison fail из-за derivedkey, test исправлен; итог fixture86/86pass. Старый manifest не перезаписан, никакой оценки поиска на невалидном вводе не было.

Финальный full unit7170pass/0fail/5 прежних todo из7175,89 новых checks pass; fixture/source/gold/seal/report checks сохраняют результат39/54. Первый общий прогон неполный:695pass/1timeout и276 suites с ENOENT временного transform-cache; он сохранён в docs/benchmarks/rp283-unit-first-environment.json. Повтор выполнен с отдельными TEMP/TMP,1 worker,после сборок,без изменения thresholds/runtime. TypeScript/diff-check0;411 RP283 fingerprints/first report/input/gold/seal неизменны, прежние RP280/281 seals также прошли. Chrome/Firefox build+ZIP0. 23/23 runtime и704 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Старый >500KB warning остаётся. Production/UI не менялись; native/browser/live model/full E2E не повторялись. Tests исключены из source ZIP, для воспроизведения нужен Git checkout/Node22. Installed copy не обновлялась

**Следующее:** безопасно разобрать natural actions внутри абзаца и собрать целые независимые источники; затем paraphrase/короткие EN reference и потерю c1, уточнить смысл coverage complete.15 losses теперь seen; новый фикс — отдельный regression runner/report, frozen fixture/gold/first report/seal не менять ради зелёного. RP-05 и true cross-turn delta открыты. RP274–283 локально поверх7005aa6, push не запрошен. Личный мир/аккаунт/installed copy не менялись.

## Текущая точка RP282 — исторические тесты отделены от нынешнего поиска

Пользователь попросил исправить8 старых unit failures. Три historical файла теперь используют явный полностью перечисленный профиль RP268: поздние lanes выключены, сохранены5→16 и все полные workload/gold/provenance digests. Это профиль воспроизведения конкретных замеров на текущем коде, НЕ эмуляция старого бинарника. Выбор вычисляется из оригинальных текстов/ролей/источников; saved baseline/candidate/gold не используются для выбора. Старые отчёты, протоколы, gold и ограничения кандидатов не менялись. В зарегистрированном `story-search-diverse.ts` восстановлены CRLF согласно уже существующему .gitattributes; код прежний. [Методика](docs/HISTORICAL-SEARCH-QA.md).

Добавлен отдельный current-runtime contract на224 исходных сценария (128 evidence +96 grounding): нынешние defaults +columns, whole source/quote/task/claim/unique/budget/immutability и cold/warm output+coverage equality. Дополнительно нынешние16 lasting positives/32 controls и independence от gold labels. Индивидуальные текущие lasting/source/budget проверки остаются. Нынешний подбор не обрезан до8; production/storage/UI/model/settings этого этапа не менялись. Начальные291 historical и493 focused pass; затем current corpus расширен с104 до128 evidence cases, поэтому финальный полный прогон должен включать226 новых checks. Первый typecheck выявил недопустимое тестовое split:'changed', заменено переключением между настоящими split labels. Зелёные runtime тесты не подтверждают новое independent качество.

Полный unit на финальных исходниках:7081pass/0fail/5todo из7086,226 новых checks pass. Все8 прежних failures устранены; TODO прежние. [Итоговый QA report](docs/benchmarks/rp282-qa-results.json) фиксирует hashes5 QA files и11 неизменных historical files; все полные historical digests прошли. TypeScript/diff-check0.411 frozen long-history fingerprints:только2 ожидаемых RP281 parser edits,409 остальных/first report/baseline неизменны. Chrome/Firefox build+ZIP0,23/23 runtime bytes/CRC match. 695 source entries byte/CRC match,3 canonical download copies SHA256 match; финальные notes повторно упакованы. Старый >500KB warning остаётся. Production/UI этого этапа не менялись, поэтому native RU/EN/live model/full E2E не повторялись; прежний native результат RP281 не выдавать за новый прогон. Нужен Node22; source ZIP исключает tests, для QA нужен Git checkout.

**Дальше:** новый заранее закреплённый independent набор длинных natural sequences после RP281. Не переименовывать RP280/281 seen данные в новый holdout. RP-05 и true cross-turn delta остаются открыты; предыдущая самостоятельная упаковка даёт около1.3%, не полноценную дельту. RP274–282 локально поверх7005aa6; push не запрошен. Личный мир/аккаунт/installed copy не менялись.

## Текущая точка RP281 — исправление естественных составных действий

После «ок» исправлены два runtime файла: `story-action-balance` добавляет конечные RU/EN examine/untie/connect/disconnect/move формы; `story-compound-action` разрешает comma / comma+conjunction только в действиях. Goal grammar прежняя,2–3 части/480 total/240 per clause/6 object words прежние. Имена маскируются ДО split, пустые/неизвестные/conditional/negated/quoted/personal/third-person clauses не отбрасываются; любая ошибка отклоняет весь разбор. Semicolon/newline/multi-sentence/4+ parts/repeated object остаются fallback. Все источники и whole budget проверяются прежними слоями; storage/model/settings/UI не меняются.

Сначала45 новых checks дали32pass/13fail (6 RP280 losses+7 parser forms), затем focused156pass/2fail: старый comma-negative теперь намеренно поддержан и перенесён в positive без удаления самого случая; новый And Then fixture сначала не содержал этого имени, текст уточнён до настоящего совпадения. Повтор158/158pass. Добавлены12 evidence/identity/rename checks; итог новых57/57pass, в том числе в full suite. Тесты не ослабляют source/condition guards.

Новый `scripts/story-search-natural-seen.mjs` принимает только2 ожидаемых parser changes относительно historical411 fingerprint manifest, остальные fixture/protocol/runner/input/gold/first RP280 report/seal неизменны. [Отдельный seen report](docs/benchmarks/rp281-natural-seen-results.json):78 cases,60/60 complete вместо54/60,missing0,integrity0,control drift0,prior selected loss0. Это не новый holdout. Старый runner/report/baseline/gold не переписаны. [Мануал](docs/COMPOUND-ACTIONS.md) и верх DISCUSSION-PRIORITY обновлены, включая устаревшее утверждение о жёстком cap8. Новый baseline независимой оценки после фикса ещё не создан; RP-05/true delta остаются открыты.

Полный unit завершён:6847pass/8fail/5todo из6860. Новые57 checks pass.8 failures в3 старых файлах: `story-lasting-recall-quality` (stale before=5), `story-search-evidence` (5 dynamic baseline/cap mismatches +incomplete lexical ranking), `story-search-grounding` (historical fingerprint). Проверены точные old parser bodies изHEAD7005aa6 против RP280 fingerprints; временный Vite alias подменял ТОЛЬКО2 парсера, working src не перезаписывались. На3 historical files тот же набор8 падающих tests;7 first messages exact, lasting before уже8 со старым parser и9 с новым, ожидание5 устарело до фикса. На new57 old parsers дают15 ожидаемых failures, что подтверждает действительность alias. [Сравнение](docs/benchmarks/rp281-legacy-comparison.json). Полный прогон НЕ зелёный; gold/старые отчёты/thresholds не переписаны.

Native isolated Edge RU/EN10/10pass/0fail/0flaky:6 прежних budget/contextual/continuation-recap за108.79s +4 natural/sequence за107.28s. Новые2 natural проверяют12 целых sources/3 objects,comma+new verbs,503→ручной retry,fetch/XHR/reload,unsafe fallback и unchanged facts/roleSeeds/episodeSources,38 scoped POST. ПервыеCLI filters обнаружили6 вместо10 из-за ограниченного testMatch; новые natural и прежние sequence зарегистрированы в isolated config и отдельно4/4 выполнены. Никаких claims о не запущенных вариантах. TypeScript/diff-check0; final411 fingerprint audit допускает только2 parser edits,409 остальных/first report/baseline unchanged. Chrome/Firefox build+ZIP0,23/23 runtime/693 source entries byte/CRC и3 SHA256 copies сверены, итоговые notes повторно упакованы. Tests/private-assets/model binaries/secrets/.env/Git/nested ZIP исключены; старый >500KB warning остаётся. Firefox native/live model не проверялись, личный мир/installed copy не менялись.

**Следующее:** починить привязку исторических измерений к их frozen compiler/provenance в этих3 файлах, отделив проверку нынешнего runtime; не подменять5 на9/не обрезать нынешний подбор до8/не переписывать gold ради зелёного. Затем новая independent оценка natural sequences после фикса. RP-05 и true cross-turn delta остаются открыты. RP274–281 локально поверх проверенного7005aa6, push не запрошен. Исправление natural sequence завершено в описанных границах; полный unit suite остаётся красным из-за8 воспроизведённых historical failures.

## Текущая точка RP280 — пункт4 проверен, найден пробел составных действий

Выполнен четвёртый отдельный prompt: новый synthetic accepted-memory corpus, без изменения runtime RP279. [Протокол](docs/LONG-HISTORY-EVALUATION.md) frozen до первого compile; [результат](docs/LONG-HISTORY-RESULTS.md), [первый отчёт](docs/benchmarks/rp280-long-results.json).78 cases:72 основных (3 новых сюжета ×2 языка ×12 форм) +6 scale250/1000/5000. Из54 основных gold cases полные48; scale6/6, всего54/60,330/348 gold facts.18 controls не включены в completeness. Во всех78 exact evidence/roles/task/claim/revision IDs/budget/input immutability/cold-warm equality без нарушений. Это agent-authored synthetic audit, не blind/human/live model proof; common anchor/short query templates и procedural noise ограничивают выводы.

Все6 потерь — three-actions: parser sequence0, unverified/query,8 из11 gold records при1324–1405/16000 tokens. Запятые отвергаются compound parser, часть естественных RU/EN verbs не поддерживается (EN examine тоже). [Seen diagnostic variants](docs/benchmarks/rp280c-long-diagnostics.json); ранние diagnostics сохранены отдельно, не переименовывать в independent gain. **RP-05 открыт:** следующий шаг — безопасный разбор естественных составных действий с сохранением условий/цитат/отрицаний/имён/source guards/prior whole sources и бюджета.6 пропусков станут seen regressions; исходные input/gold/first reports/runtime baseline не менять. После изменения runtime нужен отдельный seen runner/report, не перезаписывать baseline ради зелёного теста. Новая независимая проверка потребует нового заранее закреплённого набора. Ограничение пункта3 (true cross-turn delta) остаётся открытым.

Freeze manifest `tests/fixtures/story-long-holdout-baseline.json`:411 fingerprints (runtime +fixture/runner/protocol), normalized CRLF→LF; input4631b6d6…/goldc4625ff0…. `--freeze` не вызывает compiler; files/report write wx. Первый unit не стартовал из-за Vite http import.meta URL в jsdom; test-only path исправлен без изменения frozen fixture/gold/runtime. Постоянный fixture test проверяет неизменность corpus/protocol/runner и исторического manifest; src fingerprints проверяются runner перед оценкой и отдельно финальным audit, не блокируют будущие изменения runtime в обычной unit suite.

Финально15 selected files/1138 unit pass/0fail (80 новых fixture/report checks); TypeScript/diff-check0. Все411 frozen fingerprints/исходный report/baseline повторно совпали после QA. Последняя seen-диагностика: original6/6 parser0/missing3, conjunctions-only не решает, conjunctions+known verbs6/6 parser3/all11/1583–1628 tokens. Первый independent результат54/60 НЕ исправлен и не заменён итогом diagnostics. Chrome/Firefox build+ZIP0,23/23 runtime и690 source entries byte/CRC сверены с диском,3 canonical copies SHA256 match; итоговые notes повторно упакованы. Tests/личные данные/model binaries/.env/secrets/Git/nested ZIP исключены из source; для повтора нужен Git checkout. Старый >500KB warning остаётся. Head7005aa6 проверен, RP274–280 локально, новый push не запрошен. Личный лор/installed copy не менялись; UI/runtime не менялись, native/live/full suite checks в этом этапе не повторялись. **Пункт4 audit завершён; следующий prompt — исправление составного разбора, RP-05 не закрыт.**

## Текущая точка RP279 — безопасная часть пункта3, межходовая дельта открыта

Пользователь разрешил третий пункт. Проверен текущий код контракта: native prompt+parent ID/history/dispatch receipt НЕ подтверждают фактический input window модели. Поэтому **не реализован режим удаления unchanged memory на основании предыдущей отправки**. Он остаётся открытым ограничением, не объявлять пункт3 полностью решённым. Вместо него реализована безопасная дополнительная экономия повторяющихся полей в каждом self-contained запросе. Это объяснено пользователю во время работы. Следующий его «продолжай» — согласованный пункт4, независимые длинные истории; не повторять RP278 и не включать межходовые ссылки без контракта провайдера. [Примеры/границы](docs/SELF-CONTAINED-MEMORY.md).

`story-memory-transport` читает строгий columns-v1 envelope с kind/text первыми, уникальными allowed columns,2..N cells/row,null/omitted tail=absent, максимум128 records; после expansion применяются прежние backward-only refs и полная field/status/source validation. Генератор дополнительно оборачивает каждый старый обратимый вариант, сортирует optional columns по частоте и убирает trailing null. `formatStoryFacts` принимает таблицу только если весь guide/full prompt меньше и по chars, и по token estimate, чем уже лучший прежний вариант. В content включён memoryTransport columns, default core compact/historical fixtures прежние. Подбор/диагностика считают весь новый prompt; допустимо больше целых записей в бюджете. Canon/schema/settings/receipt/continuation/injection logic не менялись, cross-request dictionaries/state не создаются.

128 seen cases при20000 budget:strict decoded data128/128 equal;102 column/26 old, full chars839113→827945 иestimated tokens210331→207539 (~1.3%). First dense report4/128/252 chars gain сохранён отдельно. Sparse comparison сначала остановлен JSON digest property-order difference; helper теперь isDeepStrictEqual, data/gold не переписаны. Первый RU unit ошибочно требовал таблицу на любом mixed наборе, вопреки fallback по полному meter; проверка уточнена до never-larger + отдельного homogeneous RU/EN beneficial fixture. Native test TDZ shadow `f` исправлен; production guard не ослаблялся. Первые243/793 unitpass; финально796 selected unit pass/0fail, TypeScript/diff-check0.

Native isolated Edge RU/EN16/16pass/0fail/0flaky за173.33s:10 full continuation-chain,2 saved-recap,2 whole-budget и2 strengthened contextual scenarios. Новые2 проверяют реальные outgoing column requests,25 полных связанных записей с точными цитатами/ролями/source IDs,503→ручной retry,fetch/XHR/reload и unchanged37 stored facts/role seeds/episode sources;26 scoped POST. Chrome/Firefox build+ZIP0;23/23 runtime и682 source entries byte/CRC сверены с диском,3 canonical copies SHA256 match; итоговые notes включены повторной упаковкой. Старый >500KB warning остаётся. UI не менялся, Firefox native/full suite/live model interpretation и реальное окно DeepSeek не проверены. Личный лор/аккаунт/installed copy не затрагивались. RP274–279 локально поверх проверенного7005aa6, push не запрошен. Следующий prompt — пункт4; пункт3 delta limitation остаётся открытым.

## Текущая точка RP278 — пункт 2 из 4: инкрементальный индекс

По следующему «продолжай» выполнен второй пункт. Не переходить к пунктам3–4 в этом запросе. Следующий prompt означает **пункт3: сократить повторную передачу неизменной памяти между ходами**; затем отдельный prompt на независимые длинные истории. RP277/276 не повторять. [Метод, примеры и границы](docs/INCREMENTAL-SEARCH.md).

Причина повторной работы: старые WeakMap зависели от идентичности объектов; новые storage clones и чистые ranked copies теряли подготовку. Новый `GameSearchIndex` живёт в content controller; pure lore/fact owners reconcile весь текущий набор, сохраняют exact lexical projections между клонами, удаляют отсутствующие и clear на world/game/branch/vault boundaries. `inheritStoryFactSearchEntry` переносит только поисковую проекцию на свежую ranked copy; metadata остаётся независимой. Content/concept token caches используют проекцию + полную подпись исключаемых имён. Workspace title grouping имеет weak owner token, точную проверку membership/source и только текущий scope; clear меняет token, освобождая private snapshots. Никаких ID-global strong caches, selection/score/source-role/status caches, DB/schema/settings/model changes.

Текущие scopes/activation/books/exclusions/manual/roles/evidence/replacements/current states/frequency/full budget пересчитываются при каждом запросе. Это O(N) сверка состава с повторной подготовкой изменённых текстов, не O(1) алгоритм поиска и не сокращение model-wire памяти. Индекс неперсистентен, после page reload cold build; names-sensitive разбор пересчитывается при изменённой подписи имён. Lexical-проекция не объединяет одинаковые факты разных владельцев.

Финально762 selected unit pass/0fail, включая138 новых проверок. Полные cold/warm outputs и diagnostic channel сравниваются на128 прежних RP273/RP277 cases и изменениях данных. Instrumented tests проверяют фактические0 deriveKeywords после cloned compile,1 после single-fact edit;0 tokenization для1000 lore clones и1 для одного content edit; unchanged title-group inference0. TypeScript/diff-check0; frozen RP277 baselineUnchanged64. Начальные88/94/402 и focused98 тоже pass; gold/protocols/reports не переписаны.

Native isolated Edge RU/EN6/6pass/0fail/0flaky:2 новых edit/disable/manual include/delete/restore/world switch/reload сценария и4 прежних whole-budget/notice/contextual-memory.66 actual scoped POST, current quotes/roles/source IDs/whole facts/canon unchanged в прежних сценариях; старые значения/foreign-world entry не попадают в новые запросы после правки и смены области. Unit моделирует замену набора после import/reset/undo; полный backup import/world-reset workflow в этой итерации не запускался. UI не менялся, Firefox только сборка, live account/model/full suites не проверены.

Chrome/Firefox build+ZIP0,23/23 runtime и678 source entries byte/CRC совпадают с диском,3 canonical download copies SHA256 match; итоговые notes повторно упакованы. Source исключает tests/private-assets/model binaries/secrets/.env/Git/nested ZIP; существующий >500KB warning остаётся. Личный мир/installed copy не менялись. Head проверен7005aa6, RP274–278 локально, новый push не запрошен. **Пункт2 завершён; остановиться до prompt на пункт3.**

## Текущая точка RP277 — первый из четырёх шагов RP-05

Пользователь разделил завершение RP-05 на четыре запроса. Этот запрос разрешает **только пункт 1: свободные формулировки/«её подарок»/«то обещание»**. Следующий «продолжай» означает пункт 2 — обновление индекса только для изменившихся данных. Затем отдельные prompts для пунктов 3 (повторная передача памяти) и 4 (независимые длинные истории). Не продолжать пункты 2–4 заранее; не возвращаться к уже проверенному RP276.

Добавлен `story-contextual-reference.ts`: ограниченные RU/EN information-reference формы, source-backed lexical bridge через точную цитату последней selected source. Буквальный task title или явное gift copula в accepted text И quote дают label; подарок без задачи и однословное название тоже поддержаны. Вся последняя сцена проверяется на второй/неизвестный topic. Все текущие matching records + ВСЯ prior selection атомарно проходят full render/budget/128 rows. Недоказанный источник/другая игровая линия/удалённый или заменённый исторический ID/неподдержанный запрос → exact RP276 fallback; rename ID сохраняется. Guard остаётся на wire, местоимения/ownership/object identity не устанавливаются, независимые задачи/условия/terminal status не объединяются. Никаких записей канона, новых моделей, hidden calls, dependencies, UI/settings/schema. [Примеры и ограничения](docs/CONTEXTUAL-MEMORY.md).

До алгоритма frozen64 RU/EN input/gold/RP276 output baselines,204 later scenes. Честный результат: baseline уже16/16 complete, новый16/16,48 controls exact, prior source loss0; это compatibility, не прирост/не универсальный semantic search. Отдельные stress regressions15-record whole sets дают улучшение против cap8, но это seen tests, не новый independent holdout. Первые и последующие benchmark reports сохраняются отдельно; frozen старые datasets/protocols не менять. Начальные unit90pass/3fail воспроизвели отсутствие gift-without-task и две русские формы; исправлены, следующий selected494pass/0fail. Отдельный one-word test сначала упал, исправление проверяется повторно. В test setup после удаления task пересозданы соответствующие role seeds, не ослаблен production source guard.

Финально:580 selected unit pass/0fail, включая96 новых contextual tests и прежние frozen RP273 outputs/coverage/source/owner/budget/continuation controls. TypeScript/diff-check0; frozen64 baseline/input/gold неизменны, final `rp277c-final-contextual-results.json` содержит текущие algorithm/compiler hashes:16/16 против16/16,48 controls exact, source loss0. Ранние reports сохранены отдельно. После one-word расширения native Edge4/4pass за75.94s (2 new RU/EN no-task gift POST/reload и2 existing budget/notice cases); после последнего усиления object-ID guard на wire новые2/2 повторены на финальной Chrome сборке за44.4s,18 actual scoped POST. Полные13 related records/quotes/roles/sourceIDs и unchanged canon/reload/no extra pages проверены. UI этого этапа не менялся.

Chrome/Firefox build+ZIP0,23/23 runtime и676 source files сверены byte/CRC с диском,3 canonical downloads copies SHA256 match; итоговые notes повторно включены в source ZIP. Старый >500KB warning остаётся. Source исключает tests/private-assets/model binaries/secrets/.env/Git/nested ZIP. Личный аккаунт/мир/installed copy не использованы, full suites/live model quality не заявлены. RP274–277 локально поверх7005aa6; новый push не запрошен. **Пункт1 завершён в описанной ограниченной области; остановиться до следующего prompt для пункта2.**

## Текущая точка RP276 — полная цепочка переноса и локальное завершение после сбоя

По прямому запросу пользователя проверена цепочка button→memory-analysis→review/no changes→summary→fresh home→first accepted POST→local activation на синтетическом мире. Новый `tests/e2e/continuation-chain-runtime.spec.ts` управляет ответами, но использует установленную Edge MV3/content/background/HTTP bridge/IndexedDB. RU360px/EN1280px: явное принятие предложения, отсутствие изменений, reload review без повторного analysis, недоступная home503, отказ записи applied snapshot, отказ записи session receipt, сохранность canon/scene, hidden recap (DOM получает настоящий wire prompt), без reasoning в запросе.10/10 новых native cases прошли за39.4s на текущей сборке.

Найдены и исправлены реальные проблемы: post-HTTP library failure раньше молча терялся; обычный promoteDraft мог обогнать handoff transaction; обычное ok:false без strict setting позволяло fallback send. Теперь background перед локальной транзакцией сохраняет target receipt (ID snapshot/token/target, без лора), при сбое плашка с локальным retry. Receipt восстанавливается после reload той же вкладки; при session-storage отказе остаётся page-local fallback. Pending snapshot не обходит обычный promoteDraft. До commit новая отправка приостановлена в REQUEST_CONTEXT и fetch/async+sync XHR bridge отдельно от user strict-memory preference; retry не вызывает модель. Scope/token/target/shared revision guards сохранены. [Границы](docs/SAFE-CHAT-CONTINUATION.md).

Проверка до правок:6 старых reviewed-continuation native pass/6 Firefoxskip; новый EN run3pass/1fail показал молчаливый write failure. Промежуточная матрица остановлена после2 RU harness timeouts: narrow compact meter не раскрыт тестом, trace подтвердил ожидание скрытой кнопки, теперь тест открывает виджет штатной кнопкой без увеличения таймаута. После отмены удалён только установленный по PID80596 собственный Vite4175; пользовательский4173 не трогали. Следующий run22pass/2fail/8skip выявил advisory bypass, затем30pass/4fail/18skip выявил promotion/page-fallback races. Все assertions усилены, не ослаблены. Финальный10-case repeat с реальным wire DOM echo и ownership-before-retry assertions прошёл.

Финальный targeted browser run34pass/18 штатных Edge-only Firefoxskip/0fail/0flaky за98.37s. `playwright.continuation.config.ts` выделяет52 checks, включая established6 safeguards и16 UI Edge/Firefox RU/EN320/900/360/1280; не добавляет весь runtime-sync в обычный UX набор. Scoped axe/keyboard/no focus theft/locked hiding и screenshot RU320 проверены.11 selected files245unitpass/0fail, TypeScript/diff-check0; exact receipt scope, durable retry и session clear failure after committed library покрыты. После последней оптимизации неизменного dataset и разделения sync-XHR pending/strict сообщения native10 повторён на свежей Chrome-сборке:10pass/0fail/0flaky за50.2s, additional failed-local-retry/fetch/async+syncXHR assertions.28 actual scoped POST в этом повторе; local retry не добавляет model calls.

Chrome/Firefox build+ZIP0,23/23 runtime и669 source files byte/CRC audit,3 canonical downloads copies SHA256 match. Итоговые notes повторно внесены в source ZIP и проверены; tests/private-assets/веса/секреты/.env/Git/nested ZIP исключены. Прежний >500KB warning остаётся. Installed copy не обновлялась; собственных Edge процессов с playwright profile после завершения не осталось. RP276 завершён в своей synthetic области, не весь endless RP.

Личный аккаунт, реальная модель, весь unit/browser suite и закрытие/restart вкладки не проверены. При полностью недоступном session storage reload не гарантирует сохранение принятого адреса, но snapshot остаётся в библиотеке. Новый push не запрошен; RP274–276 локально поверх7005aa6.

**После финальной упаковки продолжать:** независимый corpus свободной речи/масштаб до новых retrieval rules, полный актуальный регресс и performance/RP-08. Текущую цепочку не начинать заново. Возможный отдельный этап — восстановление accepted-receipt после закрытия вкладки/browser restart; текущая session/page-local отметка этого не обещает. Frozen protocols/gold не менять, E5/MMR не включать; native историю DeepSeek не считать очищенной или автоматически сжатой.

## Текущая точка RP275 — сжимка без повторного хвоста переписки

По «дальше» проверен существующий safe continuation. Найден и исправлен двойной сценический reference: summary snapshot раньше дополнялась automatic recentStory fallback, а completeContinuation оставлял прежний recentStory после готовой сжимки. Теперь явный snapshot определяет reference компилятора; content не передаёт fallback при snapshot; транзакция переключения создаёт следующий сегмент со сжимкой (или explicit legacy continuation). Оригинальные story records/episode sources/facts/role seeds/задачи/ручные правки/канон остаются отдельно и не удаляются. Новый выбор памяти/модель/миграция не добавлены. [Примеры и границы](docs/SAFE-CHAT-CONTINUATION.md).

QA: две воспроизводящие проверки сначала упали на дублировании хвоста, затем прошли после правки.11 selected files/241 unit pass/0fail;4 long tests повторены после добавления unselected alternative,4pass. TypeScript/diff-check0. RU/EN synthetic selected история:>200 сообщений/ограниченный recent tail/точные factRoleSeeds и episode IDs/3 task statuses/Day12/manual claim correction, reload/idempotent retry/atomic write failure/two competing repositories. Первые long fixture failures были ошибками harness (accessor перекрывал fixture world/binding; пустой proposedContext не давал нужного injection proof); production protections не ослаблялись.

Browser финально12pass/4 Edge-only Firefox skip/0fail/0flaky за35.7s:8 UI RU/EN360/1280px Edge/Firefox +2 native saved-recap send/reject/reload/retry/ownership +2 existing native two-chat/manual-edit/reminder/resume.4 actual new scoped POST с одинаковым recap/canon и разными request receipts. Первый run10pass/2fail/4skip: новые2 native tests ошибочно требовали одинаковые request UUID при повторе; теперь требуют разные валидные UUID и побайтово одинаковую остальную сцену/канон. Production не менялся для этой поправки.

Chrome/Firefox build+ZIP0, прежний >500KB warning.23/23 runtime и668 source files byte/CRC проверены;3 canonical downloads copies SHA256 совпадают. Source включает это руководство и итоговую передачу, исключает tests/private-assets/model binaries/.env/Git/nested ZIP. После финальных notes source повторно обновлён/проверен. Текущая установленная копия сама не перезагружается. Все собственные headless browser contexts закрыты; личный профиль не использовался.

**Следующее после упаковки:** полный synthetic пользовательский цикл analysis→review→summary→fresh chat с управляемым модельным ответом, недоступное открытие и post-HTTP local receipt failure. Текущий native test начинает с сохранённой сжимки;>200-message source integrity проверена storage интеграцией. Не выдавать это за live DeepSeek full flow. Затем NEW corpus свободной речи/масштаб/full regression/performance/RP-08. Frozen protocols/gold не переписывать, E5/MMR не включать. Полный unit/browser/live account/model-summary quality не проверены. Личный лор и installed copy не изменялись; новый push не запрошен, RP274/RP275 локально поверх7005aa6.

## Текущая точка RP274 — понятный дефицит важной памяти

По «го» завершён первый приоритет из передачи RP273. Отдельный observer compileGameContext сообщает complete/budget/unverified(source/query/capacity)/required-overflow/not-applicable; возвращаемый text/selection/report/counters не расширяется и точный RP272 rollback не меняется. Для<=8 неполного набора observer делает отдельную целую бюджетную пробу без её применения. Для9+ используется исходная атомарная проверка. В compiler report не пишется новый статус; content-контроллер добавляет transient selection.memoryCoverage только в page state, включая сигнатуру обновления sidepanel при прежнем prefix.

На странице и в «Игре» виден спокойный статус только при доказанной нехватке локального бюджета или переполнении обязательной части. Без перехвата фокуса/модального окна/блокировки/дополнительного DeepSeek-запроса. Подробности объясняют unknown source/unsupported wording/complete как ПОДГОТОВКУ, не отправку/использование моделью. MemoryStatus не говорит безусловное «Память готова» при дефиците. Историческая delivery receipt не изменена и новый статус в ней не сохраняется; reload пересчитывает текущий ввод. [Примеры/границы](docs/IMPORTANT-MEMORY-STATUS.md).

Оригинальный текущий RP273 compiler побайтово сохранён в rp273-final-compiler.txt с обязательным CRLF, старый contract проверяет этот исторический snapshot. Protocol/gold/report/алгоритм приоритета не меняются.64 existing frozen RP273 outputDigest проверяются с observer, плюс новые статусы/focus/UI; это регрессия совместимости, не новое исследование точности/holdout. Первая browser матрица обнаружила8 старых selectors скрытого SupportDetails и1 ранний RPC после reload в новом native test; сценарии теперь открывают оба раскрытия клавиатурой и ждут прежний признак готового extension UI, без повышения таймаутов/ослабления проверок.

Финально15 selected files/953unitpass/0fail за77.52s, включая102 новых cases и все64 зарегистрированных RP273 outputDigest с observer. TypeScript/diff-check0; старый benchmark без флагов подтвердил baselineUnchanged64. UI32/32pass в Edge/Firefox RU/EN320/900px (5 состояний, keyboard/axe/support disclosures). Общий промежуточный исправленный run34pass/2 Edge-only Firefox skip/0fail/0flaky за99.36s; после последней правки page-state сигнатуры native отдельно повторён на новой сборке:2pass/2skip/0fail/0flaky за25.18s,28 actual scoped completion POST,12 whole sources, синхронные notice/clear в боковой панели, дефицит до отправки и после reload, прежние facts/roles/episodeSources/pages/draft. Native попытка с личным местоимением правильно дала required-overflow из-за дополнительного обязательного ambiguity guard при tiny budget; тест очищения уведомления использует нейтральное «привет/hello», production priority overflow не ослаблена, добавлены2 unit регрессии приоритета обязательной части.

Chrome/Firefox build+ZIP успешны,23/23 runtime и667 current source entries сверены побайтово/CRC;3 canonical copies downloads совпадаютSHA256. Source повторно актуализирован после этой финальной передачи, tests/private-assets/веса/.env/Git/nested ZIP исключены. >500KB warning прежний. Весь unit/full browser/live account не запускались; личный мир/установленная копия не менялись. RP274 закрыт в своей области; работа локальна поверх7005aa6, новый push не запрошен. Следующий этап — изучить и проверить существующий безопасный continuation на длинной synthetic линии (см. передачу RP273 ниже), не переписывать с нуля и не обещать сжатие native переписки. E5/MMR и arbitrary language остаются открыты.

## Передача на рабочий ПК: RP269–RP273

Пользователь попросил опубликовать всю накопленную работу RP269–RP273 в `main` репозитория `NEONARCHY/DeepRole`. Этот раздел — актуальная точка входа после pull. Строки «локально»/«push не запрошен» в исторических разделах ниже описывают момент выполнения тех итераций, а не новую задачу. База пакета — `f4a093e`; перед публикацией `origin/main` совпадал с ней. На рабочем ПК сначала проверь remote/branch и `git log`, читай этот раздел, затем [итог дня](docs/HANDOFF-2026-10-15.md), [следующее задание](docs/HOME-CODEX-NEXT.md) и верх ROADMAP. Не повторяй уже завершённые RP269–RP273 и старые задания RP-01–04 из глубины переписки.

### Что сделано в этом пакете

- **RP269:** отдельное исследование «событие против разговора». Полнота нужного набора не выросла, поэтому прототип НЕ внедрён. Сохранены96 RU/EN случаев, baseline/gold/протокол/отчёт; E5/MMR и новые model services не подключены. `.gitattributes` защищает замороженные контрольные суммы от переноса строк между ПК.
- **RP270:** рабочий приоритет содержательных исходников перед строго доказанным пустым повтором разговора. Нужны полная неизменённая цитата, привязанный говорящий и явное отсутствие новых сведений, действий и обязательств. Простое «снова обсудили» не достаточно. Вся история хранится; меняется только подбор уже принятой памяти в запрос.
- **RP271:** дополнительные конечные RU/EN формулировки таких повторов, порядок/разделители трёх отрицаний, поддержанные одиночные действия. Новые условия, коды, обещания и непроверенный пересказ не объявляются пустым шумом; независимые владельцы и объекты не склеиваются.
- **RP272:** короткие действия без «я» и поддержанные цепочки из2–3 действий, например «открываю дверь и достаю ключ». Каждой части нужны полные содержательные исходники; отрицание, условность, неизвестная часть, личное/указательное местоимение и неоднозначная личность не разбираются по догадке. Фраза игрока сама не выполняет поручение.
- **RP273:** для поддержанного запроса9+ нужных записей передаются целиком по полному бюджету добавленного контекста. Сохраняется также весь прежний non-repeat набор. Одна атомарная проверка учитывает лор/защищённые поля/protocol/guards/общие transport references; если не хватает места или proof — exact RP272 text/selection/report/counters. Decoder safety128 ограничивает один блок передачи, не библиотеку мира;8 новых предложений на ответ остаются отдельной проверкой.
- **Передача и сборки:** обновлены roadmap, дневник, объяснение с примерами, все исходные/исправленные регистрации и отчёты, tests/fixtures и три актуальных ZIP в downloads. Личные миры/профили/установленное расширение не изменялись, лишние окна тестов закрыты.

### Что проверено и чего это не доказывает

Перед публикацией дополнительно прошли25 selected files/1417unitpass/0fail (включая весь новый RP269 research и RP270–273 runtime regressions), TypeScript/diff-check. Для41 frozen indexed source/fixture/snapshot files восстановлен checkout через Git и проверена эквивалентность исходных контрольных сумм с обязательными CRLF/LF правилами. Это проверка переносимости пакета, не новая оценка качества модели и не весь unit suite. Browser tests из RP273 не запускались повторно в публикации; их точные результаты ниже. Updated handoff notes включены в source ZIP, content/copies audit повторён.

Финальный выбранный регресс RP273:23files/1279pass/0fail,196 новых случаев, отдельное усиление valid-quote budget test —196pass. TypeScript/diff-check проходят. В synthetic установленном Edge прошли8 уникальных сценариев (6 прежних и2 новых RU/EN):26 новых scoped completion POST проверили целые12 источников до/после reload и неизменность facts/roles/episodeSources. Это не ответы настоящего DeepSeek и не личный аккаунт. Ранние провалы и исправления test harness/правил не скрыты: подробности RP273 ниже.

Последний полный unit был на RP271:5871pass/1 legacy100-turn timeout/5todo; неизменённый файл отдельно24pass. После RP272–273 весь unit/browser matrix не запускался, потому нельзя заявлять, что «полный набор прошёл». Начальные и amended benchmark reports сохранены; исправленные оценки используют уже просмотренные данные, не новый независимый holdout. Runtime ограничен конечными RU/EN формами, не универсальным пониманием любых лоров/языков.

Chrome/Brave/Edge иFirefox ZIP пересобраны; runtime23/23 иsources662 entries сверены SHA256 с текущими файлами и canonical copies. Source ZIP не содержит tests/private-assets/веса/секреты/Git/nested ZIP, поэтому для повторения QA нужен полный Git checkout. В репозитории tests/fixtures/registrations есть; optional модели не нужны. Node24+, не старыйNode20. Архивы не обновляют установленную копию автоматически: заменить файлы в прежней папке, reload расширения иDeepSeek, не удалять расширение ради обновления.

### Что делать дальше — начать именно отсюда

1. **Сигнал нехватки важной памяти.** Сейчас при непоместившемся целом наборе возвращается старый подбор; его полнота не гарантируется и игрок может не знать о дефиците. Разделить «полный набор передан», «не хватает локального бюджета», «источник/запрос не подтверждён», обычные пропуски второстепенной памяти и переполнение обязательного лора. Не менять замороженный exact rollback ради UI; новый статус/причину проектировать как отдельную диагностическую передачу, не текст в игровом ответе. Показывать спокойно и только при необходимости, RU/EN и узкая панель; не заставлять игрока открывать review после каждой реплики.
2. **Безопасное продолжение в новом чате.** Сначала изучить уже существующие `src/core/story-continuation.ts`, `src/storage/story-continuation.ts`, `src/core/story-checkpoint.ts`, `src/storage/story-checkpoint.ts` и `docs/CONTINUATION-MEMORY.md`. Не переписывать с нуля и не создавать второй канон. Проверить на длинной synthetic игре перенос активной выбранной линии, source IDs/роли, текущих claims, незавершённых/закрытых задач, временных ограничений и авторских правок; перезагрузка/ретрай/две вкладки/сбой создания чата не должны терять или дублировать историю. Блок контекста DeepRole не сжимает уже отправленную переписку на сервере DeepSeek. Нельзя обещать автоматическое очищение native окна каждые10–15 сообщений; момент continuation выбирать по реальной доступной проверке/локальному бюджету, а не магическому счётчику.
3. **Свободные формулировки и масштаб.** Создать NEW размеченный корпус до новых правил: более свободные действия/реплики, неоднозначные имена/предметы, длинная игра, несколько обязательных условий и unknown sources. Все наборы RP263–273 уже seen. Не переписывать их gold или подключать прежний E5/MMR без нового доказанного выигрыша. Настоящие многосценарные live проверки только с разрешённым synthetic/пустым миром; личный лор не сбрасывать.
4. **Доведение RP-05–08.** Полная регрессия/масштабные игровые прогоны, восстановление/экспорт/импорт/два окна, серверные отказы/обрывы, производительность и прежний >500kB build warning остаются отдельными задачами. Этот пакет не закрывает весь «бесконечный ролплей». Перед каждым изменением сверяться с актуальным верхом ROADMAP и обновлять done/remaining после итерации.

### Где находится реализация

`src/core/game-context.ts`: `compileGameContext` (RP273) → `compileSequenceContext` (RP272) → `compileFlexibleContext` (RP271) → `compileDiscussionContext` (RP270) → базовый `compileGameContextPass`. Отдельные readers — `story-{discussion,flexible,sequence,budget}-priority.ts`; formatter/decoder — `story-fact-context.ts`/`story-memory-transport.ts`. Не глобально заменять все числа8: proposals/reply, резервирование legacy lanes и transport rows — разные ограничения. Для UI смотреть `context-budget-i18n.ts` и вызывающие места; для UX сначала DESIGN-SYSTEM. `budgetPriority:false` и прежние false options — внутренние сравнения, не новые настройки пользователя.

Проверка переноса: `node --version`, `npm ci` при отсутствии зависимостей, `npm run typecheck`, relevant Vitest. CLI `node scripts/story-search-budget-bound-benchmark.mjs` без флагов проверяет сохранённый baseline; `--freeze-*`/`--evaluate` не перезаписывают уже существующие files и не являются обычной командой повтора. Не удалять зарегистрированные reports ради нового запуска. Исследовательские и исторические compiler snapshots сохранять; перенос CRLF/LF проверять через `.gitattributes`, не менять алгоритм/gold ради хеша.

## Текущая точка RP273 — бюджет вместо cap8 для полного набора

RP273 завершён. Chrome/Firefox build+ZIP и3 canonical downloads обновлены, SHA25623/23 runtime и662 source entries совпадают с диском/copies. Все current core/3 registrations/reports/snapshots/docs/.gitattributes включены; tests/private-assets/секреты/веса/Git/nested ZIP исключены. Final QA notes повторно добавлены в source ZIP и сверены. Прежний >500kB chunk warning остаётся RP-08.196 new unit cases/selected1279pass + strengthened valid-quote budget regression196pass; TypeScript/diff-check0.8 unique synthetic native cases проверены с ранними failures/harness fixes подробно ниже; full unit/full browser/live account не считать проверенными. All own contexts closed, личные installed files/world/account не менялись. Git остаётся local поверх f4a093e, push не запрошен. Не повторять завершённый RP273; следующий шаг — видимый дефицит whole important bundle и безопасный continuation.

Native завершён:8 unique synthetic installed Edge scenarios passed across first6 unchanged old cases (compound/reference/sequence RU/EN) and final new2 RU/EN. Initial8-run6pass/2fail от copied assertion старого вопроса; next2fail и isolated1fail показали early wait on duplicate fact text. Trace подтвердил: additions были последней пары50/51 уже отправленного noise-batch, не новые факты/работа compiler. Harness теперь ждёт exact selected native source в episodeSources перед snapshot, DOM на reload показывает тот же selected reply; assertions не ослаблены, production/gold не менялись. Final new2/2pass30sec:26 scoped completion POSTs, whole12 records/условия/quotes/task/claim/source до/после reload, unchanged facts/roleSeeds/episodeSources/pages и0 page errors. Все own contexts finally closed даже в failed runs; личный браузер/мир/аккаунт не трогали. Архивы пересобраны/сверены выше.

Финальный unit:196 новых cases, выбранные23files1279pass/0fail, TypeScript/diff-check0. Initial independent comparison32/32 full sets против0/32,32 controls exact/no prior substantive loss,320 full-budget/source/status/atomic probes pass. Регресс выявил unbound unclassified conversation tail inflation и потом overly broad gate, блокировавший bound meaningful dialogue. Две отдельно зарегистрированные поправки до следующих comparisons: old path только для unbound unclassified talk; известные meaningful quoted conditions eligible. Все3 reports/protocols и2 algorithm snapshots сохранены;64 input/gold unchanged. Amended checks reused, не fresh holdout. Первый selected975pass/5fail и второй1274pass/5fail сохранены в ignored QA outputs;2 new auxiliary test setups исправлены (current vs superseded duplicate quote; eligible single-object old anchor), не frozen inputs/labels. Focused86pass, затем final1279pass. Bound/cap overflow и unknown guards теперь default tested; old RP270–272 provenance comparators/gold сохранены. Full unit/full browser matrix/live account не запускались. Native QA завершён, package audit завершён.

Рабочий read-only story-budget-priority/compile wrapper поверх exact RP272 подключён; QA завершён, упаковка завершена. При9+ matching substantive sources вместе со всеми prior non-repeat whole bundle проверяется ONE atomic full render (shared transport/protocol/guard/lore/профили/required context). Quote/status/условия/source lineage сохраняются отдельно/целиком; unknown/edited matching source/restart/reference-only/неразобранная часть/недостаток места → exact RP272 result/report/counters. <=8 lanes и8 новых proposals/reply неизменны. Decoder safety128 на один request не world library limit. Нет DB/schema/UI/settings/model/API/canon mutations; native chat не сжимается. [Пример/границы](docs/DISCUSSION-PRIORITY.md).

64 fresh RU/EN input/gold/RP272 baselines до интеграции:32positive/32control,9/12/16sources,2settings/dev+evaluation. Отдельный protocol до comparison. Старые core/fixtures/gold/protocols сохранены; historical cap8 comparison budgetPriority:false, default new tests отдельно. RP272 finalized compiler snapshot сохраняет прежний fingerprint. Прежние RP269–272 local changes сохранены, push не запрошен, installed personal copy не менялась. Финальные QA и3 ZIP завершены/сверены, этап закрыт.

Дальше: автоматический понятный сигнал недостатка места для whole important bundle и проверка безопасного нового continuation чата. Не считать exact fallback полным набором памяти/compact added prompt сжатием native transcript; arbitrary speech/E5/MMR/весь RP-05–08 открыты. Реальный бюджет здесь — существующая локальная оценка добавленного контекста, НЕ серверное измерение свободного native DeepSeek window.

## Текущая точка RP272 — короткие и составные действия

Финальная упаковка: Chrome/Firefox build+ZIP успешны;3 canonical downloads обновлены. SHA25623/23 runtime и648 source entries совпадают с диском/copies; current docs/core/initial+type-cleaned registrations/report/snapshots/.gitattributes включены, tests/private-assets/веса/.env/Git/nested ZIP исключены. Final QA notes повторно упакованы/сверены. Прежний >500KB warning остаётся RP-08. Установленная личная копия не обновлялась автоматически; завершённые проверки RP272 не повторять.

По запросу пользователя подключён src/core/story-sequence-priority.ts и outer compiler pass с exact RP271 rollback. Bare RU/EN single actions и explicit/bare2–3 object clauses используют прежние неизменные storyActionBalance/storyCompoundAction validators. Никакого arbitrary NLP/owner/pronoun/permission/fulfillment inference. Фразы с неразобранной/отрицаемой/условной/персональной/deictic/goal/третьего лица/четвёртой частью не получают частичного нового разбора. Names masked by old parsers; quotes/keys/values не lexical evidence.

ВСЕ literal matching non-repeat sources плюс prior non-repeat должны поместиться≤8/full render, substantive coverage обязателен для КАЖДОГО clause. Unknown/edited/foreign/replacement source или overflow → точный прежний текст/выбор/report/counters. Whole source/status/code/условия/неизвестность сохраняются. Shared literal-label guard остаётся на wire, идентичности/поручения не объединяются. Unrelated old anchor может остаться protected. Нет DB/schema/UI/settings/model/extra request/canon изменений; sequencePriority:false — test-only comparator. Native transcript не сжимается. [Пример/границы](docs/DISCUSSION-PRIORITY.md).

До интеграции fixed64 new RU/EN input/gold/RP271 baselines (32dev/32evaluation,28positive/36controls,2settings/3objects/36repetitions). Протокол алгоритма/компилятора зафиксирован до сравнения. TypeScript выявил unused fixture import; initial registration/snapshot сохранены, отдельный type-only amended registration ДО comparison с exact same algorithm/compiler/input/gold hashes. Initial CLI остановлен fingerprint check, старые отчёты не перезаписаны; 28/28 complete vs0/28,36 controls exact, substantive loss0,192 full-budget probes без source/status/budget ошибок. Набор теперь seen, шаблоны родственны; arbitrary language не проверен.

RP271 finalized compiler сохранён в docs/benchmarks/rp271-final-compiler.txt; старый unit fingerprint проверяет исторический CRLF snapshot, не законно меняющийся current compiler. Старые core/fixture/gold/protocols unchanged. Новый comparator false возвращает exact RP271 для каждого frozen64 case.154 новых unit, selected18files931pass/0fail, TypeScript/diff-check0. Native Edge8/8pass/0fail/0flaky за2.6m: sequence/RP271/old compound/reference RU/EN;30 explicit new POSTs before/after reload, complete2/3 objects incl user's unqualified example, unchanged facts/roleSeeds/episodeSources, no extra windows/page errors. All own contexts finally closed. Финальные архивы сверены выше. Full unit/full browser matrix/live account не повторялись; результаты прошлой итерации не выдавать за новые. Base f4a093e, local RP269–271 preserved, push не запрошен, installed personal copy не менялась.

Дальше: отдельный новый corpus и бюджетный allocator для9+ substantive источников. Нельзя расширять cap8 без whole-budget/coverage/quotes/conditions/rollback проверки или удалять историю ради места. Больше свободной речи требует нового independent набора; E5/MMR не интегрированы, RP-05–08 в целом открыты. Не повторять RP272 после финального QA/package status ниже.

## Текущая точка RP271 — более свободные повторы и одиночные действия

Финальная упаковка завершена: Chrome/Firefox build+ZIP,3 canonical copies в downloads. Все23/23 browser и640 source entries сверены SHA256 с текущим диском/copies; source содержит current core/docs/initial+amended registrations/reports/snapshots/.gitattributes, исключает tests/private-assets/веса/.env/Git/nested ZIP. Source notes после QA дописаны и повторно упакованы/сверены. Прежний >500KB warning остаётся RP-08. Установленная копия не обновлялась автоматически; этот этап не повторять, продолжать со следующего нового корпуса.

Пользователь поручил расширить RP270 для свободнее сформулированных повторов и обычных игровых действий. Новый src/core/story-flexible-priority.ts читает только целые frozen equal text/quote события с доступным speaker-only, без task/claim; конечные формы головы и явные три отсутствия новизны допускают разные separators/order. Неполное «ничего нового», новый код/условие/обещание/добавочная фраза/пересказ/unknown источник не понижается. RP270 reader и его raw code/fixture/protocol hashes не переписаны. [Пользовательский пример и пределы](docs/DISCUSSION-PRIORITY.md).

compileGameContext получает точный RP270 result/proof, использует прежний storyActionBalance object matcher или literal-topic admission, сохраняет ВСЕ substantive matching sources + prior non-repeat union≤8/full render or exact RP270 rollback. Уже полный набор не перекомпилируется. Нет DB/schema/UI/settings/model/extra request/canon mutations; flexiblePriority:false — test-only comparator. Native transcript не сжимается. У supported object action может сохраняться прежний AMBIGUOUS_STORY_OBJECT guide вместе со ВСЕМИ независимыми candidate sources; это не identity resolution/permission/fulfillment/merging. Personal/name/deictic/unknown guards не разрешены.

Новый90-case RU/EN baseline фиксирован до интеграции:60dev/30evaluation,18positives/72controls,3сеттинга,36 поздних обсуждений/6 форм. Первый completeness0→15/18: три qualified EN actions блокировались literal guard. Initial algorithm/compiler snapshots + registration/report сохранены; отдельно зарегистрирован narrow candidate-preserving exception с неизменным guard/quotes/owners/conditions. Corrected0→18/18,72 controls exact, substantive loss0,270 whole-prompt probes без budget/source ошибок. Это reused evaluation регресс, не новый независимый holdout после изменения правила. Gold/input/старые protocols не менялись. `.gitattributes` сохраняет LF новых core/fixture/scripts и CRLF frozen game-context; compiler snapshot fingerprint проверяется в исходном CRLF, без изменения смысла.

Финальная QA:165 новых unit cases, selected7files444pass/0fail, TypeScript/diff-check0. Полный267-file прогон:5871pass/1 прежний100-turn5000ms timeout/5 прежних todo,698.80s; JSON .output/rp271-full-unit.json сохранён. Тот же неизменённый файл отдельно24/24pass,100-turn2969ms, report .output/rp271-memory-batch-repeat.json. Не называть первый полный запуск0fail. Initial contract40/40; первый focused438pass/5fail от ещё блокируемых qualified actions сохранён как причина amended policy, assertions не ослаблялись. TypeScript исправил только tuple-spread type в fixture, данные прежние.

Native Edge:4/4 новых+RP270 RU/EN cases,46 явных completion POST, whole data before/after reload/unchanged stored facts/roles/sources/нет extra windows. Старые action2/2pass; старые reference RU общий120s timeout и EN startup12s timeout при параллельном unit, затем неизменённые sequential RU/EN2/2pass за54.2s. Итого8 уникальных native cases прошли, но первый combined regression не0fail/не0flaky. Все own contexts finally closed, no live DeepSeek/личный world/installed files. Финальные архивы сверены выше. Base f4a093e, RP269–270 local work preserved, push не запрошен.

Дальше: новый независимый корпус коротких/составных действий и ещё более свободных форм перед расширением. Все90 RP271 теперь seen.9 substantive sources remain allocator problem; не объединять поручения/историю/условия ради восьми мест. E5/MMR не интегрированы; RP-05–08 целиком не закрыты. Исторический RP270 ниже не актуальная точка.

## Текущая точка RP270 — рабочий приоритет содержательных источников

Полный unit регресс после финального runtime кода:265 files/5707pass/0fail/5 прежних todo, Node24/worker1,562.39s; report .output/rp270-full-unit.json только локальный. TypeScript/diff-check0. Native8/8pass:2 новых RU/EN и6 старых long-history/task-goal/lasting-recall; все собственные contexts закрыты. Не путать full unit с live-account quality или закрытием всех RP-05–08.

Финальные Chrome/Firefox build+ZIP успешны;3 canonical downloads обновлены, SHA25623/23 runtime files и631 source entries совпадают с диском и копиями. Source включает current docs/core/registrations/reports/.gitattributes, исключает tests/private-assets/веса/.env/Git/nested ZIP. После завершения QA документация дополнена и повторно сверена внутри source ZIP. Прежний >500KB warning остаётся RP-08. Установленная личная копия автоматически не менялась; push не запрошен.

Пользователь поручил не вытеснять важные события/условия повторными разговорами. Implemented src/core/story-discussion-priority.ts + compileGameContext two-pass priority: prior internal selection/proof, whole literal topic's non-repeat sources + all prior non-repeat sources, union≤8/full-render or exact original result/counters. Only known full equal quote/text kind:event with frozen available speaker ONLY and finite explicit no-new-information/actions/commitments repetition lowers. No task/claim/belief/recipient/extra clause/number/edited/unknown source downgrade. Dialogue/person/time/owner/ambiguous/reference-only/restart/unknown topic retain old behavior. No schema/settings/DB/canonical/model/extra native send changes. Two local compiles only for a proven narrow group; native context not compressed. Runtime no longer RP262-only: this limited path is integrated; old E5/MMR/RP269 not integrated.

New96-case baseline fixed BEFORE algorithm;64dev/32evaluation (48positive/48controls) with120 late discussions. Initial20/32 vs16/32 and10/16 vs8/16. Development unit exposed RU external closing-quote punctuation bug; initial code snapshot/protocol/report preserved, mechanical amendment separately registered, same gold/policy/weights. Corrected22/32/11/16, controls48 exact, substantive/lost lexical gold0;480 whole-prompt probes. Reused evaluation split is NOT a new independent holdout for corrected code; source templates are narrow, not arbitrary semantics. [Guide, reports and bounds](docs/DISCUSSION-PRIORITY.md). Initial CLI cannot rerun current corrected source against its old hash; use corrected CLI/full Git checkout.

Final QA: runtime/contract58 pass; selected6files446pass/0fail incl RP269/RP264 provenance and old admission; full unit5707pass/0fail/5 existing todo; TypeScript0. Native Edge synthetic RU/EN2/2 pass, actual fact acceptance→32 later conversations→whole POST before/after reload→dialogue request,20 sends total, no stored facts/roles/source changes and no page errors/extra windows. Additional older long-history/task-goal/lasting-recall RU/EN6/6 pass (4.1m); total8/8. Own contexts closed. No personal account/installed copy/live DeepSeek or full browser matrix. Existing RP269 local work retained, Git base f4a093e; no push requested. CLI startup SSR timeouts/one concurrent WS warning are harness issues: sequential retries, own temp and hmr/ws disabled on corrected CLI; native timeouts/guards unchanged. Earlier runtime unit repeated all96 fixtures per case caused one5s timeout; one shared fixture + cloned input fixes setup without relaxed assertions.

Следующий RP-05: NEW independent freely worded corpus before widening this explicit-repeat predicate or adding ordinary-action priority. All RP270 examples now seen; do not tune current code to them. Preserve relevant conditions/attributed uncertainty/current statuses/source IDs, full budget/cap8 and exact fallback. Nine substantive sources remain a separate allocator/ranking problem; don't truncate them or remove canon. Next live-user test may update existing files manually after package handoff, never delete extension/reset world automatically.

## Текущая точка RP269 — событие против обсуждения

Финальные пакеты RP269: Chrome/Firefox build+ZIP успешны,3 canonical copies обновлены; SHA256 сверка23/23 browser files и619 source entries с диском/copies успешна. Source содержит новую документацию/отчёт/регистрацию/скрипты и `.gitattributes`; tests/private-assets/веса/.env/Git/nested ZIP исключены. zip.includeSources явно сохраняет `.gitattributes` без включения остальных dotfiles. Source notes обновлены после QA; прежний >500KB warning остаётся RP-08. Браузеры/служебные чаты не открывались, установленные файлы не заменялись. Игровых нововведений в RP269 нет; не просить пользователя обновлять расширение ради этого эксперимента.

Пользователь после pull f4a093e поручил продолжить память по передаче. Выполнен новый отдельный read-only experiment, не production integration. До алгоритма заморожены96 RU/EN cases (64dev/32holdout,48positive/48control) и текущий lexical/compiled baseline. После — отдельная регистрация кода/политики/whole-admission probe, затем Node network-blocked evaluation:0 requests. Нет E5/MMR/download/provider/DB/schema/UI/личного мира изменений. Runtime остаётся RP262 + FIX268/UX267; новые файлы только scripts/tests/docs и checkout formatting.

Результат: complete dev20/32→20/32, holdout10/16→10/16; wrong-first16→12 и8→6. Все48 controls exact prior selection; mandatory evidence loss0, lost lexical gold0.480 actual whole-prompt probes на900/1500/2300/4000/6000;900 всегда exact fallback, остальное помещается с прежней полнотой30/48.12 mandatory-union overflow: защита baseline task/claim/любого bound speaker оставляет повторные обсуждения и не даёт вернуть исходное событие/все условия. Не объявлять улучшенную первую позицию улучшением полного набора. Не подключать эту finite grammar к игре и не считать related-template holdout произвольной речью.

[Метод, результаты и команды](docs/SEARCH-GROUNDING.md), frozen baseline tests/fixtures/story-search-grounding-baseline.json, protocol scripts/story-search-grounding-registration.json, full report docs/benchmarks/rp269-grounding-results.json. Источники/negative/question/reported/unknown/terminal statuses/replacement names/cap guards проверены.138 new unit cases; финальный selected8 files590pass/0fail, TypeScript/diff-check. Первый previous-regression run450pass/2fail: raw code SHA изменились от CRLF при checkout; `.gitattributes` и только EOL formatting восстановили EXACT прежние frozen checksums. Старые алгоритмы/эталоны не перерегистрированы и логически не менялись. Core text/admission fixture EOL закреплён как в RP269 registration; new/old audit scripts LF. Full unit/browser/live account здесь не запускались; не выдавать это за runtime test.

Следующий RP-05: NEW independent corpus более свободных формулировок ДО новой query-relevant mandatory evidence policy. Все96 RP269 теперь seen. Гипотеза: сохранять целые релевантные исходники/условия/альтернативы/актуальные статусы, а не автоматически считать любое speaker-bound обсуждение обязательным. Это не разрешение стереть/объединить accepted facts, угадывать объект/владельца/правду или ослабить unknown/budget/source guards. Прежние RP263/264/269 algorithms не внедрять и не тюнить по просмотренным gold; current lexical fallback обязан остаться точным. Git baseline f4a093e, новые изменения локальны; commit/push не запрошен. Установленное расширение не менялось.

## Передача домой после push — RP256–FIX268

Пользователь прямо попросил отправить все накопленные изменения и оставить точную передачу домашнему Codex. Ветка main, проверенный исходный HEAD e8f5cba совпадает с origin/main; обновление выполняется обычным commit/push без переписывания истории. Этот раздел заменяет прежние исторические пометки «push не запрошен». Окончательный commit ID берётся из git log после pull; не ориентироваться на старые HEAD в нижних разделах.

**Что уже закончено:** рабочий подбор памяти RP256–262 для нескольких старых дел, длинных/составных действий, постоянных сведений, ссылок на предметы и форм коротких имён; отдельные offline эксперименты RP263–264 с зафиксированными данными/отчётами (E5/MMR в игре нет); меню/настройки/состояния UX265–267 и финальное QA; готовый сброс мира FIX268, который не устаревает только из-за ожидания и служебных изменений. Chrome/Firefox/source ZIP в downloads актуальны. Подробности/границы каждого этапа ниже и в ROADMAP; личный лор не переписывался, игровой аккаунт не использовался.

**Что делать дома:** после безопасного pull прочитать [HOME-CODEX-NEXT](docs/HOME-CODEX-NEXT.md), верх этого файла, [дневной журнал](docs/HANDOFF-2026-10-14.md) и последние разделы ROADMAP. Первый следующий этап RP-05 — новый независимый корпус и source-aware grounding/reranking: отличать совершённое действие от обещания, намерения, обсуждения и отсутствующего события. Сначала закрепить новые RU/EN данные/эталон/лексический baseline, только потом менять эксперимент. Все128 прежних случаев уже просмотрены. Сохранить источники, условия, текущие статусы/коды, cap8 и полный бюджет с точным fallback. Не подключать нынешний E5/MMR и не повторять закрытое UX QA.

На домашнем ПК модель/optional runtime из private-assets не появятся с pull; корпус и обычный baseline можно подготовить без них. Согласование прежнего скачивания описано в RP263; не заменять локальный эксперимент внешним сервисом. Использовать поддерживаемый Node24+ (здесь24.19.0), не системный Node20 с установленным Vitest5. Установленную Edge-копию обновлять в её прежней папке и reload, без удаления расширения. Личный сброс не подтверждать за пользователя; FIX268 сохраняет обе человеческие проверки.

## Текущая точка FIX268 — готовый сброс после долгого чтения

Пользователь получил reset-stale через30–50 минут чтения готового отчёта, без новых сообщений. Время ожидания не имеет TTL. Воспроизведён дефект: resetGuard включал всю активную ChatBinding, включая updatedAt/messageCountAtAnalysis/portraitLayouts. Реальный savePortraitLayout менял только расположение и timestamp, sharedGame оставался побайтово прежним, но оба сохранённых формата плана давали reset-stale.

Исправлены src/core/world-reset.ts и storage/world-reset.ts: сравнение нормализует обе исходные копии, исключая только известные служебные отметки/расположение/локальные изображения/recovery/notice. Идентичность/ревизия игры, сценические состояния, scope, подбор памяти, исходный лор, записи, шаблоны и версии анкет остаются защищены; неизвестные будущие поля также участвуют. Старый ready resetGuard читается без повторной генерации и без подмены baseline текущими данными. Нет миграции, автоматического применения или изменений личного мира. Старые исправленные invalid-evidence не являются причиной этого отказа.

Добавлены регрессии50 минут через Date.now, настоящего savePortraitLayout до обоих подтверждений, legacy guard, реальных изменений и повреждённых guards. Новый isolated Edge RU/EN idle сценарий сохраняет legacy guard в реальной IDB, перезагружает панель, меняет только служебные поля, подтверждает оба шага и проверяет архивы/фото/чужой мир/чистый POST. Исходный старый черновик не затрагивается. Первый прогон новой E2E-проверки неправильно искал внутренний resetGuard в публичном CastView; assertion перенесён на raw fixture IDB, production-выдача внутренних данных не менялась. Правила skip и таймауты не менялись.

Финальная проверка FIX268:10 focused unit files/217pass/0fail за23.89s (reset/guard/preparation/entries/coordinator/UI/world-game/portrait-layout/cast); TypeScript0. До исправления новая задержанная storage регрессия дала2 reset-stale, после — оба формата проходят. Финальный Playwright24 variants/16pass/0fail/0flaky/8skip за124.29s:8 реальных Edge MV3 сценариев,8 UI RU/EN320/900px Edge/Firefox; пропуски —8 Edge-only runtime вариантов в Firefox. Весь5354-unit/272-case UX267 здесь не повторяется. Личные данные/аккаунт/установленная копия не проверены и не сброшены.

Chrome/Firefox build+ZIP пересобраны; финальная сверка23/23 browser files,609 source files с текущим диском и CRC успешна,3 копии downloads совпадают поSHA256. Source актуализирован после финальной передачи. Служебные отчёты/профили тестов вне поставки; >500KB warning прежний. После обновления существующей установленной копии и reload старый готовый план можно подтвердить только при неизменившейся игре, без повторной подготовки. Прежняя локальная RP256–267 работа сохранена, push не запрошен. Следующий исследовательский RP-05 остаётся source-aware grounding из RP264; нынешние E5/MMR не подключать. UX267 не переделывать.

## Текущая точка UX267 — финальная проверка UX

Пользователь прямо поручил прогнать финальное UX QA и исправить найденное. Сохранена вся прежняя незакоммиченная RP256–266 работа. Исправлены потеря категории/черновика настроек через нижнее меню, ложный конфликт при повторной правке сохранённого факта, неотображённая ошибка настройки и конкуренция кликов при медленной записи; убрана повторная подсказка сцен. Исправлены устаревшие названия памяти/пути импорта и описание inbox в режиме подтверждения. Лор, RP262 runtime, реальные фотографии и личный профиль не менялись.

Добавлены регрессии сохранения черновика, повторной правки факта и RU/EN failed/slow preference save. Старые E2E адаптированы к новому маршруту/двум раскрытиям отчётов, без удаления проверок редактирования, отмены, фокуса, axe и сохранности данных. Backup v5 проверяется по repository records и байтам photo table, а не сравнением inline data URLs с переносимыми адресами. Fault-injection существующего мира начинается после обеих записей, а не имитирует недоступность сейфа посреди второй записи. Проверка сейфа и startup error не ослаблены.

Повторяемый набор: playwright.ux.config.ts, отдельный свежий сервер4175,22 файла/272 сценария вместе с большим fixture. [Область, команды, ограничения](docs/UX-QA.md). Использован встроенный Node24.19.0; системный Node20 не поддерживается Vitest5.0.3. Промежуточный full unit наNode20 дал113 ошибок (включая старые diagnostics assertions); первый Node24 workers2 дал5353pass/1 старый 100-portions timeout/5todo, отдельный этот файл30/30 за19.47s. Финальные unit выполнены с одним worker, без повышения таймаутов/ослабления assertions. Личные данные не использовались; browser runtime — изолированный Edge с синтетическим DeepSeek.

**UX265–267 закрыт по результатам финальной проверки.** Весь unit наNode24/worker1 —259 файлов,5354pass/0fail/5todo за759.05s; focused UI31/31 после последней правки callbacks; TypeScript/diff-check0. Общая финальная матрица:226pass/0fail/0flaky/44skip,702.68s, свежие пакеты, Edge2 workers/Firefox1, без full unit в фоне. Большая изолированная библиотека280MiB/24 персонажа/40 фото: экспорт скачанного файла → пустая БД → точные записи/изображения/назначения,1pass/1Firefoxskip за54.9s. Всего227pass/45skip из272 вариантов:10 отсутствующий Brave,34 Edge-only ветки в Firefox,1 повтор большого fixture. Новые skip/увеличения таймаутов не добавлялись. Прежний параллельный Firefox дал Browser.removeBrowserContext/_maybeDontRestoreTabs на закрытии контекстов; окончательный последовательный Firefox прошёл без ошибок.

Пакеты Chrome/Firefox build+ZIP пересобраны; все23/23 browser entries побайтово/CRC сверены с диском. Source609 файлов, включая UX-QA и config, актуализирован с финальными заметками; tests/private-assets/.env/веса/вложенные ZIP исключены. Все3 canonical copies в downloads совпадают поSHA256; >500KB chunk warning остаётся RP-08. [Матрица и границы](docs/UX-QA.md); raw reports/screenshots только в игнорируемых .output/test-results, не в поставке. Реальный DeepSeek/личная установленная копия/личный мир не проверялись и не менялись.

Очистку собственных профилей test-results-ux267* автоматическая проверка запретила без указанной причины. Каталоги оставлены локально/игнорируются/исключены из ZIP. Собственная вкладка/viewport/сервер4176 завершены, существующий4173 не трогали. Финальные отчёты в игнорируемой .output; тестовые данные вымышлены.

**Следующий RP-05 шаг остаётся прежним:** новый независимый source-aware grounding/reranking корпус из RP264; нынешние E5/MMR в игру не подключать. Не повторять RP239–267 и завершённое UX QA. Откат старого чата и другие открытые RP-05–08 ограничения не закрываются этой проверкой. Commit/push не запрошены; установленная личная копия не обновляется сборкой автоматически.

## Предыдущая точка UX266 — меню, память и диагностика

По прямому запросу пользователя выполнена перестройка оболочки UX. «Игра» оставляет выбор мира и готовность памяти; подробности доставки и ручные инструменты раскрываются отдельно. «Память игры» получила единую навигацию Обзор/Память/Дела/Персонажи/Сводки/Записанные сцены. Обзор показывает режим сохранения и нерешённые предложения; дополнительный batch-разбор, управление прогрессом и legacy starting points раскрываются по названиям. StoryReview остаётся одним экземпляром, прежняя внутренняя навигация скрыта только в новом workspace; черновики не теряются при смене раздела. В фактах явно показана несохранённая правка и есть отмена локальной правки. Просмотр доступен во время ответа/в старом чате, изменения блокируются с отдельным объяснением.

Настройки сгруппированы в карточки с назначением и областью действия. Reply recovery и StoryUpdateSettings собраны в «Память и защита отправки». Точный подбор памяти остаётся advanced; диагностика дополнительно закрыта «Инструментами технической поддержки». SupportDetails скрывает raw JSON/коды/HTTP/историю исправлений за двумя раскрытиями. Текущий сбой/успех/next action и последствия дополнительных запросов/strict sending остаются видимыми. Общий scoped [hidden] защищает скрытые формы от display:grid и клавиатурного доступа. Неизвестное состояние batch-проверки больше не выдаётся за «Выключено», ошибочный refresh не помечается сохранением.

Основные изменения: navigation/story UX dictionaries, SettingsNavigation, StoryWorkspace/StoryReview/StoryFacts, StoryMemoryBatchPanel, StoryUpdateSettings, SupportDetails, CastDiagnostics, WorldResetSetup, ImageErrorDetails/ImageHeaders/MemoryDeliverySummary, sidepanel App/styles. [Пути и примеры](docs/MENU-GUIDE.md); DESIGN-SYSTEM/WORLD-RESET/CHARACTERS актуализируются. Лор/схемы/подбор RP262/личный мир не менялись, E5/MMR по-прежнему не встроены.

Проверка: TypeScript/diff-check и ручной локальный предпросмотр на вымышленных данных RU/EN,320/900px; переходы, фокус, скрытые формы, сохранность/отмена черновика памяти, доступ к отчётам и старый/занятый чат. Проверены неизвестный статус batch и предупреждение «Нужно внимание» на закрытом разделе при остановке разбора. Существующий navigation unit адаптирован к новой категории без добавления test cases; unit/E2E-наборы в этой итерации не запускались. Живой DeepSeek/установленная Edge-копия/реальный сброс не проверялись. Браузерные пакеты пересобраны. Предыдущая локальная работа сохранена, commit/push не запрошены.

**Дальше:** запрос пользователя на эту перестройку UX реализован; проверку установленной копии и полный браузерный регресс не считать пройденными. Исследовательский RP-05 остаётся source-aware grounding на новом независимом корпусе из RP264; не внедрять нынешний E5/MMR по общему90/100. Не повторять RP239–265 и не сбрасывать мир ради демонстрации интерфейса.

Сборка UX266: финальные Chrome/Firefox build+ZIP успешны. Первые попытки выявили Vite CSS cache error при анализе content entrypoint из-за side-effect CSS import нового SupportDetails. Стили перенесены в общий design-system.css, который уже собирается для Shadow DOM через прежний inline-путь; конфигурация/зависимости не менялись. Все23/23 browser entries сверены побайтово, CRC проверены; source607 текущих файлов, включая MENU-GUIDE/SupportDetails и обновлённую передачу, тоже сверяется с диском. Три canonical ZIP в downloads совпадают по SHA256 с .output. Tests/private-assets/.output/зависимости/веса/секреты/вложенные ZIP исключены. Прежний >500KB chunk warning остаётся RP-08. Preview/скриншоты только в игнорируемой .output; в поставку не включены. Свои вкладки/сервер4174 закрыты; существующий сервер4173 не трогали. Установленная копия автоматически не менялась.

## Текущая точка UX265 — готовый план сброса больше не теряется

По сообщению пользователя: после долгой подготовки временное окно закрывалось, подтверждения не появлялись; диагностический журнал с промежуточными invalid-evidence выглядел текущим сбоем, хотя phase=ready/prepared24/cleanup=done. Причина UI: WorldResetSetup опрашивал сохранённую работу только при открытом диалоге и жил внутри посещённой вкладки истории, которая размонтируется при смене контекста/закрытии встроенного меню.

Исправлено: единый WorldResetSetup смонтирован на уровне App вне вкладок, общий useWorldResetJob читает сохранённую подготовку при закрытом диалоге и по возвращению фокуса/видимости. После полной готовности и очистки проверка открывается автоматически только для актуальной игры и исходного чата. Закрытое меню имеет WorldResetNotice на странице: кнопка открывает extension iframe с адресным resetReview ID. «Позже»/закрытие сохраняет существующий statusHidden, не подтверждая и не отменяя план; постоянная карточка в меню позволяет вернуться к нему. Старые готовые планы тоже подхватываются; устаревший прогресс требует повторной подготовки. Не восстанавливать несохранённые ручные правки как будто это утверждённый план.

cast-progress/cast-progress-i18n различают полную готовность и промежуточный ready между частями, исправленные ошибки/исправление в процессе/текущую остановку/предыдущую попытку. CastDiagnostics сохраняет безопасный отчёт и весь прежний журнал, меняет заголовок на «История проверки ответов» и показывает следующий шаг. Текущий сбой и неуспешная очистка не скрываются. Две человеческие проверки, exact evidence, nonce, контроль ревизии мира и транзакционное применение не ослаблялись. Автоматическое открытие формы не отправляет confirm-reset/apply-reset. Личный мир/изображения/игровой аккаунт не менялись.

Проверено: TypeScript и diff-check; ручной локальный UI на вымышленных данных RU/EN,320/900px: готовый план, маркировка 4 исправленных ошибок, закрытие/возврат, подготовка в фоне → готовый план, переход ко второму шагу с выключенным применением без отдельного согласия. Unit/E2E-наборы в этой итерации не добавлялись и не запускались; живой сброс/реальный DeepSeek/установленная Edge-копия не проверялись. Браузерные пакеты пересобраны; окончательные архивы сверяются с файлами сборки. Первый Chrome build остановил временный Windows Access denied при удалении esbuild temp; повтор с отдельным TEMP внутри .output прошёл. Прежний warning >500KB остаётся. Скриншоты и локальный preview только в игнорируемой .output, в поставку не включать.

Основные файлы: src/core/cast-progress*.ts, src/core/world-reset-i18n.ts, shared/{WorldResetSetup,WorldResetNotice,useWorldResetJob,CastDiagnostics,CastStatus,StoryWorkspace,WorldGamePanel}, sidepanel/App.tsx, content/PageWidget.tsx и стили. Мануалы WORLD-RESET/CHARACTERS, ROADMAP и дневник обновлены. Существующие tests/world-reset-ui.test.tsx и tests/e2e/world-reset-ui.spec.ts адаптированы к автоматическому открытию проверки и постоянной карточке; новых test cases не добавлено, наборы не запускались. TypeScript после адаптации прошёл. Предыдущие локальные RP256–264 сохранены; commit/push пользователь не запрашивал. Установленное расширение автоматически не обновляется.

Итог пакетов UX265: финальные Chrome/Firefox build+ZIP успешны; архивы сверены побайтово со всеми23 файлами каждой сборки. Source604 файла обновлён текущими исходниками/документами и тоже сверяется побайтово; tests/private-assets/.output/зависимости/вложенные ZIP/секреты/веса не включены. Три актуальных ZIP скопированы в downloads с проверкой SHA256. Ручной отдельный preview также подтвердил уведомление при закрытом меню → открытие шага1 по кнопке; реальное применение сброса не выполнялось.

**Следующая работа RP-05 не изменилась:** source-aware reranking/grounding замер на новом независимо размеченном корпусе; не подключать нынешний E5/MMR к игре. Подробности и ограничения RP264 ниже. Если появится новый живой сбой сброса, сначала получить финальный phase/cleanup/готовность всех частей; не принимать историю исправленных ошибок за terminal failure.


## Текущая точка RP264 Разнообразие кандидатов и сохранность доказательств

Продолжение выполнено в изолированном read-only стенде, без изменения рабочего поиска RP262/канонических данных/личного мира/установленной копии. Новых весов/сервисов/production dependencies нет: используется ранее разрешённая локальная E5-small q8. Прежняя локальная работа RP256–263 сохранена, main e8f5cba, commit/push не запрошены.

Сначала до inference зафиксированы 40 новых RU/EN примеров, policy/algorithm/input/gold/source-provenance hashes: tests/fixtures/story-search-diverse-baseline.json. Anchored MMR: lexical leader, затем 0.5×query relevance−0.5×max redundancy, cap8; owner/ambiguous identity/covered existing topic admission сохраняют baseline. Известные50 positive42→50 full top8, но первые новые30 остались23/30: paraphrase3/8→6/8, multi-source5/6→1/6, потеря4 ранее найденных источников с разными условиями. Первый вариант отклонён.

Затем добавлена защита всех уже выбранных текущих facts с task/claim/непустой frozen source role. Они обязательны до новых similarity-кандидатов; заполнение/переполнение cap8 возвращает точный baseline. Формула/вес прежние. Первые40 стали development; ДО запуска защиты отдельно размечены ещё24 новых запроса с90 обсуждениями, у которых тоже есть явный speaker. Frozen tests/fixtures/story-search-evidence-baseline.json (128 cases,964 inputs): input0dc2b6d67ee29a31aab8699c83fe8f2371e9777c04b129a0a5d28db1888d7109, gold bba5781a96e8247c26068489d2888269bfb51f12c88465f2f8b65713254bf141. Policy/algorithm/provenance и прежний base algorithm закреплены раздельно.

С защитой full candidate sets: seen50/50 vs lexical42/50; development26/30 vs23/30; второй независимый fresh14/20 vs14/20 (без защиты17/20). Всего90/100 vs79/100 lexical и77/100 actual compiled, НО90 включает просмотренные данные и НЕ доказывает независимый выигрыш. Wrong first24/100 остаётся прежним; lost lexical gold0, mandatory source loss0. 14/28 controls на старых/dev данных меняют подбор, новые4 сохраняют его. **Не внедрять в игру:** защита корректности есть, нового независимого выигрыша нет; bound discussions могут занимать все места.

Реальная full-prompt probe заменяет whole fact block внутри текущего compiler output с прочими sections/guards неизменными; cap8/full addedContextTokens проверяются, иначе точный fallback. Это не новая allocation/integration/live send. Default6000 full evidence90/100; fresh24 budget900:1 replacement/23 exact fallback,1500/2300/4000/6000:24 replacement, recall14/20. Post-run224 уникальных case/budget проверили mandatory IDs именно фактического baseline на ЭТОМ бюджете:0 потерь. Полные source quotes/условия/task status/claim/current code и scoped frozen roles сохранены; старые open/cancelled/code sources отсекаются до отбора. Исторический старый код может быть указан как отменённый ВНУТРИ актуального источника.

Файлы: scripts/story-search-diversify.mjs + policy (первый неизменный вариант), story-search-evidence.mjs + policy (защита), declarations; общий CLI --experiment rp263/rp264/rp264b; raw scenario adapter reuse; новые fresh/audit/diverse/evidence fixtures и tests. [Метод/команды/результаты](docs/SEARCH-DIVERSITY.md), case-level reports docs/benchmarks/rp264-search-results.json и rp264b-search-results.json. --freeze отдельным шагом сwx, не перезаписывает прежний эталон. При изменении источников/подбора/политики/кода старая регистрация не проходит; gold/keys/roles не поступают encoder.

Оба actual inference run были Node fetch/http/https/net blocked:0 попыток,734 общих prefixed inputs дали точно одинаковые векторы.734 inputs7.29s,964 inputs15.67s, load0.95/1.52s; параллельно были focused unit jobs, это не контролируемый latency benchmark/не браузер. Whole-process peakRSS около956/988MB включает Vite/fixtures/probes. Новых загрузок нет; installed runtime/weights остаются только private-assets, в ZIP не попадут.

RP264 QA: финальный выбранный набор12 файлов556 passed/0 failed/0 todo; TypeScript/diff-check прошли.250 новых unit в2 файлах, плюс прежняя64-case проверка RP263 разбита на64 отдельные source assertions с reuse результатов в агрегате. Промежуточные: protocol275 passed; общий491 passed/1 старый64-case synchronous timeout; ранее protocol43-case имел2 aggregate timeouts104/128. Все большие повторные compilation loops разбиты без ослабления assertions/таймаутов/production checks. Исправлена declaration intersection для extended report rows. UI/production runtime не менялись; live account/browser/full E2E не запускались. Финальный CLI --experiment rp264b --plan повторно подтвердил неизменную frozen регистрацию без скачивания.

RP264 packages: Chrome/Firefox builds и ZIP пересобраны; entry-to-disk SHA256 audit23/23. Source600 current files, текущие handoff/docs/2 reports/algorithm+policy/declarations включены; tests/private/.env/Git/node_modules/nested ZIPs и все .onnx/.wasm/.node исключены. Experimental model name отсутствует в runtime браузеров, root package/lockfile не менялись. Все3 canonical copies совпадают поSHA256, только3 ZIP без dated duplicates. Временный Windows UNKNOWN на копировании Firefox ZIP устранён повтором; readonly/права не менялись. Source repacked after final QA/package notes. Прежний >500KB chunk warning остаётся RP-08. Установленная копия не заменялась/не перезагружалась автоматически; изменения локальные, push не запрошен.

**Следующий конкретный RP-05 шаг:** отдельный source-aware reranking/grounding замер: отличать запрос о сыгранном действии от обсуждения действия и проверять отсутствие нужного события. Similarity, авторство и наличие записи по отдельности этого не доказывают. Сначала ещё один свежий независимо размеченный корпус; все RP264/RP264B наборы уже просмотрены. Сохранять whole current-source alternatives/условия/исторические IDs/unknown guard и реальный бюджет, не подбирать MMR веса по этим данным. Не подключать нынешние модели к игровым отправкам и не поставлять веса пользователям на основании общего90/100. Новый сервис/передача библиотеки/новые веса требуют соответствующего согласования; модель выбирает разработчик. RP-05–08/object IDs/pronouns/масштаб/live/old-chat rewind остаются открыты. Следовать текущему handoff, не повторять RP239–264.

## Предыдущий этап RP263 Локальный смысловой прототип

По поручению «продолжаем» выполнен следующий шаг RP262: отдельный read-only стенд поиска кандидатов. Пользователь отдельно подтвердил «Да, проведи эксперимент» для скачивания локальной модели/зависимостей. Xenova/multilingual-e5-small q8, revision ae61bf0193ce3851dc8a45147e459b04ed783d8a, 384d, mean pooling; Transformers.js3.8.1. Веса/токенизатор135392183 bytes, дополнительные установленные файлы391572893 logical bytes, только в игнорируемых private-assets. Корневые зависимости/продукт/личный мир/установленная копия не изменены.

64 заранее зафиксированных RU/EN запроса: Semantic40 development +24 holdout с новыми предметами/событиями и72 поздними обсуждениями. Frozen tests/fixtures/story-search-baseline.json; input SHA256 f1253bb9cb662660e49a9c73d986054024d10c59142d264161fee177f90ed73e, gold d173b9d46ded8ed4ccf8fb52c2c05368d4ff4d02b2de30c49b5a027244ae4cbd. Только текущие compacted source-backed записи; старое открытое поручение о камере не воскресает. Исправлена ошибка СТЕНДА: rankStoryFacts.index относится к compacted array, ID теперь от исходного факта. Рабочую компактацию/источники не меняли.

Из50 positive запросов полный набор: actual compiled40/50, lexical top8 42/50, dense28/50, fixed RRF(k60) hybrid35/50. Development lexical26/32 vs dense14/hybrid21; holdout16/18 vs14/14. Direct20/20→hybrid18/20, paraphrases16/20→14/20; multi-candidate6/10→3/10. Hybrid изменяет8/14 контролей. Явные owner/ambiguous identity запросы сохраняют baseline; similarity не назначает владельцев. Эти top8 показатели НЕ доказывают допуск в целый prompt/live quality. **Этот вариант не подключать к игре.** Веса/данные/критерии после просмотра holdout не подгонялись.

Файлы: scripts/story-search-{benchmark,evaluation,local-model,offline}.mjs + declarations/model manifest, tests/fixtures/story-{semantic-holdout,search-prototype,search-baseline}, 3 новых unit-файла. [Метод/команды/решение](docs/SEMANTIC-SEARCH-PROTOTYPE.md), точный case-level отчёт docs/benchmarks/rp263-search-results.json. Для запуска нужен полный Git checkout (source ZIP исторически исключает tests). CLI --plan/--export не скачивает; --download-model только явным флагом; local-only inference; кэш проверяется по текущим входам/источникам/модели, gold отдельно.

Запуск с запрещёнными Node fetch/http/https/net:0 попыток,424 вектора точно равны первому запуску. Повторный cold: load0.923s, inference4.160s, median9.50ms/p9513.57ms на вход, cache-read18.75ms отдельно, whole-process peakRSS816MB включает Vite. CPU i5-10400/Windows/Node24.19/2 inference threads; не браузер/не физическое отключение сети. 27 новых unit-проверок, финальный выбранный набор10 файлов242 passed/0 failed, включая provenance frozen report; TypeScript/diff-check прошли. Unit не скачивает веса и не выдаёт фиктивные векторы за качество модели. Полный unit/E2E/live-account не перезапускался; UI/production runtime в RP263 не менялись, прежние браузерные результаты RP262 остаются историческими.

RP263 packages: Chrome/Firefox builds и ZIP обновлены, SHA256 entry-to-disk audit23/23; sources591 current files, все3 canonical download copies совпадают, ровно3 ZIP без dated duplicates. Source включает текущие docs/benchmark/scripts/runtime template+lockfile; test/private/.env/Git/node_modules/nested ZIPs исключены. Проверено отсутствие .onnx/.wasm/.node файлов во всех пакетах и имени экспериментальной модели в runtime браузеров. Веса и установленные зависимости не попали в поставку. Source repacked after final QA/package notes. Прежний >500KB chunk warning остаётся RP-08. Установленное расширение не заменялось/не перезагружалось автоматически.

**Следующий конкретный шаг RP-05:** спроектировать и отдельно сравнить дополнительный подбор, сохраняющий точные совпадения/исходные события и не позволяющий повторным обсуждениям заполнить все места. До настройки зафиксировать ЕЩЁ ОДИН свежий корпус; RP263 holdout уже просмотрен и больше не unseen. Измерять пропуски всех альтернатив, неверный приоритет/unknown controls и реальный whole-prompt бюджет. Не внедрять нынешний dense/RRF, не добавлять словари под отдельный подарок, не считать similarity владельцем/разрешением/событием. Текущие runtime правила RP262 сохранить. Пользователь одобрил этот локальный эксперимент; новый внешний сервис/передача библиотеки или поставка модели пользователям этим не разрешены. RP-05–08/object IDs/pronouns/масштаб/живой аккаунт открыты. Main e8f5cba, RP256–263 локальны; commit/push не запрошены.

## Предыдущий этап RP262 Смысловые запросы и независимый замер

RP262: независимый замер поиска по смыслу и ограниченная форма вопроса о данном слове. 40 RU/EN запросов, 96 поздних обсуждений, вручную заданные источники; прежний выбор и top3 сохранены в tests/fixtures/story-semantic-baseline.json. Прямые запросы 16/16→16/16, перефразы 4/8→6/8, неверный первый кандидат среди перефразов 4→2, полный набор для общих ссылок 3/8→3/8. 8 контролей сохраняют прежний состав/порядок. Это проверка локального подбора, не качество модели.

Основная форма вопроса в story-owner-query.ts: ограниченное «данное Норой Мире слово» / “Nora’s word to Mira” использует прежнее ранжирование по source-bound promisor. Оба названных человека должны разрешаться однозначно; получатель не становится владельцем или отдельным фильтром. Исторические ID/версия V1/условия/статусы/бюджет/канонические данные не менялись. Нет нового словаря подарков, настроек, скачивания весов или дополнительных сетевых запросов. Исходная фикстура English recipient превышала возможности V1; исправлена фикстура без изменения источниковой грамматики. Контроль неоднозначного получателя тоже исправлен на фактически употреблённое имя/прозвище. 105 новых unit-проверок, включая 16 для коротких имён; финальные общие проверки ниже. [Примеры и пределы](docs/SEARCH-QUALITY.md).

По дополнительному запросу пользователя сразу исправлены короткие русские имена в текущем поиске: query-only retrievalQueryNames достраивает регулярные формы трёхбуквенных имён/прозвищ на а/я, включая Ева→Евой/Еве и Аня→Аней/Ане, в том числе однозначную короткую форму полного имени. storyRetrievalQuery и storyOwnerQuestion используют новые формы; V1 source reader продолжает использовать прежнюю retrievalNames. Проверены коллизии, чужой мир, замена человека, целый исходный запрос и неизменные исторические source IDs. Это не пересмотр сохранённых источников и не общее склонение всех русских имён.

RP262 QA: 105 новых unit-проверок. Перед дополнительной правкой коротких имён весь unit-набор пройден двумя запусками: 4972 основной + 24 batch = 4996 passed / 0 failed / 5 прежних todo. После query-only расширения: 17 связанных файлов, 701 passed / 0 failed, включая новый 16-case short-name набор, все owner/source/retrieval/reference/long-history корпуса; независимый Semantic40 остаётся 16/16 direct, 6/8 paraphrase, 3/8 ambiguous, 8 exact controls. TypeScript/diff-check прошли. Первый общий запуск дал 4994 passed / 2 timeout (batch100 и повторный синхронный goal48); оба файла отдельно 73/73. Goal-сводка теперь использует готовые результаты тех же 48 проверок, batch24 прошёл отдельно при прежнем 5s лимите. Производственные проверки/таймауты не ослаблены.

Финальный выбранный браузерный набор после исправления Ева→Евой: 32 passed / 8 намеренных installed-Firefox skips. Synthetic Edge RU/EN actual POST проверил nominal word до и после переименования в Еву/Eva и перезагрузки: сохранённый promisor ID/sourceName, исходный запрос, неизменные факты, исключённую альтернативу, 7 явных отправок на язык, отсутствие лишних вкладок/ошибок. Context-budget UI: Chromium/Firefox RU/EN 320/900, keyboard/overflow/scoped Axe. Исходный браузерный запуск (31/8/1) выявил короткое имя; промежуточный rename Елена прошёл 32/8, затем пользователь попросил исправить ограничение сразу. Изменение сделано только для current-query forms; замена персонажа/коллизии/историческая V1-грамматика проверены. Живой аккаунт/DeepSeek/Brave/полный E2E не проверялись; свои контексты закрыты. RP262 packages: Chrome/Firefox/sources ZIP SHA256 entry-to-disk audit 23/23/580 files; all 3 canonical download copies match, no dated duplicates. Current source includes SEARCH-QUALITY and first RP262 handoff; tests/private data/.env/Git/node_modules/nested ZIPs excluded. Source repacked after final QA/package notes. Existing >500KB chunk warning remains RP-08. Installed extension was not replaced or reloaded automatically.

Следующий конкретный шаг RP-05: отдельный прототип смыслового поиска кандидатов и сравнение с frozen RP262 baseline плюс новые holdout-примеры до настройки алгоритма. Не добавлять словарь под каждый подарок/спасение. Сначала проверить пользу, неверный приоритет, передачу всех альтернатив, задержку и размер/работу без сети; затем выбрать внедрение. В этой итерации векторная модель не сравнивалась и не подключалась. Не скачивать веса и не отправлять библиотеку новому сервису без пользовательского выбора. Разработчик выбирает модель сам, пользователь не должен выбирать техническую модель. Источники/владельцы/актуальность/целый бюджет остаются за текущим компилятором. RP-05–08, постоянные ID предметов, произвольные местоимения, масштаб и живая проверка остаются открыты. Не переделывать RP239–262. Личный мир/установленная копия не менялись; main e8f5cba, RP256–262 локально, commit/push не запрошены.

## Предыдущий этап RP261

RP261 fixes partial priority of independent same-label alternatives. storyReferenceCandidates retains all eligible source-bound open duties and persistent details for the literal group, and rejects the extra lane if a matching CURRENT task/persistent record is unavailable or unproved. Unified compiler admits every whole candidate plus recent anchor within cap8/rendered budget, or resets facts/omission/attempted/protected sets to guarded fallback exactly. A shared label is explicitly NOT an object ID; sources/owners/places/codes/conditions remain separate. Exact single-object literal collisions across current independent task slots get their own guard; the existing draft fact ranking/compaction was moved before guard costing; recent-context ranking remains separate. Supported special goals/compound actions retain their rules. No canonical/schema/settings/model/provider/DB/object-ID changes; drafts, source provenance and currentness unchanged. referenceBundle:false is a private prior-selector comparator.

Fixed independent34 RUEN corpus,300 newer scenes per fixture: whole target sets0/10→10/10; incomplete extra priority20→0;8 normal recall and16 guarded fallback cases. Code replacement, completed/cancelled tasks, explicit Day4→20 and earlier temporary circumstances checked separately.69 new unit cases; focused4 files159 pass/TypeScript pass. Initial bare-key wording correctly blocked the old lane; a semantically equivalent different-objects phrasing exposed partial priority, while the bare-object case remains a fallback control. Extra workshop source initially had a speaker instead of its explicit promisor; fixed the fixture, not evidence policy. Large synchronous rollups were split into per-scenario/budget checks without changing production/native timeouts. Final QA/packages follow below. RP256–260 local work preserved; no push requested, main e8f5cba; personal world/installed copy untouched.

RP261 final QA:69 new unit cases; full251 files4907 passed/0 failed/5 prior todo; final TypeScript/diff-check passed. Fixed34 RUEN corpus uses300 later scenes: target-set0/10→10/10 and incomplete extra priority20→0,8 normal and16 guarded-fallback cases. Broad browser98 passed/26 intentional installed-Firefox skips; first new-only10 passed/2 such skips. Actual synthetic Edge RUEN POST/reload starts with an open copper duty, accepts its completed result and replaces old code1133 with current4926;56 stored current facts/role seeds/selected source order remain identical after reload,24 explicit sends per locale/no extra tabs/errors. Source alternatives stay separate in the intercepted prompt for both this-key and literal blue-key requests; source roles/conditions/current claims/time status preserved, no old code record resurrected. Native fixture uses48 later scenes and configured6000 budget; unit checks1500–4300 verify exact guarded fallback and whole cap. Chromium/Firefox RUEN320/900 keyboard/scoped Axe/overflow,4 screenshots inspected. Initial full run cancelled after extending literal-label coverage, then final complete suite rerun. After test-only metric/cancellation-evidence refinements, focused quality35/35 rerun passed; production code unchanged. Test rollup and budget loops split per scenario, no production/native timeout or evidence guard relaxation. Live model/account/Brave/full E2E not tested; own contexts closed.

Next concrete RP-05 task: an independent semantic-search comparison for medallion/promise/alias/old event requests with source/owner gold, missed-evidence and wrong-priority metrics. Compare against the current local lexical selector before choosing another implementation. Do not install a heavy model, download weights or transmit the library without user choice; external quality/cost/offline behavior need explicit handling. Object IDs/pronoun resolution/incremental indexing/inter-turn reinforcement and RP-06–08/old-chat rewind/live quality remain open. Do not redo RP239–261. Only3 canonical downloads; installed copy update/reload stays manual.

RP261 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/579 files and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff RP261. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads and no dated duplicates. Existing >500KB chunk warning stays RP-08. Installed browser copy was not automatically replaced/reloaded.

## Предыдущая точка RP260 Ссылки на предметы и персонажей

RP260 adds explicit unresolved-reference guards for ordinary personal references, not just topic questions. Finite single-action this/that references may reserve a whole recent accepted anchor plus one eligible source-owned open duty and matching persistent detail. Qualified labels reuse storyTaskObject; the full latest scene must contain the exact accepted anchor quote, agree with its text on ONE label, and have every bare-object occurrence inside that same label. Unknown/unbound/other bare objects also block narrowing. Missing/edited quote/selected source, ambiguous names, unavailable IDs, reference-only/restart and incomplete whole budget retain fallback. Whole selection/omission/attempted/protected-set rollback; guard remains required. No pronoun binding, ownership/knowledge transfer/consent/permission/completion inference, schema/settings/model/provider/DB/canonical writes. Current historical IDs and original draft/source conditions remain. referenceRecall false/guard are private comparators; source title extraction is shared with natural recall.

Independent40 RUEN corpus: guard coverage0/20→20/20, whole source target sets0/6→6/6,20 exact controls. Initial21 failing assertions reproduced missing guards and wrong object recall.83 new unit cases pass; full/native/browser/package checks follow below. Core story-reference-recall/game-context/shared title helper; fixture/quality/reader/runtime/UI; OBJECT-REFERENCES.md. RP256–259 local work preserved, no push requested, main e8f5cba; personal world/installed copy untouched.

RP260 final QA:83 new unit cases; full249 files4838 passed/0 failed/5 prior todo; TypeScript/diff-check passed. Independent40 corpus guards0/20→20/20 and whole-target0/6→6/6 with20 exact controls. Broad browser88 passed/24 intentional installed-Firefox skips; separate new-only10 passed/2 such skips. Actual synthetic Edge RUEN POST/reload preserves41 accepted facts/frozen role seeds/episode-source order;19 explicit sends per locale, no extra tabs/errors. Both unresolved-personal guards and unique qualified source-owned task/code conditions appear on wire, full original draft retained. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and four screenshots inspected. Initial missing scaffold markers and one misplaced branch brace were fixed before broad checks; no source/evidence/budget/lifetime/identity/timeouts weakened. No canonical writes or extra model requests. Live account/model/Brave/full E2E not tested; own contexts closed.

Next corpus must also include two distinct objects with the same full literal label: a label is not an object ID. Current priority is candidate recall with a retained unresolved-reference guard, not disambiguation or a binding. Measure false priority separately before introducing object identity or widening grammar.

Next: evaluate RP-05 retrieval quality on a fixed mix of real-shaped long scenes before another grammar expansion; record missed evidence and false candidate priority separately. Personal/pronoun ownership remains unresolved locally; standalone deictic knowledge without an eligible title and arbitrary language remain open. RP-05–08/calendar/overdue/scale/live-model quality/old-chat rewind/UX onboarding/editors remain open. Do not redo RP239–260. Only3 canonical downloads; installed copies require manual update/reload.

RP260 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/578 entries and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff RP260. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads, no dated duplicates. Existing >500KB chunk warning remains RP-08. Installed browser copy was not replaced/reloaded automatically.

## Предыдущая точка RP259 Знания без открытого дела

story-lasting-recall.ts supplements existing balanced selection with whole accepted persistent knowledge and completed/cancelled task results, without requiring an open task title. Finite present/past query clauses reuse storyActionBalance; raw object tokens preserve stop-word/name barriers. Ordered one-clause text/title matching, no quote/key/claim-value tags. Persistent candidates retain frozen active speaker/believer + selected-source + lifetime proof; closed tasks require a bound active reporting speaker and selected source, never become open or persistent. Latest current compacted sources; recent anchor, cap8/full rendered budget and exact prior facts/counters/attempted/task/persistent-set rollback. No schema/settings/model/provider/DB/canonical writes; full draft/conditions/source identities remain. Local shared noun lexicon and ephemeral action.object only. Existing RP256–258 local work preserved.

Independent48 RUEN corpus16 positive/32 exact controls: baseline complete-target5/16→16/16. Before implementation14 assertions reproduced missing targets/anchor, no schema guards weakened. Initial cross-clause control used a legitimate bare object; corrected fixture now separates the qualified source terms across clauses, with expected guard unchanged. Final83 new cases pass; QA and package results below.

RP259 final QA:83 new focused unit cases pass; full247 files4749 passed/0 failed/5 prior todo, followed by6 additional passing cap/identity/stop-word cases (4755 distinct passing cases across these checks). Final TypeScript/diff-check and documentation7 pass. Independent48 RUEN whole-target5/16→16/16 with32 exact controls. Broad browser78 passed/22 intentional installed-Firefox skips; separate first new-only run10 passed/2 such skips. Synthetic Edge RUEN actual POST/reload preserves44 stored facts/frozen role seeds/source order,27 explicit sends per locale, no extra tabs/errors. Native ingestion starts with an open key duty, then accepts its completed result; status/quote/owner/source and persistent permission conditions remain whole. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe, four screenshots visually inspected. Production source/identity/lifetime/budget/timeouts unchanged. Initial runtime generation marker/type errors corrected in test scaffolding, no production guard relaxation. Live account/model/Brave/full E2E not tested; own contexts closed.

Concrete next task: prepare an independent RUEN corpus with two same-kind objects, renamed/deleted/replaced identities, and possessive/deictic references (её/этот, her/this). Compare current selection against fixed whole-source gold; unresolved referents must retain fallback. Identify a measured gap before changing retrieval; do not append another broad regex or infer possession/knowledge from a reporting speaker.

Next: independently measured broader phrasing and identity/pronoun comparison before widening lexical forms. No universal semantics, inferred object possession/knowledge transfer or guessed owner. RP-05–08 remain open, including calendar/overdue, scale/live-model quality, old-chat rewind and UX onboarding/editors. Do not redo RP239–259; personal lore/installed copy untouched. No commit/push requested; main remains e8f5cba. Only3 canonical archives.

RP259 packages: Chrome/Firefox/source ZIP entry-to-disk SHA25623/23/576 files and all3 canonical copies verified. Final source repacked after QA/package notes; first handoff section RP259. Source excludes private/test/.env/Git/node_modules/nested ZIPs; exactly3 downloads, no dated duplicates. Existing >500KB chunk warning stays RP-08. Installed browser copy was not replaced/reloaded automatically.

## Предыдущая точка RP258 Обычная речь и предметная память

Пользователь после RP257 уточнил ограничение2–3 действий и одобрил естественные формулировки/падежи/длинные сообщения. Добавлен story-natural-recall.ts после существующего balance, на тех же eligible frozen-owner/episode-source/lifetime candidates. Literal object labels извлекаются только из ограниченных явных task.title prefixes (goal.object теперь доступен как request-local field); query не парсится по количеству действий и не обрезается по длине. Whole per-object oldest duty before optional latest persistent details, recent anchor, cap8/rendered budget/exact rollback. Qualified longest-at-occurrence phrases suppress unrelated bare labels; stop words/names/clause boundaries cannot manufacture objects. Локальная таблица ключ/дверь/код forms, global stemming/data прежние. Conditions/negation remain full draft and original whole facts, never completion/permission/consent evidence. Pronoun owners/ambiguous names not guessed; historical/current scopes intact. No schema/settings/model/provider/DB writes. Supported legacy single goals/compound/single object syntax retain their own path and ablations.

QA: independent50 corpus18 positives/32 exact controls; actual baseline complete target recall7/18 (not0)→18/18. Preimplementation19 failed assertions reproduced missing targets/recent anchor; first metric assertion incorrectly assumed0 baseline, corrected to measured7 without changing gold.111 new unit cases, full245 files4672 passed/0 failed/5 prior todo, TypeScript passed. Source-title/query gap barriers, masked pronoun aliases, eight-object cap rollback, qualified labels, query/source order, immutable identity/quotes/status and valid-schema whole-budget tests included. RP258 final QA:111 new unit cases; full245 files4672 passed/0 failed/5 prior todo, TypeScript/diff-check. Independent50 corpus7/18→18/18 whole-target recall with32 exact controls, no changed gold. Browser68 passed/20 intentional installed-Firefox skips; synthetic Edge RUEN actual POST/reload retains45 facts/frozen role seeds/source order,22 explicit sends per locale, no extra tabs/errors. Four+ actions/>480-character input/conditions/negation sent verbatim, all conditional duties and persistent direct-speech quote/source IDs remain. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and4 screenshots inspected. First2 native failures came from a fixture without a parser-supported named knowledge quote; replaced with explicit named direct speech and added2 actual source-role grammar checks. Production identity/lifetime/evidence/timeouts unchanged. Prior compound runtime now explicitly expects supplemental object recall for conditional/multiline prose, with whole draft/quote/open statuses; old compound parser itself still rejects those forms. Live account/model/Brave/full E2E not tested; own contexts closed. Main module/game-context/goal.object; natural recall fixtures/unit/runtime/UI and NATURAL-MEMORY.md. Existing RP256–257 local changes retained; main still e8f5cba, no commit/push requested. Personal world/account/installed copy untouched.

Next: broader object recall from standalone lasting facts when no eligible open task remains, and independent identity/pronoun/semantic comparison corpus. Do not just widen regexes without measured gold/control cases. Current supplement still needs an eligible open-task title anchor; task-only prefix/noun table is not universal language understanding. Ambiguous owner/unknown-history reconstruction, local semantic quality, calendar/overdue, old-chat rewind, scale and live account quality remain open RP-05–08; UX onboarding/editors remain. Do not redo RP239–258. Only3 canonical downloads; installed copy needs manual update/reload.

RP258 packages: Chrome/Firefox/source ZIP SHA25623/23/574 entries match build/source bytes and all3 canonical copies. Final source repacked after QA/package notes, first handoff section is RP258. Private/test/.env/Git/nested ZIP exclusions verified; no dated duplicates. Existing >500KB chunk warning remains RP-08. User-installed extension not reloaded; update/reload remains manual.

## Предыдущая точка RP257 Составные игровые действия

После локально завершённого RP256 пользователь одобрил следующий участок. Новый story-compound-action.ts разбирает только2–3 finite first-person object actions или repair/return/delivery goal clauses (whole<=480,each<=240,object<=6 words), and/then/и/затем, whole asterisk wrapper. Known names masked before grammar; ordered significant object terms cannot join fields/clauses/names or lose duplicates. Every clause requires whole bound-owner/source-order open task or active accepted persistent speaker evidence; goals require matching title prefix. Recent anchor plus up to1 oldest source duty/1 latest persistent detail per clause, exact rollback of selection/counters if any clause fails. No I-owner/permission/execution/completion/calendar inference, no schema/settings/provider/model calls/canonical writes. Existing single action/goal paths unchanged.

Independent48 RUEN corpus16 positives/32 exact controls: complete-target recall0→16/16. Preimplementation17 real selection failures plus2 invalid terminal-fixture assertions; closed fixture corrected to event kind per existing schema, no product guard weakened. Targeted6 files340 pass and TypeScript pass. Final QA:113 new unit cases; full243 files4561 passed/0 failed/5 prior todo, TypeScript/diff-check. Independent48 complete-target0→16/16 with32 exact controls. Additional RUEN valid long>240 requests preserve all3 whole conditional duties; valid-schema whole-budget tests and duplicate/name/cross-field guards pass. Broad browser58 pass/18 intentional installed-Firefox skips; final rebuilt repeat46 pass/6 such skips after the newline-prefix guard. RUEN actual Edge POST/reload preserves43 stored facts/role seeds/source order,20 explicit sends per locale/no extra tabs/errors. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe and4 screenshots inspected. No product evidence/scope/timeouts relaxed; own contexts closed. Live account/model/Brave/full E2E not tested. Main new core/quality/parser/runtime/UI files and COMPOUND-ACTIONS.md. RP256 local changes retained; main still e8f5cba, commit/push not requested.

Next after QA: independent natural RUEN phrasing corpus (inflected short objects, richer explicit clauses, unsupported conditions/pronouns) before any parser/scorer expansion. Prefer measured gaps over another universal-intent claim; preserve whole-source/source-owner/budget/old-path controls. RP-05–08, semantic universality/calendar/overdue/live quality, historical old-chat rewind and UX onboarding/editors remain open. Do not repeat RP239–257; current handoff/home/day are authoritative. Own contexts only; personal world/account/installed extension untouched.

RP257 packages: Chrome/Firefox/source ZIP entry-to-disk SHA256 and canonical copies verified23/23/572 files; exactly3 downloads, no dated duplicates. Source includes final QA docs and COMPOUND-ACTIONS.md. Existing chunk-size warning stays RP-08; installed copy not updated automatically. Final source repacked after correcting the top handoff heading.

## Предыдущая точка RP256 Подбор нескольких дел по явной цели

После pull e8f5cba пользователь одобрил следующий RP-05 участок: несколько старых обязательств при ясной цели/предмете. Добавлен локальный story-task-goal.ts поверх существующих role/source/scene guards. Finite repair/return/delivery RUEN declared-goal/continue/first-person forms; literal ordered object prefix в заголовке open task, минимум2 eligible bound-owner+episode-source tasks. Oldest/newest source samples reserve up to2 whole duties alongside current anchor; no urgency/date/ownership/fulfillment inference. Unknown/one-task/unsupported/quoted/conditional/compound/foreign/restart/reference-only keeps exact old path. No settings/provider/model request/schema/canonical writes. Матч не соединяет разных объектов, clauses или masked names; исходный title/quote не режется.

QA RP256: independent48 corpus24 positive/24 exact controls, complete-target recall0→24/24,106 новых unit cases. First preimplementation run25 failures reproduced starvation; targeted6 files312 pass, final full241 files4448 pass/0 fail/5 прежних todo, TypeScript/diff-check passed. Additional negative test caught cross-object token matching, fixed to ordered literal prefix; oversized-anchor fixture initially invalidated its own old source proof and was reseeded for all full anchor quotes, exact rollback assertions unchanged. Browser48 passed/16 intentional installed-Firefox skips: Edge synthetic RUEN actual next POST/reload has whole old promise/new plan with conditions, frozen IDs and exact source;32 stored facts/role seeds/source order unchanged,17 explicit sends per locale/no extra tabs/errors. Prior action/topic/compact transport/roles/paraphrase/late/time runtime regressions retained. Chromium/Firefox RUEN320/900 keyboard/overflow/scoped Axe и4 goal screenshots просмотрены. First browser failures were test-only24-fact page assumption and duplicate CSS-class selector; all new batch records and whole stored library are now checked without product guard changes. Chrome/Firefox/source canonical ZIP SHA25623/23/570 entries-to-disk/copies verified; final source includes QA notes. No dated copies; chunk warning remains RP-08. Live account/model/Brave/full E2E not tested. Main files: story-task-goal/game-context/story-action-balance helper, tests/fixtures/e2e; manual TASK-GOALS.md. User data/installed copy untouched, own contexts closed. Commit/push не запрошены.

Следующий участок после итоговой QA: длинные и составные игровые действия/цели по независимому RUEN corpus и строгому сохранению условий/владельцев/источников/бюджета. Не включать protection lanes для любого текста; нынешние3 группы/короткий literal object не universal intent parser. Несколько совпадающих задач внутри одной source tie и oversized whole evidence требуют честных limits, не обрезки цитат. RP-05–08/semantic retrieval/calendar/overdue/live model quality остаются открытыми. RP239–256 не повторять; использовать верхний handoff и HOME-CODEX-NEXT.md.

## Предыдущая точка RP255 Исправления подготовки изображений

Публикация RP255: пользователь явно запросил push в main. В этот коммит входят оба исправления изображений, проверки, документация и три актуальных архива. Раздел диагностики ниже — исторический; перечисленные там ошибки уже исправлены в RP255. Следующий Codex не должен повторять эту реализацию; для продолжения работы сначала сверить текущий Git и следующий участок roadmap.

Пользователь после push74942ec явно разрешил оба image fixes. Legacy main draft guard снят только у illustration flow, не у native askSelfie/runService; все scope/busy/reply guards остаются. Scoped DR_IMAGE_BUDGET проверяет owned preparing attempt, читает trusted selected settings/catalog и возвращает только generate/edit numeric caps. Preparing catalog failures сохраняют provider/models diagnostic и не превращаются в ложную DeepSeek/plan ошибку. Ограничение передаётся imagePlanInstruction; не требует нового user click или отдельного paid request.

Venice same-ID mode caps не теряются при merge. PlanImageInput по необходимости меняет только собственный explanatory boilerplate; selected canonical/scene/appearance/action/position/style/reference context values/IDs/references прежние. Full prompt checked before provider.generate/edit in ImageJobs.run against actual reference mode/current or frozen model. No blind slicing/user-data rewrite/dropped cast/automatic paid retry. Oversized protected descriptions fail locally with safe model/length/limit counters, RU/EN wording and clear no-generation-request details. Catalog metadata unavailable for OpenAI-compatible adapter stays unknown, not guessed; existing12000 guard still applies.

Main files: core/image-prompt-budget, image-plan/generation/diagnostics/i18n/messages; storage/image-jobs, native provider/background handler, content illustration callbacks and ImageErrorDetails. New tests image-prompt-limit/image-prompt-budget-core, diagnostic regressions and e2e image-prompt-limit/fixture. Full239 files4342 passed/5 prior todo and TypeScript pass; first mocks reproduced the old paid-call failure. Final browser/archive completion in ROADMAP. No live API/paid generation/personal extension/world/Brave touched. RP255 follows74942ec and is included in the user-requested publication. Do not repeat RP248–254. Next memory priorities still multiple old obligations/longer syntax; review image limits edge cases before widening automatic rewriting.

Final browser72 passed/2 intentional installed-Firefox skips on packaged Chrome. RU/EN real MV3 click with unsent main draft completes isolated field worker/correct1500-budget prompt/owned deletion/one multi-edit with two references; exact source scene in paid mock body and no source service rows in main. After reload a second Create with long protected style fails locally; numeric actual edit cap/length remains after another reload, mock image POST count stays1 and composer untouched during both preparations. Prior group2/6/preset/age/isolated worker/evidence/intervention/privacy regressions retained. RU/EN320/900 Chromium/Firefox keyboard/Axe/overflow and4 final screenshots inspected; selected-model label does not imply a POST happened. Initial fixture errors (catalog not mocked, evaluate closure, floating-panel overlap, invalid panel→content RPC) corrected in tests only; no production timeout/ownership/evidence relaxations. All contexts closed. Unknown caps/old model aliases/real model interpretation are not promised; new runtime metadata reads are not paid generation retries. Final packages in current roadmap.

RP255 packages: final Chrome/Firefox builds and3 canonical ZIPs, exact SHA25623/23/568 entry-to-disk/copy audit; source has current QA/handoff/home/day/readme/new guide, private/test/.env/Git/node_modules/nested ZIP exclusions remain. Source document entries refreshed after final notes. No dated archives or user-install reload; chunk-size warning remains RP-08. Full239 files4342 pass/5 prior todo and final TypeScript/diff-check. The user requested publishing these packages with RP255. Next: user tests updated Chromium package; do not claim live model quality from mocked image generation.

## Историческая диагностика изображений перед push74942ec

Пользователь запросил push текущей работы RP248–254 и актуальных пакетов в main. Функциональных изменений после финальной RP254 QA нет. Диагностика следующих двух ошибок не является их исправлением; пользователь пока не дал отдельного указания реализовать предложенные изменения.

`draftBusyImage`: checkIllustrationScope в src/entrypoints/content.tsx блокирует любой непустой основной draft, хотя generateCharacterText уже вызывает generateIsolatedCharacterText и отдельный служебный чат. Это устаревшая блокировка для иллюстраций; не снимать guards чата/мира/генерации и не переносить разрешение на askSelfie/runService, которые действительно пишут в основной composer. Черновик пользователя нельзя стирать, отправлять или заменять без его действия.

HTTP400 `/image/multi-edit`, `qwen-edit-uncensored`: API сообщил prompt limit1500. Каталог Venice считывает constraints.promptCharacterLimit в ImageModelInfo.promptLimit, но поле дальше не применяется. planImageInput собирает scene, canonical appearances, cast/reference instructions и style, проверяя только общий12000; ImageJobs.run передаёт input.prompt без модельного preflight. Другая generate-модель не заменяет выбранную edit-модель при приложенных references. Repeat хранит exact frozen old request и не сокращает его. Предложено учитывать лимит фактически выбранной модели при подготовке/проверке полного prompt, без обрезки сохранённых анкет и без автоматического повторения платного запроса. Это не реализовано.

Read-only QA диагностики:73 existing tests image-api/image-plan/image-diagnostics прошли; live API/платная генерация не вызывались. Официальный per-model контракт: https://docs.venice.ai/api-reference/endpoint/image/multi-edit. До реализации нужна отдельная команда пользователя; если она будет, сначала подтверждённый failing mock/corpus, затем RU/EN/черновик/model budget/reference/replay guards и новые пакеты. Последняя готовая реализация — RP254 ниже, не считать image errors закрытыми.

## Архивы после очистки 14 октября 2026

По просьбе пользователя в downloads оставлены только три актуальных архива: deeprole-0.1.0-chrome.zip (основная сборка для Brave/Edge/Chrome), deeprole-0.1.0-firefox.zip и deeprole-0.1.0-sources.zip. 48 датированных снимков и дубликатов отправлены в Корзину; упоминания этих путей в исторических разделах ниже больше не являются ссылками на доступные загрузки. downloads/README.md указывает только существующие пакеты. В следующих итерациях обновлять три основных архива, не создавать браузерные/датированные дубликаты без отдельной просьбы пользователя. Установленное расширение, профили браузеров и игровые данные не затронуты.

## Предыдущая готовая точка — RP254, память коротких игровых действий

Запрос пользователя: подбор для «Я открываю дверь», не только «Продолжай». Finite single first-person RU/EN actions/gestures, optional whole asterisk wrappers; no arbitrary intent/third-person/pronoun owner/quoted/compound/conditional grammar. Object terms must all occur in one full text or task title; quote/key/value/status is not object proof. Request-local WeakMap invalidates text/title edits. Supported gesture with known unambiguous address uses existing reference guard; I does not infer a player/owner ID.

RP252 source-bound candidates reused under previous world/story/restart/reference/owner/topic guards. Current-context anchor retained; object actions also reserve a whole matching target and filter protected lanes to that object. At most one matching open task and one persistent fact, frozen promisor/planner/speaker/believer ID plus selected episode/time proof. Source order is not importance/urgency, recipient is not owner, source speech is not objective knowledge/consent. Whole-budget rollback restores exact prior selection/counters when no extra proven lane fits; cap8/required/manual lore/transport unchanged. No canonical writes/schema/migration/new setting/provider/model call. Unsupported drafts keep memory, not memory-off.

Independent fixed48 synthetic RU/EN examples:24 positives with three settings (door/airlock/chest),20 newer related conversations and100 other promises;24 exact fallback controls. Full target-set recall0→24/24.126 new unit cases (116 action/quality,8 explicit sequence/condition guards,2 UI label regressions), including actual source-role V1 grammar, identity replacement/rename, terminal task/quote/lifetime/source/restart/foreign/2000 and overflow guards. Initial typecheck caught an unused test import; removed. Initial focused8 files/415 passed. Final TypeScript/full237 files4310 passed/0 failed/5 прежних todo. UI copy now «Незавершённые дела»/«Open tasks and promises», not an inaccurate claim that protected tasks never directly match. It follows UX-copy/i18n guidance without new UI controls.

Browser38 passed/14 intentional installed-Firefox skips in final regression suite: actual installed Edge synthetic RU/EN POST/reload,20 explicit sends, old full conditional promise/persistent direct-speech quote/source IDs/time statuses retained, DB/factRoleSeeds/episodeSources unchanged and no extra tabs/errors. Topic/owner/unknown/unsupported controls and previous relevance/transport/role/alternative/paraphrase/late/lifecycle passed; RU/EN320/900 Chromium/Firefox keyboard/overflow/Axe and4 updated-label screenshots inspected. First run37 pass/1 failed revealed a false assumption about preexisting Russian stemming: «коде» does not match short «код». Natural «Напомни код» is now the supported-topic assertion and the old inflected fallback is separately asserted; global stemming not changed. No production evidence gate or timeout weakened. Final packaged repeat and exact ZIP audit read current roadmap; live account/model/Brave/full E2E not tested. All own test contexts close in finally.

Main files: src/core/story-action-balance.ts, game-context.ts; tests/story-action-balance/quality, fixtures/story-action-quality, e2e/story-action-runtime and context-budget-ui/fixture. Guide docs/ACTION-MEMORY.md, continuation guide updated. Do not repeat RP239–254. Next independent work: goal-linked task priority/older-task starvation and long/compound narrative syntax, with measured gates and whole-source budget. RP-05–08, arbitrary semantics/calendar/expiry/overdue/native context/live quality stay open. Personal installed extension/world/account not changed, commit/push not requested. Keep only three canonical downloads, no dated copies.

Final package verification: Chrome rebuild after all8 condition/sequence guards then repeated26 action/UI browser passes/2 intentional installed-Firefox skips. Chrome/Firefox/source archive SHA25623/23/566 files exactly match disk and3 canonical downloads. Source excludes tests/private-assets/.env/Git/node_modules/nested ZIPs and includes final handoff/roadmap/home/day/readme plus ACTION-MEMORY/core. Only3 canonical packages remain; no dated copies. Build chunk-size warning remains RP-08; installed user copy is not automatically updated. Final full237 files4310 pass/5 prior todo and TypeScript/diff-check pass. Existing RP248–253 changes retained.

## Предыдущая точка — RP253, исправление подготовки полного сброса

Пользователь показал reset service window с неверной плашкой «Подготовь персонажей по лору» и invalid-result/$/complete valid JSON object; исходный ответ не приложен, точную синтаксическую причину не утверждать. Добавлены reset-specific RU/EN copy, pre-claim query mode и text-free reload marker; verified claim выбирает mode, не получает полномочия из URL. Native prompt/reasoning/reply по-прежнему скрыты, DOM/cleanup ownership сохраняются.

Legacy reset batches получают следующий exact existing ID/name, а не discovery/new keys. Проверяются next roster и полное совпадение ранее подготовленных лиц; локальная очередь, не more модели, определяет конец. Одно/старое two-person ограничение сохраняется. Large reset prompt получает текущую цель, не первый ID снова. Checkpoint/interrupt используют тот же guard. JSON не дописывается автоматически и цитаты не угадываются.

Reset entry correction раньше получала profile hints и не включала их в запрос. Теперь отдельные fixed decisions hints, schema/language/escaping и одна попытка на этап; complete fenced JSON unwrap без исправления данных, incomplete/multiple/foreign/partial edits отвергаются. Invalid JSON даёт bounded structured diagnostic. Main reset UI объясняет неудачную проверку и считает исходные состояния. Два подтверждения, atomics, stale guards, portraits/lore/archive защиты не менялись. Личный мир не сбрасывать.

QA: TypeScript/diff-check pass, full235 files/4184 passed/5 прежних todo,17 новых unit cases. Первый concurrent full unit дал один 5s timeout старого portrait-action-search RU, полный повтор с двумя workers прошёл. Browser50 разных случаев прошли суммарно в исходном и повторном прогонах,8 intentional installed-Firefox skips; сначала4 reset-ready и1 cleanup ожидания истекли при нагрузке, после тестовых deadlines60/30s все6 installed synthetic RU/EN normal/profile+entry repair/failure прошли. Production deadlines не менялись. Подтверждены masked popup, correct decisions correction, complete fenced JSON, сохранение одной готовой starting state после двух malformed replies, закрытие своего чата, отсутствие POST/reset до двух подтверждений, atomic reset/fresh actual POST/backup/portraits/foreign world/source draft protection. RU/EN320/520 keyboard/overflow/Axe,4 reset-service screenshots просмотрены. Собственные contexts закрыты; live account/model/личный Brave не проверялись.

Chrome/Firefox/source пакеты пересобраны; SHA256 сверены все23/23/564 entry-to-disk и три canonical copies. Финальная Chromium-сборка ещё раз прошла все6 installed synthetic reset scenarios (1,9m). Обновлены только downloads/deeprole-0.1.0-chrome.zip, downloads/deeprole-0.1.0-firefox.zip и downloads/deeprole-0.1.0-sources.zip, без новых датированных копий. Installed user copy не обновлялась. Chunk warning остаётся RP-08; commit/push не запрошен. После проверки пользователем следующая memory-задача прежняя: independent ordinary-action RUEN corpus, не включать balance для произвольного текста. RP253 не реализует её.

Дополнительный вопрос пользователя: почему два сброса. Объяснены различия saved-start restart и пересмотр стартовых значений/очистки по лору; обе функции оставлены, поскольку просьбы удалить или объединить не было. Можно предложить один вход с выбором сценария, без изменения destructive contract.

## Предыдущая точка — RP252, source-bound память короткого продолжения

После «дальше» реализован bounded unquoted short continuation balance: recognized RUEN phrases после mask известных имён, не arbitrary intent/action parser. Anchor выбирается по прежнему recent-context score/source order/index, не по имени в текущем draft. До одного fitting open task и одного persistent detail защищаются до остальных optional rounds. Нужны exact frozen source roles, available current-world ID и verified selected source position; task owner=promisor/planner, не recipient. Persistent требует accepted timeStatus:persistent и related speaker/believer, не утверждает objective truth/epistemic transfer. Latest recorded source (не matching digit/urgency/deadline) выбирает защищённое дело/сведение. Whole budget/metadata и текущий cap8 прежние. Без дополнительной fitting lane факты/счётчики откатываются к EXACT RP251 admission; pinned/required данные не режутся. Никаких canonical writes, новых source-role grammar/migration/provider/model calls/UI settings.

Current IDs: explicit scene/partners/player/focus/query; без scene/focus — unique recent references только для contextual ranking, не physical presence. Unknown/ambiguous/quoted/action/owner/topic requests, reference-only service, absent game/scope и restart сохраняют прежний путь. Completion/cancel/correction/replace применяются canonical compaction; время не закрывает дела, новый персонаж с тем же именем не наследует ID. Optional derived persistentFacts counter объясняет lasting lane в прежнем RUEN ContextBudgetSummary и не входит в stored/proposal schema. Unrecognized «Я открываю дверь» пока не включает баланс. Original narrator-only knowledge без frozen speaker/believer остаётся обычным fallback, не получает guessed owner.

QA: independent fixed48 RUEN corpus с тремя vocabulary settings,24 positives/24 exact controls; full needed-set recall0→24/24. Cases:20 newer noise,100 other obligations, named continue/focus-other, current anchor+owned promise/plan+lasting conditional quote.84 новых unit/quality/guard/UI cases; final TypeScript/diff-check pass, full234 files/4167 pass/0 fail/5 прежних todo. False generic framing и coincidental document/conversation number исправлены recent-anchor/source-order выбором; фактическая speech grammar проверяет fixtures. Unknown sources/quotes, empty scene, same-name replacement/rename, terminal tasks/reclassified knowledge, whole-budget rollback/2000 и quoted-after-address/O'Connor checked. RP249 mixed-eight payload metrics/RP25048 recall/RP25148 admission benchmarks unchanged.

Final browser38 pass/14 intentional installed-Firefox skips. Installed Edge synthetic RUEN four captured replies/25 source proposals/current24 facts: latest review UI24 не library cap, all new batch proposals и all20 noise/old topic/knowledge сохранены. Actual POST/reload для Continue передаёт latest noise anchor, old open gate с точным promisor ID и full condition, old persistent quote с speaker ID/timeStatus. Owner/topic/compound/unknown regressions retained,16 explicit POST/no extra tabs/errors и unchanged DB/factRoleSeeds/episodeSources. Previous episode/time/roles/alternatives/paraphrases/late evidence/lifecycle/transport passed. Chromium/Firefox UI RUEN320/900 keyboard/focus/overflow/scoped Axe;4 continuation screenshots просмотрены. Все собственные contexts закрыты. Live model/account/installed Brave/full E2E не проверены.

Chrome/Firefox/source ZIP SHA25623/23/564 entries и canonical copies сверены; актуальны downloads/DeepRole-Brave-continuation-memory-20261014.zip и идентичный Edge archive. Финальный source включает QA/передачу; old dated packages сохранены, private/test/lore/photo exports excluded. Installed user copy автоматически не обновляется, chunk warning/RP-08 остаётся. RP248–252 локальные поверх main7a9dd3c; commit/push не запрошен. Manual CONTINUATION-MEMORY.md; HOME-CODEX-NEXT/day log2026-10-14 актуальны.

Следующий RP-05 участок — independent RUEN corpus обычных игровых действий без control phrase: «Я открываю дверь», «Я киваю», «I nod», quoted dialogue/unknown, several active owners, explicit object/owner/compound queries и tight whole budget. Измерить пропуски accepted open/lasting facts и влияние на прямые вопросы; подключать balance только при доказанно безопасном query path, не угадывать arbitrary intent/owner/urgency. Нельзя просто включить нынешние lanes для любого текста или рассылать все задачи. Goal-linked task ranking и starvation older tasks также не решены; latest protected source не означает narrative importance. RP239–252 не повторять. Heavy/external provider/второй канон молча не добавлять. RP-05–08/live/arbitrary semantics/calendar/expiry/overdue остаются открытыми; historical identity repair/old-chat rewind/UX02 отложены.

## Предыдущая точка — RP251, меньше посторонней памяти в тематическом запросе

После «дальше» добавлен осторожный topic admission поверх RP250. Только bounded explicit information-request prefix, все meaningful terms существуют в full text/title, хотя бы один distinguishing term, нет recognized action/owner/reference uncertainty. Tentative whole topical facts резервируются до optional rounds; actual budget/cap8 должны покрыть ВСЕ requested terms. При missing coverage selected facts и omitted counters сбрасываются и запускается EXACT prior admission. Open tasks, совпадающие даже по общему слову темы, остаются кандидатами. Обычное продолжение/повествование/unknown/ambiguous/pronoun/owner/action requests сохраняют прежний подбор. Required/manual lore не режется; canonical facts/источники/status/time/IDs/roles/RP249 transport не переписываются. Extra calls/provider/UI controls/schema changes нет.

Independent fixed48 RUEN admission cases (four thematic vocabularies):24 positives/24 exact fallback controls.192→32 selected records, complete requested-target recall20→24/24. Для20 запросов, уже содержащих все нужные данные, суммарная full added prompt длина77450→56353 characters (-27,2%); четыре English compound cases с исправлением прежнего пропуска не входят в same-needed-data size subset. Это bounded lexical/synthetic quality, не native tokens, live model или universal semantics. Весь48 corpus валиден по accepted fact schema, включая oversized-budget sources≤2400.

QA:71 новых unit/quality/guards cases, focused273/7 files, final TypeScript/diff-check pass, full232 files/4083 pass/0 fail/5 прежних todo. Valid oversized and required-overflow/cap9→8 rollback, quote/keys/values не topic proof, current frequencies/masks/edits, common-topic open tasks, latest claim replacement и manual lore/2000 budget проверены. Final browser22 pass/14 intentional installed-Firefox skips. Installed Edge synthetic RUEN четыре captured replies/open→completed task/отдельное условное обещание/20 newer noise; single1/compound2/owner+unknown+continuation8 selected facts в actual next POST/reload. Quote/kind/status/source ownership и DB/role seeds/source chronology unchanged,16 explicit POST/no extra tabs/errors. Прежние transport/episode/roles/alternatives/paraphrases/late evidence/lifecycle regressions passed. Chromium/Firefox UI RUEN320/900 keyboard/focus/search/overflow/Axe;4 screenshots просмотрены. Все собственные contexts закрыты; личный аккаунт/Brave/live model/full E2E не проверены.

Chrome/Firefox/source ZIP SHA25623/23/562 entries/canonical copies сверены; актуальны downloads/DeepRole-Brave-focused-memory-20261014.zip и идентичный DeepRole-Edge-focused-memory-20261014.zip. Source ZIP включает финальную QA/передачу; прежние dated packages сохранены, private/test/lore/photo exports исключены. Installed user copy автоматически не обновляется; chunk warning остаётся RP-08. RP248–251 локальные поверх main7a9dd3c; commit/push не запрошен. Manual MEMORY-TOPICS.md, HOME-CODEX-NEXT.md и day log2026-10-14 обновлены. Начальный esbuild Windows TEMP error обойдён отдельным ignored .wxt/rp251-build, чужой Temp не чистился.

Следующий RP-05 участок: independent RUEN quality corpus баланса обычного продолжения. Initial TDD показал прежний пропуск open gate task: admissionWorld, draft «Продолжай»/«Continue», recentMessages=[последняя noise.text], old gate перед20 noise records → восемь похожих разговоров могут вытеснять дело. RP251 сохраняет этот fallback, не исправляет его; его контроль с recentMessages=[gate.text] удерживает open task/latest scene. Измерить недавнюю сцену/важное длительное знание/подтверждённые незавершённые задачи, completion/cancel/conflict/unknown/budget границы, затем исправлять доказанные пропуски. Не отправлять все задачи каждый ход, не угадывать urgency/owner/calendar/fulfillment, не резать source proof. RP239–251 не повторять; heavy/external provider и второй канон молча не добавлять. RP-05–08/live scale/arbitrary semantics/conditions/calendar/overdue открыты; old-chat rewind/historical identity repair/UX02 отложены.

## Предыдущая точка — RP250, подбор памяти по конкретной теме

После «ДАЛЬШЕ» исправлены два измеренных пропуска: нужное слово в полном fact.text вне прежней короткой поисковой проекции и предмет завершённого дела в полном task.title. Scoped rank получает ограниченный дополнительный topic score до32; known names, query framing и recognized actions-before-stemming не усиливают его. Частоты отличительных слов пересчитываются по текущим compact accepted facts. Явные source-bound owner questions сохраняют прежние scores/order; legacy standalone ranking не изменён. Generic RUEN continuation («продолжай»/«continue») не получает новый тематический бонус. Кэш хранит только query-independent text/title tokens с invalidation по текстам и name masks, никогда selections/owners/status/источники.

Canonical facts, цитаты, условия, виды, task/time statuses, IDs/role bindings и RP249 compact transport прежние. Никакого inference, нового канона, extra model call, provider, migration или UI knob. Fixed independent48 RUEN cases из шести тематических словарей с manually specified gold: first candidate и actual requested-memory recall24→48/48. Это проверка двух механизмов и owner/secret controls, не универсальное понимание любых слов/сеттингов. Нерелевантный actor/framing/fallback хвост ещё может занимать свободные места.

QA:79 новых unit/quality cases; final TypeScript/diff-check pass, full230 files/4012 pass/0 fail/5 прежних todo. Контроли whole body/title, names/framing/actions, unknown/ambiguous, opaque keys/quote/value, common/repeated terms, edits/subset/cache/current frequencies и2000 newer records в2000 budget. Прежние source-owner/paraphrase/transport regressions сохраняются. Final browser22 pass/14 intentional installed-Firefox skips. Installed Edge synthetic RUEN: четыре bounded captured replies, open→completed task и20 newer framing records; actual next POST/reload возвращают старые body/title topics первыми, сохраняя whole quote/kind/status/source order и unchanged DB/seed values;8 explicit POST/no extra tabs/errors. Mixed transport/roles/alternative/paraphrase/late-evidence/lifecycle regressions passed. Chromium/Firefox UI RUEN320/900 keyboard/focus/search/overflow/Axe;4 screenshots просмотрены. Все собственные browser contexts закрыты. Живой аккаунт/модель/full E2E и установленный Brave не проверены.

Chrome/Firefox/source ZIP SHA25623/23/562 entries и canonical download copies сверены. Актуальны downloads/DeepRole-Edge-memory-topics-20261014.zip и идентичный Chromium archive downloads/DeepRole-Brave-memory-topics-20261014.zip. Финальный source ZIP включает handoff/QA. Старые dated archives сохранены; private/test profiles/lore/photo exports исключены. Chunk warning остаётся RP-08, installed user copy автоматически не обновляется. RP248–250 локальные поверх main7a9dd3c; commit/push не запрошен. Manual docs/MEMORY-TOPICS.md; HOME-CODEX-NEXT.md и day log2026-10-14 актуальны.

Следующий RP-05 участок: отдельный independent RUEN admission corpus для нерелевантного хвоста после найденной конкретной темы. Включить exact topics, владельцев/compound requests, «продолжай», unknown и oversized target; ограничивать хвост только при доказанном тематическом сигнале, не лишать обычную игру недавней памяти/открытых дел и не ломать whole budget/source/status/scope guards. Live-model interpretation компактной легенды проверять отдельно после обновления пользовательской копии. Не подключать heavy/external provider молча; не сохранять второй канон/резать источники ради метрики. RP239–250 не повторять. RP-05–08, arbitrary semantics/conditions/calendar/overdue и scale/live quality открыты; old-chat rewind/historical identity repair/UX02 отложены.

## Предыдущая точка — RP249, компактная передача памяти DeepSeek

По одобрению пользователя реализован обратимый request-local transport поверх прежнего wire, включая существующее exact quote sharing. Новые опциональные value/title refs выбирают точный text или resolved quote той же записи; roles/episode refs копируют более раннее полное поле этого массива; person roleRef копирует ранее указанное полное лицо в том же sourceRoles. Никакой нормализации, угадывания, cross-request refs или второй writable memory. Каждый кандидат проходит strict decode и exact comparison со всеми прежними hints. Conflicts/forward/chained/missing/unknown/inherited-required refs отклоняются. Исторические ID/names/merge/unavailable metadata, kind/task/temporal semantics и цитаты сохраняются.

Unified compiler сравнивает варианты по полной добавке с инструкциями, лором/профилями, required suffix, continuation и легендой. Требуется выигрыш минимум32 настоящих символа и8 локально оценённых токенов; Cyrilllic-ratio meter оплачивается целиком. Иначе прежний формат. Standalone/legacy wire не изменён; legacy compiler option — внутреннее средство сравнения, не настройка пользователя. БД/backup/fact proposals/schema/ранжирование/автоматические safety gates прежние. Новых model calls/provider/migration/UI controls нет. UI-текст RP248 не дублируется в запросе.

QA:96 новых unit/quality/transport cases, fixed RUEN48 corpus и два independent mixed eight-fact scenarios. Полная добавка RU9675→8550 символов (-11,6%), EN9885→8698 (-12,0%); local estimates2423→2142/2476→2179. Все8 тех же selected records восстанавливаются точно. Это не native tokenizer usage, не обещание процента для любого лора и не удаление server transcript. Case coverage: malformed targets/enum/own fields, complete historical metadata, sourceQuote-after-sharing, whole-budget fallback/admission, reorder/subset/edit, non-Latin/combining marks/emoji/delimiters и1000 stored facts, input immutability.

Final TypeScript/diff-check pass; full228 files/3933 pass/0 fail/5 прежних todo. Final browser20 pass/12 intentional installed-Firefox skips: Edge synthetic mixed scene через actual XHR→review→next POST/reload, exact eight restored facts/conditions/open vs completed/ended/belief/source lineage, unchanged DB/seed values,3 explicit POST/no extra tabs/errors. Четыре uncertain details подтверждались через настоящую review queue, а не обходились; source-policy guards не ослаблены. Старые roles/rename/alternative/paraphrase/late evidence и promise→completion/conflict-resolution regressions тоже прошли. RUEN320/900 Chromium/Firefox keyboard/focus/search/overflow/Axe;4 screenshots просмотрены. Initial fixture неправильно ожидала review proposals в saved-only list и fixed native parent; подготовка исправлена. Старые RP04 wording asserts обновлены к RP245 temporal policy; их поведенческие checks сохранены. Живой аккаунт/модель/full E2E не проверены.

Chrome/Firefox/source ZIP SHA25623/23/560 entries и canonical download copies сверены; актуален downloads/DeepRole-Edge-compact-memory-20261014.zip. Финальная source упаковка включает QA/handoff. Старые dated archives сохранены, private/test profiles/lore/photo exports не упакованы. Chunk warning остаётся RP-08; installed user copy не обновлялась. Собственные browser contexts закрыты. RP248 и RP249 — локальные изменения поверх main7a9dd3c; commit/push не запрошен. Manual docs/COMPACT-GAME-MEMORY.md; current day log docs/HANDOFF-2026-10-14.md и HOME-CODEX-NEXT.md.

Следующий RP-05 участок: независимый расширенный RUEN corpus качества подбора памяти разных сеттингов, измерить пропуски важных условий/задач/владельцев и исправлять доказанные retrieval ошибки. Понимание новой транспортной легенды оценить отдельно по реальному прогону пользователя после обновления установленной копии. Не подключать heavy/external provider молча; не сохранять второй канон или резать цитаты ради метрики. RP239–249 не повторять. RP-05–08, arbitrary semantics/conditions/calendar/overdue и scale/live quality открыты; old-chat rewind/historical identity repair/UX02 отложены.

## Предыдущая точка — RP248, связный текст памяти с точными источниками

Продолжение после pull main7a9dd3c (merge PR1, RP239–247). По следующей задаче передачи добавлен read-only source-backed narrator в существующие эпизоды. Он использует целые точные цитаты принятых актуальных фактов; отображает вид, подтверждённый task status и отдельное временное уточнение. Связки описывают порядок записанных реплик, не причинность/календарь. Frozen roles копируются только по точному fact/source/quote proof; неизвестное не угадывается по современному roster. Связь [1] раскрывает исходную цитату и переносит фокус. Поиск/alternative/progress/rejection/undo/new-game пересчитывают view без второй writable memory.

Краткое отображение допускает шесть целых фрагментов и1800 символов, явно сообщает пропуски; полный список ниже не обрезается. Это лимит UI, не библиотеки. Canonical facts, лор, возраста, изображения, запросы модели и outgoing format прежние. Дополнительных model calls/migration/provider нет. RP248 улучшает чтение и фиксирует контракт, но не реализует экономию контекста и не является свободным генеративным пересказом.

QA:63 новых unit/quality/UI cases; независимый фиксированный corpus48 RUEN scenarios.14 специально заданных важных фрагментов теперь видны без раскрытия цитат; раньше они уже хранились в полном источнике, но не были в кратком fact.text. Общий unit227 files/3837 pass/0 fail/5 прежних todo, TypeScript/diff-check pass. Browser14 pass/6 intentional installed-Firefox skips: Chromium/Firefox RUEN320/900, keyboard/focus, search/empty/overflow/Axe;4 screenshots просмотрены. Installed Edge synthetic RUEN memory→UI citation→actual next POST/reload сохраняет conditional open promise, ended property, temporal/source metadata и неизменные saved facts;4 explicit POST/no extra tabs/errors. Прежние source-role/alternative/paraphrase installed regressions тоже passed. Живой аккаунт/модель/full E2E не проверены. Initial focused failures исправляли corpus count и test matcher для trailing whitespace; production evidence guards не ослаблялись. Отдельная проверка защищает lasting belief от превращения в факт через temporal label.

Chrome/Firefox/source ZIP SHA25623/23/557 files и canonical copies сверены; актуален downloads/DeepRole-Edge-narrative-memory-20261013.zip. Финальная source упаковка включает QA/handoff. Старые архивы сохранены, личные данные и тестовые профили не упакованы. Chunk warning остаётся RP-08; installed user copy не обновлялась. Все созданные тестами браузерные контексты закрыты. Commit/push этой итерации не запрошен; изменения локальные поверх main7a9dd3c. Основные файлы story-narrative.ts/story-narrative-i18n.ts/StoryEpisodePanel; manual docs/NARRATIVE-SUMMARIES.md.

Следующий RP-05 участок: сравнить компактные варианты сериализации исходной памяти для модели на том же RUEN corpus, измерить весь request budget и точность источников/условий/видов/ролей/task statuses. Не добавлять этот UI-текст поверх тех же фактов и не обрезать цитаты ради показателя. Подключать новый формат только с проверенными бюджетными регрессиями; исходные записи прежние. RP-05–08 остаются открытыми: arbitrary semantics/conditions/calendar/overdue, масштаб/live model quality; old-chat rewind/historical identity repair/UX02 отложены. RP239–248 не повторять. docs/HOME-CODEX-NEXT.md — актуальная передача.

## Предыдущая точка — RP247, полный сброс мира по исходному лору

Пользователь запросил подготовленный сброс всего лора с двумя подтверждениями, сохранением семьи/исходной любви, внешности/характера/изображений и передачей домашнему Codex. Реализован отдельный reset cast job: исходная точка пользователя, по одному существующему персонажу в ответе, затем по две записи/ограниченные фрагменты для удаления только сыгранных добавлений. Точный состав/ID обязателен. Частичные или неопределённые записи сохраняются; описание мира может только переписываться. Определения шкал/условия отношений/главный герой сохраняются кодом, модель предлагает только начальные значения. Никакого глобального zero/strangers и автоматического сброса без человека.

UI WorldResetSetup RUEN: исходная точка, прогресс, отмена/очистка временного чата, редактируемый просмотр с прежними значениями/цитатами/JSON, первое подтверждение плана, отдельное второе с точным названием мира. Действия только из extension page; frozen token и полный fingerprint мира проверяются перед атомарной транзакцией. Старый game и изменённые тексты/начальные поля архивируются без копии фотографий. Новая игра очищает facts/time/episodes/queues/overrides/history/locks; approved merges/identity seeds/images сохраняются, goals/background epochs меняются. Late old-game proposals не применяются.

Снимок с resetGameId открывает чистый native chat и передаёт скрыто только исходную точку/новые состояния. Old native chat и его черновик не удаляются. Failed open retry не сбрасывает второй раз; concurrent opens сериализованы, fresh-empty/token/deadline guards прежние. Старый transcript на сервере DeepSeek не стирается локальным reset. Неполный состав, сбой cleanup, чужие/неточные источники, изменение мира и неправильное имя блокируют применение. Личный мир пользователя агентом не сбрасывался. Архивы исходных текстов входят только в полную backup, portable world экспортирует текущую очищенную библиотеку.

QA RP247: полный unit224 files/3774 pass/0 fail/5 прежних todo; финальный targeted reset/cast/continuation/docs107 pass/10 files, TypeScript/diff-check pass. Browser reset+RP regression36 pass/12 expected installed-Firefox skips, прежний cast workflow4 pass/4 expected skips (success/schema repair/refusal/replacement). Chromium/Firefox fixtures RUEN320/900, keyboard/focus, overflow/scoped Axe и8 reset screenshots просмотрены. Installed Edge RUEN synthetic: owned temporary worker7 bounded requests, cleanup, оба confirm/apply, wrong-name blocked, actual fresh POST с новой исходной точкой без старого hug/image data, families/initial love/stranger values, exact original portrait bytes, archive/entries, reload no duplicate POST; source draft untouched. Начальные runtime failures были mock: pending tab URL/target attachment, незакрытый JS handler и inline-photo assertion вместо separate photo bytes; production guards не ослаблены. Живой аккаунт/модель/full E2E не проверены. Chrome/Firefox/source ZIP сверены SHA25623/23/554 files и canonical download copies; downloads/DeepRole-Edge-world-reset-20261013.zip актуален. Финальная source упаковка включает QA docs. Chunk warning остаётся RP-08; пользовательская installed copy не обновлялась.

Передача подготовлена из main7fe177c в codex/full-world-reset и включает предыдущие незакоммиченные RP239–246 вместе с RP247. Пользователь запросил push/merge и файл для домашнего Codex; после pull читать этот верхний раздел и docs/HOME-CODEX-NEXT.md, актуальный commit/PR сверять через git log. Личное хранилище и профиль Edge не изменялись.

Следующий RP-05 участок: короткие связные сводки поверх принятой памяти и фиксированный RUEN quality contract; ссылки на точные fact/source IDs, условия/negation/владельцев/task statuses, сравнение с нынешними extractive outlines. Не сохранять вторую writable memory и не переписывать исходные факты. RP239–247 не повторять. RP-05–08 открыты; broad semantic retrieval, произвольные end conditions/calendar/overdue, масштаб/live model quality не завершены. Old-chat rewind/historical identity repair/UX02 отложены. Подробный home handoff: docs/HOME-CODEX-NEXT.md. Manual: docs/WORLD-RESET.md. Сборка сама не обновляет установленную копию.

## Предыдущая точка — RP246, явное завершение временных обстоятельств

После «продолжаем» добавлен optional scene claim.status active/ended. Ended требует event/state/scene, progress, value=text и точную цитату; automatic gate требует known exact property key и bounded RUEN ending wording. Unknown/future/conditional/negated/reported/remembered/unrecognized proposals review. Clock/persistent/tasks не получают status. Explicit active+progress возобновляет property, statusless stale facts не возобновляют; late batch сравнивает status. Старые identity arrays и binding1 прежние. Compact facts retain ending/source history; request/UI timeStatus ended только с source order, unlinked unknown. No extra requests/provider/lore/age/image edits.

QA RP246: focused125/6 files;41 новых cases (33 core/compiler,6 storage,2 UI). Final full220 files/3739 pass/0 fail/5 прежних todo, TypeScript/diff-check passed. Начальные default2000 tests выявили overhead нового контракта; compact temporal policy сокращена с сохранением schema/evidence/safety guards и исходного бюджета. Новый RUEN ending и прежний clock+temporary fact помещаются в basic three-character default2000. Первое storage падение было тестом, читавшим review proposals из списка только saved facts; проверяется реальный durable review event, production фильтр прежний. Browser26 pass/10 expected installed-Firefox skip: installed Edge synthetic RUEN actual next POST/reload содержит ended reading/exact source, предыдущего active reading нет; coat earlier-scene, code persistent, library last-known и conditional open promise прежние;4 explicit POST/no extra tabs/errors. Chromium/Firefox RUEN320/900 keyboard/scoped Axe и4 circumstances screenshots просмотрены. Живой аккаунт/модель/full E2E не проверены. Chrome/Firefox/source ZIP SHA25623/23/547 files и canonical copies сверены; downloads/DeepRole-Edge-circumstances-20261013.zip актуален. Финальная source упаковка включает QA docs. RP-08 chunk warning remains, installed user copy не обновлялась. Current manual CIRCUMSTANCES.md и связанные описания обновлены.

Следующий RP-05 участок: контракт кратких связных сводок поверх принятых фактов и фиксированный RUEN набор качества. Требовать ссылки на точные источники, условия/negation/task statuses и сохранение исходных фактов; оценить против extractive outlines. Произвольные end conditions/calendar/overdue, broad semantic retrieval и live-model quality открыты. RP239–246 не повторять; old-chat rollback/identity repair/UX02 отложены. Push не запрошен. Пользовательская installed copy не обновляется сборкой сама.

## Предыдущая точка — RP245, явное игровое время и временные состояния

После «го» реализован bounded source-backed temporal contract: story-time.ts, optional state claim.lifetime scene/persistent, reserved claim key deeprole:game-time. Literal paragraph-opening Day/День number, valid ISO date и limited RUEN elapsed labels проходят inline/batch parsing и graph checks. Text/quote/value identical; decreasing comparable absolute marker и lifetime change идут на review. Repeated elapsed phrases at separate sources не duplicate; date arithmetic/expiry/overdue status отсутствуют. Старые identity arrays byte-identical без optional lifetime, binding grammar1 прежняя.

Derived time reader использует exact fact identity/quote binding +validated episode source order. Unlinked time marker unknown; temporary state before a later accepted marker earlier-scene, otherwise last-known; persistent только accepted metadata. Task status/conditions/source text unchanged. Required story_time anchor и selected timeStatus/guide входят в whole budget. RUEN episode UI показывает literal last marker, no exact date from elapsed, temporary/lasting/unknown labels. Continuation/full backup/reset/restore/rejection сохраняют или пересчитывают view без вторичной writable памяти. No model request/provider/author lore/images rewrite.

QA RP245:45 новых unit/storage/compiler/UI cases; latest focused68/4 files passed, включая новый source-linked clock+temporary fact в 2000-token request. Final full219 files/3698 pass/0 fail/5 прежних todo, latest TypeScript и diff-check pass. Initial full exposed temporal policy overhead in legacy 2000-token scenarios and an async UI-test selection race: compact temporal policy enabled only with supported chronology, unknown empty clock not sent, original budget/selected-memory assertions retained. Identity UI test waits for the selected enabled button; product behavior unchanged. Second full exposed policy-builder default mismatch; shared default now follows world chronology. Дополнительный default-budget corpus выявил overhead самого clock+source/time guides; temporal schema/policy и общие guides сокращены без изменения JSON/evidence/status fields. Полный final повтор3698/0 зелёный. Final повтор browser26 pass/10 expected installed-Firefox skip. Installed Edge RUEN synthetic: old coat earlier-scene, gate knowledge persistent, current library last-known, literal elapsed marker in actual next POST/reload; open conditional promise unchanged,4 explicit POST/no tabs. Chromium/Firefox RUEN320/900 keyboard/scoped Axe и4 новых time-status screenshots просмотрены. Живой аккаунт/модель/full E2E не проверены. Chrome/Firefox/source ZIP SHA25623/23/545 files и download copies сверены; downloads/DeepRole-Edge-game-time-20261013.zip актуален. Финальная source упаковка включает QA docs. Chunk warning остаётся RP-08; installed user copy не обновляли.

Следующее после финальной QA: расширение жизненного цикла обстоятельств по явным условиям завершения и фиксированным сценариям; сроки/просрочку не выводить из календаря автоматически. Narrative summary quality/semantic retrieval/RP-05–08 открыты; old-chat rollback/historical proof repair/UX02 отложены. Manual GAME-TIME.md. Commit/push не запрошен, installed extension не обновляется сборкой сама.

## Предыдущая точка — RP244, проверяемые сводки эпизодов

Пользователь одобрил сводки и уточнил старение после игровых дней. Реализована первая extractive версия поверх accepted current facts: story-episodes.ts группирует по12 завершённым выбранным игровым репликам, с точной цитатой и исходным revision ID. Это порядок recorded turns, не календарь/semantic arc. Новые optional WorldGame.episodeSources и Baseline.episodeSourceSeeds сохраняются при sync/review/continuation/backup/reset/archive/restore. Graph проверяет complete non-OOC sources, same game/world, selected ancestry order, полные inherited prefixes; неизвестная старая хронология не backfill.

В StoryWorkspace добавлен StoryEpisodePanel RUEN:6 последних непустых групп, earlier disclosure, поиск text/task.title/quote, exact source disclosure, reset query при смене game ID. Сводки пересчитываются по принятым фактам: progress/replacement/rejection/alternative/undo не сохраняют отдельную устаревшую копию. Prompt facts получают episodeSource {revisionId,episode,period}; chronology не разрешает неизвестную identity. Temporal guide: transient state last-known at source, current scene/later explicit updates приоритетны; time alone NEVER fulfills/cancels task. При равной релевантности source recency выше позднего extraction order. Whole budget включает guide/annotations; quote/kind/task status не режутся.

43 новых unit/storage/compiler/UI cases; target67/5 files и итог full217 files/3653 pass/0 fail/5 прежних todo. TypeScript/diff-check pass. Первый full3652/1 выявил старую fixture, которая меняла source purpose напрямую без derived game projection; тест теперь пересчитывает её captureWorldGame, original pending/OOC exclusion assertions сохранены, production guards не ослаблены. Повтор полного набора зелёный.

Final browser26 pass/10 expected installed-Firefox skip. Actual installed Edge RUEN: jump3 game days, bridge→library accepted progress/current scene, old conditional promise remains open, next POST/reload, unchanged facts/source IDs,4 явных POST/no tabs. Прежние runtime flows и Chromium/Firefox RUEN320/900 source/text+quote search/keyboard/scoped Axe прошли;4 новых screenshots просмотрены. Живой аккаунт/модель/full E2E не проверялись. Manual EPISODE-SUMMARIES.md; календарь и произвольные lifetimes пока не реализованы. Author lore/ages/images и source grammar1 прежние; extra model calls нет.

Chrome/Firefox/source ZIP SHA25623/23/543 entries и canonical download copies совпадают; downloads/DeepRole-Edge-episodes-20261013.zip актуален. Финальная source упаковка включает этот QA handoff. Chunk warning остаётся RP-08. App code после green checks не менялся; установленную пользовательскую копию не перезагружали.

Следующее: явные подтверждённые временные метки и срок актуальности обстоятельств, начиная с контракта и набора сценариев (time jump, persistent fact, overdue open task, unknown date). Не выводить дату из episode number, wall clock или порядка импорта. Narrative summaries/model quality и RP-05–08 остаются открытыми. Внешний provider требует отдельного выбора. Historical-proof repair/old-chat rollback/UX02 отложены. RP239–243 не повторять. Commit/push не запрошен; installed extension не обновляется сборкой сама.

## Предыдущая точка — RP243, перефразирование запросов памяти

После «продолжаем» добавлен локальный story-retrieval-concepts.ts: восемь ограниченных групп RU/EN действий повышают приоритет принятого факта при другой формулировке. storyRetrievalQuery использует bounded bonus14/28, маскируя известные имена/aliases. Читаются только fact.text/task.title; quote/key/соседние поля/предложения не склеиваются. WeakMap проекция проверяет text/title/roster signature; status, roles, branch selections не кэшируются. Draft/лор/facts/quotes/storage/schema/source grammar1/model calls прежние.

48 фиксированных запросов: прежний поиск3/48 → текущий48/48, с более новыми упоминаниями того же предмета. 91 новых unit/compiler cases зелёные, включая24 abstentions, коллизии имён, cache edits, отрицания/условия/task status/вид факта и общий бюджет среди2000 записей. Итог full213 files/3610 pass/0 fail/5 прежних todo; TypeScript/diff-check pass.

Browser16 pass/8 expected installed-Firefox skip. Новый installed RUEN flow проверяет actual next POST, reload и запрос между языками с неизменными accepted facts/roles/quotes и ровно3 явными POST/no new tabs. Прежние runtime flows и Chromium/Firefox RUEN320/900 keyboard/scoped Axe прошли;4 screenshots просмотрены. Живой аккаунт/модель/full E2E не проверялись.

Chrome/Firefox/source ZIP сверены SHA25623/23/539 entries; canonical copies и downloads/DeepRole-Edge-paraphrases-20261013.zip актуальны. Финальная source упаковка включает этот QA handoff. Chunk warning сохраняется в RP-08. App code после green checks не менялся.

Следующая итерация: компактные проверяемые сводки эпизодов поверх принятой памяти; начать с контракта и фиксированных сценариев, сохраняя цитаты, исходные ID, условия и открытые/отменённые задачи. Не переписывать исходные факты ради сжимки. RP-05–08 остаются открытыми; semantic provider требует отдельного выбора, historical proof repair/old-chat rollback/UX02 отложены. RP239–242 уже выполнены; не повторять их. Commit/push не запрошен; сборка не обновляет установленную копию сама.

## Предыдущая точка — RP242, поздние источники

После «далее» исправлены exact dispatch pairs и повторные наблюдения. Новый story-dispatch-match.ts: exact body/scope/parent/user, уникальный exact assistant; competing claims unknown, единственный FETCH legacy fallback без role proof. Game writer предпочитает matching selected revision и сохраняет unchanged raw user body после late confirmation: source/events/accepted memory не дублируются и не теряются. Реальные edits работают. Images требуют того же уникального capture вместе с прежней explicit permission. Graph parent proof теперь проверяет предыдущий native assistant или baseline anchor и exact draft/full wire body.

До fix7/7 regressions падали; после38 новых unit/storage cases и target100/5 files зелёные. Итоговый full210 files/3519 pass/0 fail/5 прежних todo; TypeScript/diff-check pass. Первый общий прогон3518/1 fail показал старую UI-test гонку disabled checkbox: ожидание enabled/select checked/exact edited preview исправлено, данные/assertions/timeouts не ослаблены; production UI прежний. Отдельный21-case и повтор полного набора зелёные. Новая installed RUEN проверка держит XHR в ожидании, принимает сцену, затем выпускает ready/finish/close и проверяет следующий actual POST/unknown identity без duplicates: exactly2 явных POST, no new tabs. Итоговая browser группа14 pass/6 expected installed-Firefox skip; прежние runtime flows, Chromium/Firefox RUEN320/900 keyboard/scoped Axe и4 screenshots просмотрены. Живой аккаунт/модель/full E2E не проверялись. Fixture getter/async backup errors исправлены, guards сохранены. Field/schema/grammar1/quotes/model calls прежние.

QA package: Chrome/Firefox и три ZIP сверены SHA25623/23/537 entries; canonical copies и downloads/DeepRole-Edge-late-evidence-20261013.zip актуальны. Финальные docs включаются повторной source упаковкой/сверкой. App code после green checks не менялся. Большой chunk warning остаётся RP-08; никаких commit/push этой серии.

Следующее после QA: fixed paraphrase retrieval/episode summaries. Unknown older sources не backfill по нынешнему roster; возможный repair требует отдельного historical proof и атомарного обновления metadata без переписывания сцен. RP-05–08, semantic provider и масштабирование открыты; old-chat rollback/UX02 отложены. Предыдущие RP239–241 dirty edits сохранены, commit/push не запрошен. Архив после QA: downloads/DeepRole-Edge-late-evidence-20261013.zip; сборка не обновляет установленную копию сама.

## Предыдущая точка — RP241

### Предыдущая точка — RP241, естественные запросы к памяти

Пользователь продолжил «го». Новый src/core/story-owner-query.ts распознаёт явно названного владельца в reminder/list/именных RUEN запросах. Public createStoryRoleReader берёт question/score из него; read/status и frozen source grammar1 сохраняет createStoryRoleReaderV1. Storage/schema/исторические ID/quotes/budget/модельные запросы не меняются. Старые unbound managed facts не привязывать по нынешнему имени.

Фиксированный tests/fixtures/story-owner-quality.ts:42 положительных запросов (baseline10→42),42 правильных первых кандидата,46 безопасных abstentions,18 unchanged source cases.111 новых tests включают коллизии, чужой мир, input-token spoof, strict unknown, RUEN rename и общий бюджет. Target/core/storage189 pass до двух последних compiler cases; corpus111, полный208 unit files/3481 pass/0 fail/5 прежних todo, TypeScript/diff-check зелёные. Final browser12 pass/4 expected installed-Firefox skip: actual next POST с длинным RUEN reminder, reload/rename/name reuse, preserved raw facts, excluded variant; Chromium/Firefox RUEN320/900 keyboard/scoped Axe и просмотр4 screenshots. Новая инструкция docs/MEMORY-OWNER-QUALITY.md; manuals актуальны. Не считать curated corpus полной семантической оценкой или гарантией живого DeepSeek/account; full E2E не запускался.

Сборки Chrome/Firefox и три ZIP сверены SHA256:23/23 runtime и535 source entries, private/tests исключены; query helper — в shared chunk, verifier ищет marker среди всех runtime файлов. После финальных docs source ZIP повторно упаковывается и сверяется. Актуальный Edge: downloads/DeepRole-Edge-owner-queries-20261013.zip. Canonical downloads обновлены. Большие JS chunks остаются RP-08. Основной код после full unit/runtime checks не менялся; изменялись финальные docs. Никакого commit/push этой серии не выполнено.

Следующее: неподтверждённые и поздние capture/source пары; не присваивать старым фактам нынешние ID без исторического proof. Далее measured retrieval/пересказы и incremental summaries; semantic provider, произвольные местоимения и cross-turn economy открыты. Локальные изменения RP239/240 сохранены. Push не запрошен. Архив после QA: downloads/DeepRole-Edge-owner-queries-20261013.zip; пересборка сама не перезагружает установленную копию.

## Предыдущая передача RP240 после pull

**Текущая точка RP240 после «го» пользователя.** Постоянные роли поддержанных источников реализованы; RP-05 открыт. Предыдущие RP239 dirty edits сохранены. Фиксированный набор сложных атрибуций/запросов и неподтверждённые/поздние транспортные случаи — следующий участок. Никакого push не запрошено.

RP240: новый story-role-binding.ts; optional dispatch.roleRoster, revision.roleRoster/roleRosterRequestId, event.memoryRoles, WorldGame/baseline.factRoleSeeds. Источники связаны с подтверждённой contextual XHR парой/parent/body/scoped binding и frozen pre-send roster. Private other-chat NPC исключены. Managed history без proof теперь sourceIdentity unknown, не fallback на нынешнее имя. Raw Fact/model schema прежние. Rename даёт current name + sourceName, merge — selected target ID + sourceId; без ID персоны unavailable, name reuse не присваивает её обещание новому ID. Repo.updateRecords догружает только referenced dispatch rows в узких readKinds. Source scopes/backup/reset/continuation проверены. Partial/OOC snapshot может храниться, но не поддерживает binding. Version1 grammar + normalization pinned (createStoryRoleReaderV1); будущий parser требует новой версии, не менять старые ID. Нет новых model requests, подсистемы embeddings или rewrite исходных текстов.

Полный срез: [docs/HANDOFF-2026-10-13.md](docs/HANDOFF-2026-10-13.md). Прочитать его и верх ROADMAP перед следующей реализацией. После pull main до 7fe177c пользователь выбрал RP-05; текущая итерация RP240. UX-02 отложен. Push RP239/240 не запрошен; прежнее разрешение относилось к домашней передаче до 7fe177c.

Следующий RP-05: сложные конструкции/фиксированный набор качества атрибуции и retrieval, неподтверждённые/поздние пары и прежняя unbound память. Не мигрировать её по сегодняшним именам. RP240 не разрешает местоимения/object ownership и не гарантирует semantic correctness. Provider или тяжёлая модель требуют отдельного выбора пользователя. UX-02/03/04 сохранены; RP-05–08 открыты. Измерить стоимость full roster snapshots и dependency reads в RP-07, не объявлять масштаб бесконечным.

Сборка RP240: downloads/DeepRole-Edge-durable-roles-20261013.zip; три канонических downloads ZIP обновлены и сверены SHA256 с runtime/source файлами. Пользователь обновляет установленную копию и вкладку, сначала сделав backup. Новая сборка читает старые v1/v4; старый строгий reader может отклонить новые optional fields. Пути после смены компьютера определять заново.

Предыдущая домашняя передача до UX238:531 source/runtime23/23 файлов сверены SHA256. RP239 имеет новые runtime/source сборки, финальные числа — текущая секция ROADMAP. Точные ветка/commit и успешность синхронизации проверяются Git; не публиковать заново только из-за исторических строк «нового push нет» ниже.

QA RP240:28 новых unit/storage cases, latest targeted109 pass (initial wider189), full207 files/3370 pass/0 fail/5 прежних todo, TypeScript/diff-check pass. Final rebuild browser repeat12 pass/4 expected installed-Firefox skip на isolated synthetic server4181: captured first POST, bound next POST, reload+rename/name reuse, unchanged canonical facts, multi-voice unknown, excluded variant, strict-send; RUEN320/900 keyboard/scoped Axe и просмотр screenshots. Chrome/Firefox/source ZIP проверены SHA256; manuals/roadmap/handoff включены. Живой аккаунт/модель/full E2E не проверялись. Старые bugs fixture/helper и missing scoped dispatch dependency исправлены; 100-batch timeout одиночно и в общем повторе зелёный без изменения лимита. Никаких code edits после финального unit, нового push нет. Late/unproven captures пока сохраняют unknown; не обещать автоматическое восстановление всех исторических ID.

## Предыдущая точка: RP239 — явные роли источника памяти

Новый src/core/story-source-roles.ts: request-local reader по quote и scoped текущему character roster. Поддержанные простые RU/EN subject+speech/promise/plan/belief и named direct first-person headers дают {speaker,recipient,promisor,planner,believer} с {id,name}; неоднозначные имена/формы, pronouns, unsupported grammar, outer reported/nested promise остаются неизвестными. Только nominative subject forms; адресат exact header. Source role не следует из summary/task key/пола/порядка и не доказывает fulfillment/truth. Узкий явный owner question +40 same/-12 explicit other/0 unknown дополняет прежнюю retrieval. Никакого model/provider call или нового UI.

story-fact-context/story-retrieval-query/game-context передают выбранные role hints и guide с полной evidence в общем бюджете. Формат без reader прежний, refs внутри массива. Два map(storyFactHint) callsites в memory-batch обёрнуты из-за optional second argument, их data semantics не менялись. Cache invalidates quote edits; возвращаемые значения независимы. Canonical StoryFact/backup/schema/stored lore/ages/photos не изменяются; proposals с sourceRoles отвергаются. Dispatch exact context может сохранить metadata как историческую строку; это не identity authority.

Важное ограничение: связи вычисляются по текущему roster, НЕ переживают смену исторической личности гарантированно. Rename/removal/name reuse/historical merges нуждаются в durable ID+source binding, RP-05 checklist оставлен открытым. Не добавлять прежние owner guesses в canonical facts и не заявлять решённые местоимения.

Начальная QA:52 новых tests, последняя целевая группа115 pass; multi-voice guard после6 реальных false-positive failures исправлен header-boundary, следующие2 test assertions уточнены для полностью неизвестного результата. Installed Edge RU/EN exact POST/roles/reload/unchanged stored facts/alternative excluded/no extra service POST or tab. Browser12 pass/4 expected installed-Firefox skip включая review/strict-send и RUEN320/900 keyboard/scoped Axe. Финальная QA/ZIP — верх ROADMAP. Synthetic server/isolated contexts only; real DeepSeek response quality/full E2E не проверены. Нового push нет.

Финальная QA:205 files/3342 unit pass/0 fail/5 прежних todo,115 target pass,TypeScript/diff-check pass. Окончательная Chrome-сборка повтор12 browser pass/4 installed-Firefox skip; shared multi-voice source не получает sourceRoles в actual POST. Своё runtime test server4181 вместо занятого другим проектом4173; private config/helper исключены из Git/ZIP. RU/EN320/900 screenshots просмотрены. Chrome/Firefox/source ZIP и копии проверены SHA256, актуальные документы включены. Warning large chunk RP-08 остаётся; real model/full E2E не заявлять. Никаких code changes после этой QA, push не запрошен.

## Предыдущая точка: UX238 — навигация и оглавление настроек

Пользовательское «дальше усиливает UX/UI (финальный промпт)» принято как подтверждение структуры. Реализованы новые RU/EN navigation-i18n и SettingsNavigation/css; SettingsView default home, группированные объяснённые переходы, advanced memory/diagnostics, отдельная диагностика вместо блока внутри data. Bottom nav: Play/Worlds/Story memory/Settings. Формы оставлены mounted+hidden для черновиков. Не менять это на remount при переключении. Мировые и общие области в hints различаются; навигация ничего не сохраняет. Никакого backend/data/defaults изменения. Отключена entrance animation только Settings page.

QA:204 files/3290 unit pass/5 прежних todo; TypeScript pass.52 distinct browser scenarios pass/10 expected installed-Firefox skips: RUEN320/900/1100,keyboard/scoped axe, помощь, настройка reasoning/reload, actions, world tuning isolation/newer edits, installed diagnostics4 и story alternatives/edit/undo/reload/two tabs2. Последние4 installed settings cases подтвердили unsaved budget3333 survives category changes при unchanged stored settings. Свои contexts закрыты. Первоначальные12 failures расширенного набора были stale test labels/internal neutral; исправлены только expectations, повтор26-case группы22pass4skip. Механически обновлены old nav selectors в E2E и helper openSettingsSection; Playwright --list2182cases/173files загружается, но весь набор не запускался. Не заявлять live model/full E2E/screen-reader coverage.

Chrome/Firefox/source пересобраны и SHA256 каждого включённого файла проверен:23/23/530. Канонические downloads ZIP обновлены; актуальный Edge архив:downloads/DeepRole-Edge-UX-settings-20261013.zip. Large-chunk warning остаётся RP-08. Пользователю дать работающую сборку с просьбой backup/update+reload. Весь UX-01–07 не закрыт: UX-02 first-run/game и UX-03/04 editor/memory следующий приоритет. RP-05–08 тоже открыты. Не обещать идеальный/бесконечный продукт и не менять его память ради оболочки. Предыдущие dirty edits сохранены, нового push нет.

## История планирования UX до реализации UX238

Пользователь просит понятную иерархию всего расширения для новичка, минимум вмешательства в игру, разделение главных/второстепенных/служебных действий. Начальная source-level сверка и предложенный UX-01–07 план сохранены в верхней секции ROADMAP.md. Предложена навигация «Игра / Миры / Память игры / Настройки» с сохранением AXIS-2 без liquid glass. Не утверждать, что дизайн уже реализован: в этом ходе нет UI edits, rendered audit, новой сборки или изменений backend. Последний проверенный архив — RP237 ниже.

Сначала получить подтверждение предложенной структуры по shape workflow; далее UX-01 mapping всех существующих функций и UX-02 работающий первый экран. Нужные ошибки, конфликты и блокировки не прятать; детали протокола/диагностики не делать повседневной обязанностью игрока. Лор, память ветви, scene state и глобальные настройки не смешивать. Использовать существующие токены/общие компоненты, RU/EN и narrow-layout проверки. Прежние dirty изменения сохраняются, push не разрешён. RP-05–08 остаются открытыми; UX-track не повод заявить их закрытие.

## Текущая точка после RP237

Финальное девятое продолжение RP229–RP237. Итоговая инструкция: docs/RP05-CHECKPOINT.ru.md (простые примеры, действия пользователя и реальные gaps). Основной RP-05 checkbox reasons/saved/selected/delivered/model-use отмечен [x] по RP231/232; broader cross-turn repetition остаётся [ ] с подитогом RP235/236. RP-05 НЕ закрыт целиком; speaker/owner bindings, semantic retrieval comparison, full incremental classification/source-backed summaries и cross-turn safeguards ещё открыты. RP-06–08 не закрывать по локальным частичным сценариям.

Текущий turn — audit/documentation без новых application code edits. В startup-runtime test исправлен Brave standalone-menu wait: 5s → 12s при прежнем независимом 8s cold-read deadline. Первый расширенный прогон дал 20 pass/2 failures/22 expected installed-Firefox skip; обе failures были на этом 5s assertion. Полный повторный прогон прошёл22 pass/22 предусмотренных skip, результаты — верх ROADMAP. Первая отдельная installed browser группа14 pass/6 expected installed-Firefox skip: RP02 reviewed-memory after quiet turns/alternative/strict-send плюс RP04 lifecycle/attribution/refs, common budget/100 profiles/names, receipts/HTTP500/new-chat, RUEN320/900 keyboard/Axe. Synthetic server/isolated profiles only, no personal account/external model requests. Все собственные контексты закрываются finally.

Финальная QA RP237: полный повтор дополнительной группы22 pass/22 expected installed-Firefox skip; обе Brave проверки прошли. Вместе с первой группой36 browser pass/28 skip. Общий unit-прогон203 files/3286 pass/5 прежних todo, TypeScript/diff-check без ошибок. No live-account/full native-server coverage. Chrome/Firefox/source пересобраны и проверены SHA256:23/23/527 файлов. Актуальный архив:downloads/DeepRole-Edge-RP05-checkpoint-20261013.zip; канонические ZIP обновлены. Large-chunk warning остаётся RP-08. Нового push не было.

Дальше: сначала пользовательская проверка свежей сборки после backup/update + one-time Automatic memory (если ещё не enabled); затем замеренный attribution/retrieval quality slice RP-05, не тяжёлая новая архитектура в один ход. Не угадывать pronoun owners, не обещать native context infinity, не внедрять внешний provider без выбора. Push без запроса не делать; прежние dirty изменения сохраняются. Последний код RP236 остаётся baseline этого checkpoint.

## Текущая точка после RP236

Актуальный архив: downloads/DeepRole-Edge-compact-protocol-20261013.zip. Финальная QA: 203 unit-файла, 3286 pass/0 fail/5 прежних todo, targeted42 pass, TypeScript/diff-check без ошибок, browser12 pass/4 expected installed-Firefox skip. Chrome/Firefox/source пересобраны; ZIP SHA256 проверены:23/23/526 файлов, канонические копии обновлены. Live account/native server/full E2E не проверялись; контексты закрыты. RP-05 открыт, установленная копия сама не обновляется, нового push не было.

Уточнение RP235: sourceQuoteRef не записываются в canonical StoryFact или reusable source table. Исторический dispatch journal сохраняет exact outgoing context string вместе с локальными refs; это не live authority и не permission использовать таблицу прошлого запроса. Не утверждать абсолютное отсутствие refs в любых persisted bytes.

Восьмое продолжение серии; осталось одно. storyUpdateInstruction optional fifth factPolicySupplied применяется только в compact branch; дефолт false, full legacy unchanged. Unified compiler получает accompaniment один раз, выставляет флаг только when nonempty + world.policy mode automatic/review; absent/off retains complete fact schema/evidence clause. Core compact kind definitions усилены: promise NOT fulfillment, plan NOT completion, belief NOT objective truth. Scope/version2/ops/known goals/present-partners/numeric-selfie/OOC/identity ограничения прежние.

formatStoryFacts optional third typesSupplied применим только compact. Unified compiler passes !!input.story, так как current story_update_mode действительно в этом же render. Compact header не повторяет kind definitions, но task.status semantics, original dates/latest claims, attribution/sourceQuote/ref guides остаются. Default standalone and full format самодостаточны. Не выставлять флаги на основе сохранности прошлых сообщений/native контекста. No DB/schema/parser/retrieval/approval changes, no extra POST; полная защита ручных профилей/quoted evidence/claims/tasks остаётся в текущем accompanying policy.

tests/story-protocol-compaction.test.ts:6 cases automatic/review, absent/off, default/full legacy, kinds+status+source attribution preservation and token estimate reduction. Targeted42 pass. Installed lifecycle adds duplicate-schema/kind-absence + NOT fulfillment/completion/objective truth assertions across actual next POST; финальная QA/архив — верх ROADMAP. RP-05 открыт: speaker/owner binding, broader quality, native continuation/performance gaps не объявлять закрытыми. Следующее — финальная сквозная сверка этой серии и честное разделение implemented vs pending перед RP-06. Push без запроса не делать; предыдущие dirty изменения сохранены.

## Текущая точка после RP235

Актуальный архив: downloads/DeepRole-Edge-shared-evidence-20261013.zip. Финальная QA: 202 unit-файла, 3280 pass/0 fail/5 прежних todo;6 новых targeted cases, TypeScript/diff-check без ошибок; browser12 pass/4 expected installed-Firefox skip. Chrome/Firefox/source пересобраны; ZIP SHA256 проверены:23/23/526 файлов, канонические копии обновлены. RP-05 открыт, установленная копия сама не обновляется, нового push не было.

Седьмое продолжение серии, осталось два. core/story-fact-context storyFactPayload собирает selected storyFactHint, exact quote→first earlier index map. Только дополнительные sourceQuote (quote!=text) могут стать sourceQuoteRef integer. Target всегда earlier fact с full sourceQuote, без chained refs и без references к предыдущим запросам. Recompute per render; no schema/DB change, no global cache or native-history deletion. Нельзя дедуплицировать авторский лор/профили или normalize цитаты ради экономии.

Shared payload применяется только если estimateTokens(encodedJSON+STORY_QUOTE_REFERENCE) строго меньше inlineJSON; short evidence остаётся inline. Full/compact envelopes добавляют локальное ref объяснение only for shared; full-render admission учитывает JSON+guides и keeps quote whole. safeJson сохраняет escaping '<'/'>', JSON reconstruction literal exact. Оригинальные task/claim/kind/text/quote поля не переписываются, scoring/status/scope прежние.

tests/story-quote-sharing.test.ts:6 cases exact round-trip, inline fallback, not normalized, order/removal/edit/fresh-request, protocol markers, fixed whole request budget retaining3 facts vs oversized inline. Предварительные targeted41 pass до добавления последнего compiler case; отдельно6 pass. Installed lifecycle adds second promise и exact общий long source с условиями; после reload в eighth manual POST refs указывают на full sourceQuote earlier факта. Browser12 pass/4 expected installed-Firefox skip, UI RU/EN320/900 keyboard/Axe, свои контексты закрыты; live account/full E2E не проверялись. Окончательная QA/архив — верх ROADMAP. RP-05 открыт; дальше safe redundancies/structured attribution. Не заявлять native context infinity, full speaker binding или model semantic use. Push без запроса не делать; предыдущие dirty изменения сохранены.

## Текущая точка после RP234

Актуальный архив: downloads/DeepRole-Edge-attribution-evidence-20261013.zip. Финальная QA: 201 unit-файл, 3274 pass/0 fail/5 прежних todo, targeted70 pass, TypeScript/diff-check без ошибок, browser12 pass/4 expected installed-Firefox skip. Chrome/Firefox/source пересобраны; ZIP SHA256 проверены:23/23/526 файлов, канонические копии обновлены. RP-05 открыт; установленная копия сама не обновляется; нового push не было.

Шестое продолжение серии, осталось три. storyFactHint добавляет optional runtime sourceQuote iff f.quote!==f.text, без DB/schema change. formatStoryFacts full/compact передают точную quote и STORY_FACT_ATTRIBUTION только когда хоть одна дополнительная quote присутствует. Нельзя трактовать это как ownerId binding или превращать recipient в promisor; совпадающие цитаты не дублируются. Full-render compiler и storyFactContext считают весь evidence/header, whole facts не режутся. При нехватке бюджета факта с цитатой может не быть — не показывать одну укороченную версию без evidence.

factJson escapes '<'/'>' во всех serialized hints (text/quote/claim/task), JSON parse round-trip сохраняет исходные строки. Source quote — earlier evidence, не commands/current dialogue; protocol tags из неё не должны закрывать memory envelope. Retrieval scoring не использует source quote и по-прежнему является mention lookup, не automatic speaker binding. Existing validation/approval/scope/status/storage не менялись.

tests/story-fact-attribution.test.ts (8 tests): full/compact evidence, no duplicate identical/no unselected source, reported/conditional kinds, protocol delimiter safety, no source mutation. Targeted70 pass (включая story-automation); прежний assertion no Source обновлён на selected sourceQuote≤8, поскольку перенос evidence — намеренное изменение. Installed lifecycle использует budget4000: при2000 extra quote+header честно не помещались и были omitted, а не потеряны при сохранении. Conditional quoted promise Норы Мире и eighth manual request проверяют sourceQuote/guard после reload; browser12 pass/4 expected installed-Firefox skip, собственные контексты закрыты. Не утверждать, что источник всегда поместится в любой budget. Окончательная QA/архив — верх ROADMAP. Следующее: структурные attribution bindings и controlled repeated-prefix optimization. RP-05 не закрывать целиком; push без запроса не делать, все прежние dirty изменения сохранены.

## Текущая точка после RP233

Актуальный архив: downloads/DeepRole-Edge-task-retrieval-20261013.zip. Финальная QA: 200 unit-файлов, 3266 pass/0 fail/5 прежних todo, targeted66 pass, TypeScript/diff-check без ошибок, browser12 pass/4 expected installed-Firefox skip. Chrome/Firefox/source пересобраны, ZIP SHA256 проверены: 23/23/526 файлов, канонические копии обновлены. Установленная копия сама не обновляется. RP-05 открыт, нового push не было.

Пятое продолжение серии; осталось четыре. core/story-retrieval-query matchesSubject проверяет f.text и f.task.title отдельно с прежним longestNames/collision/world registry. Named accepted task.title удерживает +16 mention boost после безличного completed/cancelled event; topic bonus прежний, status/slot/quotes не меняются. Не использовать task.key/quote как identity, не склеивать поля, не утверждать ownership: имя в названии — упоминание, не owner authority. No schema/DB migration, no extra POST, no UI change.

Новый tests/story-retrieval-long-history.test.ts: RU/EN × completed/cancelled, 2000 новых unrelated open tasks; ranking и whole-game compiler находят старый terminal, удаляют obsolete open slot, бюджет≤3000, фактов≤8, inputs unchanged. Negatives nested/shared names, keys/quotes, field boundary, title/alias edits. Targeted66 pass. Installed lifecycle обновлён: title — literal full-name promise clause в quote, impersonal done, next POST/reload/alias/given-name сохраняют terminal. Первоначальная colon-title fixture была отклонена existing literalEvidence: production validation НЕ ослаблялась. Browser12 pass/4 expected installed-Firefox skip, 7 ручных POST lifecycle без лишних сообщений, UI RU/EN320/900 keyboard/Axe. Контексты закрыты; live account/full E2E не проверялись. Финальная QA/архив — верх ROADMAP после завершения.

Следующее: более широкие attribution/quality checks, speaker/owner bindings (полной поддержки местоимений всё ещё нет), безопасное уменьшение repeated added context. Не закрывать RP-05 целиком и не обещать расширение native контекста или AI semantic search. Push без запроса не выполнять, прежние dirty изменения сохранены.

## Текущая точка после RP232

Актуальный архив: downloads/DeepRole-Edge-memory-delivery-20261013.zip. Финальная QA: 199 unit-файлов, 3260 pass/0 fail/5 прежних todo; 61 целевой pass, TypeScript/diff-check без ошибок, browser12 pass/4 expected installed-Firefox skip. Chrome/Firefox/source ZIP пересобраны, содержимое SHA256 проверено: 23/23/526 файлов; канонические копии обновлены. Large-chunk warning остаётся RP-08. Установленная копия сама не обновляется.

Четвёртое продолжение серии, осталось пять. Добавлен отдельный historical MemoryDeliverySummary в PageWidget+sidepanel. core/memory-delivery-view выбирает последнюю valid local user-turn capture по createdAt в exact world/binding/chat, не по updatedAt старого ответа; ties unavailable. Restored/OOC/service/invalid/foreign excluded. Это не current-game/branch authority: UI явно допускает прежнюю игру/вариант ответа. Game-managed captures не имеют storyBranchId; не создавать post-hoc связь. Нельзя переименовывать текущий selection.contextReport в sent.

View передаёт только at/stage/injection/optional proven context/responseInterrupted. Original draft, новый reply, native IDs, wire и error payload не передаются отдельными полями. Exact context может содержать private lore, старые реплики и protocol identifiers: не объявлять весь view sanitized report. injection=context proof означает exact whole outgoing string equality в существующем journal; source-confirmed отдельно от started, HTTP accepted отдельно от model use и reply completion. Лор в textarea — private user data, не safe report; ленивое раскрытие, readOnly, RU/EN/Intl date. Content читает уже загруженные dispatch records, current scope getter исключает locked/service/missing world/binding mismatch; lock очищает массив. DR_PAGE_STATE опционально передаёт view, sidepanel очищает вместе с PageState.

Точечное обновление receipt: optional onUpdated callback StoryDispatchCaptureClient после успешных prepare/source/packet writes; ошибки UI не мешают source ACK. Content читает один dispatch через repository.get, не вызывает reload/updateContext и не меняет journal/library notifications. Async generation + URL/chat/world/binding/locked guards блокируют опоздавшие результаты. Dispatch-only writes намеренно не announceLibraryChange: не включать полный reload для обновления панели.

61 целевой test pass; browser 12 pass/4 expected installed-Firefox skip. Фактический POST RU/EN: verified prefix равен отправленному, HTTP500→failed, reload сохраняет receipt, новый чат не получает чужой; ровно5 ручных POST, без дополнительных сообщений, исходные100 анкет сохранены. GUI RU/EN320/900 keyboard/Axe, два PNG просмотрены, контексты закрыты. Live account/full E2E не проверялись. Финальная QA/архив — верх ROADMAP после завершения. Следующее: quality benchmark долгой истории, owner/speaker binding и repeat optimization; RP-05 открыт. Push без запроса не выполнять. Все предыдущие dirty изменения сохранены.

## Текущая точка после RP231

Актуальный архив: downloads/DeepRole-Edge-memory-explanations-20261013.zip; канонические Chrome/Firefox/source обновлены. 3251 unit pass/5 прежних todo (198 файлов), 30 целевых pass, TypeScript/diff-check без ошибок. Browser 12 pass/4 expected installed-Firefox skip: nested reason disclosure/preview disclaimer RU/EN 320/900 keyboard/Axe, два PNG просмотрены; установленный Edge бюджет/100 профилей/имена + lifecycle/tasks/conflicts/alias/short-name, без лишних POST. Свои контексты закрыты, личный аккаунт не использован. Следующее — отдельный request-bound delivery view по dispatch evidence; не менять preview на Sent без него. RP-05 открыт; нового push не было.

Третье продолжение серии, пользователь ожидает ещё шесть. Первая часть why selected: GameContextReport.explanation optional runtime numeric counters draftFacts/recentFacts/openTasks/recentFallback, классификация лишь после admission selectedFacts, сумма ==selected.facts, metadata не входит в prompt. Нет новых persisted данных или source quote/name/ID в report. RU/EN ContextBudgetSummary в PageWidget+sidepanel принимает entries отдельно для локального UI; native details показывает первые8 titles и локализованные нормализованные причины, а не raw keywords/IDs. Режимы Always/manual, words/title/name, focus/entity, linked; неизвестное не выводится raw. UI cap не ограничивает memory selection.

Экран явно selected-memory preview, stored≠included, not confirmation of sending, recomputed before sending, how model uses unknown. Причины анкет/whole continuation generic; поддержан legacy report без explanation. Не считать текущий selection.contextReport последней подтверждённой отправкой. Отдельной Sent-history панели пока нет: следующее — читать request-bound dispatch evidence, проверять scope/world/chat/branch, различать proposed/actually submitted/server accepted/failed и никогда не обещать semantic use. Нельзя основывать Sent только на compile или наличии assistant reply.

tests/context-explanation.test.tsx: counters/omitted/no private report strings/no prompt additions/RUEN/raw-reason masking/8-item cap/legacy; context-budget-ui обновлён для nested disclosure keyboard, preview disclaimer и Always reason. 30 целевых pass, TypeScript без ошибок; актуальная финальная QA/архив — верх ROADMAP. Все прежние dirty изменения сохранены, push без запроса не выполнять. RP-05 ещё открыт.

## Текущая точка после RP230

Актуальный архив: downloads/DeepRole-Edge-character-reference-selection-20261013.zip, канонические Chrome/Firefox/source обновлены. 3246 unit pass/5 прежних todo (197 файлов), 77 целевых pass; TypeScript/diff-check без ошибок. Browser 12 pass/4 expected installed-Firefox skip; установленный Edge RU/EN проверил настоящий POST без чужой анкеты/description при nested full-name query, ambiguity guard и 4 ровно ручных POST, сохранив 100 профилей. Прежние lifecycle/alias/short-name проверки прошли; GUI RU/EN 320/900/Axe/keyboard, два PNG просмотрены. Свои контексты закрыты, личный аккаунт не использован, полного E2E не было. Установленная копия сама не обновляется; RP-05 открыт. Следующая итерация — причины выбора и stored/selected/sent различие.

Второе продолжение новой серии; осталось семь по последнему сообщению пользователя. RP-05 продолжается. storyRetrievalQuery возвращает mentionedIds (unique registry ownership, включая уникальный alias даже при duplicate canonical name) и ambiguousName (matched non-pronoun longest phrase с несколькими владельцами). Game compiler использует IDs для selectCharacterContext optional final arg и resolvedMentionIds в compileMemoryWorkspace/rankMemories. Старые scalar mentionsCharacter/legacy callers без registry не переписывались. Физические участники/player/partners/focus независимы от mention lookup; прежняя защита optional request roster budget сохранена.

runtimeMemoryDocuments принимает resolvedMentionIds, исключая ложную required entity description при Ann Lee→Ann overlap. Entity-linked score boosts используют те же IDs; scope через expandFocus/world проверяется каждый раз. compileMemoryWorkspace материализует iterable один раз до projection/ranking. Неперсонажные ссылки (groups/locations) остаются через mentionedEntities, group members раскрываются для roster reference, не устанавливают presentIds и не пишутся в базу. Неоднозначный запрос получает AMBIGUOUS_STORY_NAME в required render, даже без story если есть обычный scene scope; referenceOnly выключает registry/guard.

tests/character-reference-selection и game-context покрывают nested full vs short, ambiguity/no order choice, preserved actual cast/partner/focus, legacy, iterator, groups; 77 целевых pass. game-context-runtime RU/EN дополнен off-scene Ann/Ann Lee, actual POST без чужого profile/description и ambiguous short-name guard, ровно четыре ручных POST; исходные 100 анкет сравниваются с сохранёнными. Следующее — причины выбора и stored/selected/sent различие, quality benchmark/speaker bindings/repeat optimization. Keyword/title heuristic отдельных lore entries пока не является строгой привязкой к человеку. Актуальные проверки/архив — верх ROADMAP. Прежние dirty изменения сохранены; push без запроса не делать.

## Текущая точка после RP229

Актуальный архив: downloads/DeepRole-Edge-reference-search-20261013.zip; канонические Chrome/Firefox/source обновлены. 196 unit-файлов/3237 pass/5 прежних todo, 56 целевых pass, TypeScript/diff-check без ошибок. Browser 12 pass/4 expected installed-Firefox skip: Edge RU/EN next-POST после completion/resolution + Keeper alias + unresolved her/её + короткое Mira/Миры для Mira Vale/Мира Вейл, ровно 7 ручных POST, исходная реплика не изменена; общий бюджет/100 профилей. GUI обоих языков/320/900/клавиатура/Axe, два PNG просмотрены. Все свои контексты закрыты; живой аккаунт и весь E2E не проверялись. Установленная копия сама не обновляется. RP-05 открыт; нового push не было.

Первый из новой серии девяти продолжений (пользователь ожидает ещё восемь). RP-05 продолжается: core/story-retrieval-query делает query-only exact unique alias/name expansion в текущем мире; duplicate canonical names тоже не расширяются. score +4 для распознанного RU/EN типа (promise/task including terminal, plan/task, belief, secret), +16 для факта с точным однозначным именем/алиасом явно названного человека. Это упоминание, не вывод владельца/говорящего. Старый rankStoryFacts без scope сохраняет прежние scores; game compiler передаёт scope только для текущего draft. Recent fallback остаётся прежним и не получает это усиление.

Уточнение пользователя: полное имя с фамилией НЕ должно быть обязательным. Добавлены runtime given-name формы для conventional multi-part proper names и RU формы однословных имён на а/я. Общая owner map учитывает явные и выведенные формы; shared first names не назначаются произвольно. Canonical uniqueness отдельно проверяется по explicit names/aliases: уникальный псевдоним может отличить человека Ann от Ann Lee, даже если короткое Ann неоднозначно. Longest-name защита действует в запросе и самом факте. Однословные personal pronouns как названия/алиасы не дают автоматической привязки. Полная морфология/любые nickname guesses не объявляются готовыми; inferred forms не пишутся в базу. Scope теперь также scene.worldId при профилях без story; referenceOnly исключён. Поисковый draft используется в compileMemoryWorkspace и selectCharacterContext, настоящий draft и canonical records остаются прежними. Lifecycle RU/EN — 7 ровно ручных POST, включая Keeper, her/её и Mira/Миры после reload.

При распознанной теме и personal reference добавляется короткий deeprole_reference_guard: NOT resolved, кандидаты не доказательство принадлежности, не объединять обязательства. Guard в required общем бюджете, no profile/service без story. Никакой подмены draft, gender guessing, first/last recent name binding, persisted writes или дополнительного POST. Факт/цитата/claim/task остаются исходными. tests/story-retrieval-query — 12 фиксированных positive misses baseline → correct top1, отрицательные shared aliases/world/substrings/duplicate names/mutation; game-context сохранение обеих promise candidates, guard budget и off-scene профиль по короткому имени; lifecycle-runtime RU/EN дополнен alias, pronoun и short-name запросами после reload, 7 ровно ручных POST. Актуальный результат — верх ROADMAP.

Следующее — закончить оставшиеся RP-05: проверяемые speaker/participant bindings, quality comparisons/reasons и repeat optimization, затем RP-06. Нельзя представлять текущую lexical эвристику как полное понимание любого лора или завершённый pronoun resolver. Прежние dirty изменения сохранены; push без запроса не выполнять.

## Текущая точка после RP228

Актуальный архив: downloads/DeepRole-Edge-fact-search-20261013.zip; канонические Chrome/Firefox/source обновлены. Полный unit 3207 pass/5 прежних todo, 51 целевой pass, TypeScript без ошибок; выбранный browser 12 pass/4 expected installed-Firefox skip, GUI обоих языков/320/900 и установленный Edge next-POST после completion/conflict resolution. Все свои контексты закрыты, живой аккаунт не использован. Установленная копия сама не обновляется; полного RP-05/semantic retrieval здесь нет.

Первый lexical layer игровых фактов: core/story-fact-search-index WeakMap по исходному StoryFact хранит лишь text/claim.key/task.title и synthetic MemoryEntry. rankStoryFacts использует compactStoryFactSources (исходные identities) для индекса и cleanStoryFact для возвращаемых независимых копий. compactStoryFacts сохраняет прежний copy contract через sources.map(cleanStoryFact). Порядок latest slots/replaces вычисляется каждый раз, open bonus берётся из текущего source.task.status; цитаты/статусы/выбор ветки не кэшируются. После reload библиотеки новые source objects намеренно получают новый индекс; ускорение постоянного кэша между перезагрузками не обещать.

tests/story-fact-search-index содержит 1000-факт reuse, parity с прежним cold scorer, in-place edits, статус/цитаты, независимость returned copies, latest claim/human replacement/undo и supplied branch isolation. Это оптимизация CPU разбора, не улучшение semantic quality. Следующее — измеримые сложные случаи поиска/неоднозначные ссылки, полная incremental classification и безопасное сокращение повторов; далее RP-06. Актуальные проверки/архив — верх ROADMAP; прежние dirty RP226/227 сохранены, push не выполнялся.

## Текущая точка после RP227

Актуальный архив: downloads/DeepRole-Edge-incremental-search-20261013.zip; канонические Chrome/Firefox/source обновлены. 3196 unit pass/5 прежних todo, 44 целевых pass, TypeScript без ошибок; выбранный браузерный набор 10 pass/2 expected installed-Firefox skip. GUI RU/EN 320/900 и фактические установленные игровые POST RU/EN проверены синтетически; личный аккаунт не использован. Все свои контексты закрыты. Установленная копия сама не обновляется. RP226 незакоммиченные изменения сохранены, нового push не было.

RP-05 продолжен первым инкрементальным lexical layer: core/memory-search-index.ts, используемый scoreMemory, хранит WeakMap по MemoryEntry object. Сравнивает фактические title/content/keyword values, а не updatedAt; переиспользует неизменённые компоненты. Другой объект с тем же ID не получает чужой индекс. Нет persistent cache, API, изменения score/reasons или кэширования selections. Проверки scope/disabled/book/manual/excluded выполняются каждый раз.

memory-workspace titleIndexes теперь проверяет снимок scoped enabled записей (ID/title/content/copied keywords), поэтому та же array identity после правки/замены/добавления/удаления не оставляет старую name association. При изменении классификация имён пока пересчитывается целиком; это не полный инкрементальный индекс. compactStoryFacts создаёт новые объекты и его ускорение этим слоем не объявляется готовым. Следующее — измеримые случаи более точного поиска, индекс игровых фактов/классификации, неоднозначные местоимения и сокращение повторов без предположения о сохранности старого native context. Подробные проверки и актуальный архив — верх ROADMAP.

## Текущая точка после RP226

Первый бюджет RP225 и его проверка/упаковка завершены вместе с исправлением запуска RP226. Текущая сборка: downloads/DeepRole-Edge-common-context-budget-20261013.zip; канонические Chrome/Firefox/source ZIP обновлены. Следующее — оставшийся RP-05: точнее локальный поиск/неоднозначные местоимения, инкрементальный индекс, сокращение повторных вставок без предположения о бесконечной сохранности старого контекста; затем RP-06. На другом компьютере .output нужно создать заново. Актуальные результаты — верх ROADMAP; ранние таймауты не выдавать за финальный прогон.

RP226: startupBudget даёт один 8s logical deadline для всех content startup фаз, начальные чтения идут вместе. active lease и reloadGeneration защищают поздние ответы; imageSettings присваиваются только после проверки generation. getVaultConfig/getSessionKey ограничивают именно storage read внутри операции: reject, не unlocked default, освобождает библиотечный lock. Нельзя заменять это таймаутом всей записи/crypto/IDB transaction или принудительно освобождать lock у продолжающейся мутации. Tests startup.test/vault-read-deadline и installed startup-runtime включают задержку перед зависшим vault; все 8 Edge cases прошли. Основной выбранный E2E 20 pass/12 expected skip, обе recovery; полный unit 3184 pass/5 todo, TypeScript без ошибок. Живой аккаунт, installed Firefox/Brave и весь E2E проекта не проверены.

Первый игровой слой RP-05 подключён: compileGameContext собирает весь добавленный prefix, включая [User message] separator, в одном приблизительном бюджете. Нативная история DeepSeek не сокращается и не удаляется. Следующее: более точный релевантный поиск/неоднозначные местоимения, инкрементальный индекс, контролируемое сокращение повторов; затем RP-06 продолжение. Полный RP-05 ещё открыт.

Required часть: компактный протокол, текущая сцена/roster/action restrictions/numeric policies, защищённые поля активных анкет, записи Всегда/manual и выбранная summary snapshot и полный проверенный recovered reply для конкретного запроса. Ничего из этого молча не обрезается; при required>limit optional данные не добавляются, превышение видно в общем индикаторе. Strict sending сохраняет свой существующий режим. Нормальный запрос использует compact variants; referenceOnly/service и standalone вызовы прежних функций остаются полными, не получают новый write-протокол.

Прямые совпадения игрового факта с вопросом резервируют место до общих абзацев анкеты; слова последней сцены — fallback, не конкурируют с явным вопросом. Остальные optional части добавляются небольшими раундами: ранжированные принятые факты/задачи (макс8), релевантные записи, цельные абзацы appearance/personality/goals/background, затем до двух цельных последних turns переноса. Полный render проверяет лимит после каждой попытки; JSON, условия и отрицания не режутся. profile_excerpts явно partial/nonadjacent. Анкеты/история в базе не меняются. Активные профили не ограничены шестью; physically present/player/focus/exact-mentioned roster сохраняет IDs/alias ambiguity rules, без unrelated библиотеки.

Candidate-only режим rankMemories/compileMemoryWorkspace не строит огромный совокупный prompt; прежние вызовы сохраняют поведение. Контекстный neighbor допускается только от фактически выбранного родителя. Подбор остаётся локальным words/stems/names/links; местоимения не подменяются догадкой и embeddings не включены. estimateTokens остаётся приблизительным, не native token count.

Content.updateContext использует единый builder; ContextSelection.contextReport передаёт только counts/budget/overflow (не новые persistent данные). ContextBudgetSummary в sidepanel и PageWidget, RU/EN, что выбрано/не включено и обязательное превышение. Preview и финальная отправка могут различаться из-за актуального request ID/scene; фактический prefix проверяется на синтетической MV3. Обновление архива не обновляет установленную копию. MemoryStatus и badge учитывают игровые факты/фрагменты даже без lore entry. Native parent/edit подготовка ограничена tracked shared game; обычный чат без мира не вызывает game rewind и не теряет recovered reply. Same-chat/world/vault guards сохранены.

Файлы: core/game-context/context-budget-i18n, compact варианты characters/actions/relationships/attributes/story-update/story-automation/scene-choices, story-fact-context; content.tsx; shared/ContextBudgetSummary. Tests: game-context.test.ts, context-budget-ui.spec.ts, game-context-runtime.spec.ts. Итоговые проверки/архивы — верх ROADMAP. Живая модель и весь E2E не заменяются тестами; сохранять прежние нерешённые границы RP223/224 ниже.

## Текущая точка после RP224

Рабочие задачи и разрешение противоречий подключены к игре, поверх RP220/223. Inline по-прежнему не делает дополнительных запросов; отдельные партии остаются opt-in. Следующая основная задача — RP-05: общий бюджет контекста и более точный подбор памяти. Старый непроверенный backfill и сложные идентичности ещё открыты; не объявлять весь бесконечный ролплей законченным.

StoryFact.task хранит exact key, literal title и open/completed/cancelled. Terminal требует event и известную связь; планы/обещания/сомнения/переименование/повторное открытие не закрывают задачу автоматически. claim.transition:progress отличает сыгранное изменение state от correction; новое differing state без progress требует проверки. Сопоставление смысла и ключей всё ещё зависит от модели, не является доказательством. Старые факты читаются без новых полей.

Review показывает старые/новые игровые факты и цитаты. Human resolver может добавить replaces с exact storyFactIdentity только из предложенных текущих сравнений, под guard/game/writer; inline/batch запрещают модельное replaces. compactStoryFacts снимает влияние старых значений, не удаляет sources; selected-line undo/continuation/seeds/backup используют тот же fold. Авторский лор не удаляется. Старая неподключённая память promise/plan/task показана отдельно, не считается выполненной задним числом.

StoryTaskPanel в основном StoryWorkspace: поиск, открытые задачи, completed/cancelled, цитаты, пагинация без общего потолка. Русский и английский текст общий story-task-i18n. Подбор контекста остаётся до восьми фактов в прежнем supplied budget; приоритет open задач не увеличивает бюджет. Batch hints передают до восьми open и двенадцати остальных в прежних 5000 символах; служебные replaces/quotes не передаются как hints.

Попутно исправлены хронологический порядок previous memory в planStoryAccompaniment, сравнение отклонённых proposals с исправленными metadata, сохранение factSeeds при restart/checkpoint и сохранение раскрытия завершённых задач после поиска. Похожие слова не должны поглощать marked conflict или explicit differing-claim progress.

Файлы: core/story-memory-lifecycle, story-task-i18n, story-update/automation/fact-context/review; storage/story-automation(-review)/story-facts/review/game/memory-batch; StoryTaskPanel, StoryAutomationInbox/Workspace. Tests: story-memory-lifecycle, fixtures/story-lifecycle, e2e/story-lifecycle-ui/runtime. Финальные проверки и актуальные архивы — верх ROADMAP; пересборка не перезагружает установленную копию. Личный аккаунт/живая модель/installed Firefox не тестируются вместо синтетических проверок.

## Текущая точка после RP 223

Пакетная проверка новых записанных сцен подключена к игре. Последующие задачи RP224 описаны выше; этот раздел сохраняет передачу после пакетной части. Не повторять её очередь. Полный старый backfill и «бесконечный ролплей» не закрыты.

«История → Дополнительная проверка памяти» отдельно включает дополнительные запросы. По умолчанию выключено; automatic/paused/off имеют собственную revision. Inline220 сохраняется без дополнительных запросов. Запуск — в свободном видимом актуальном чате с пустым черновиком: после 12 ходов, при большом объёме или смене состава сцены после четырёх ходов. Частично разобранный большой текст продолжается следующей порцией. Проверка таймером 15 секунд не означает запрос модели каждые 15 секунд.

StoryRevision.memoryBatch хранит offset и request(id, anchor, policy, end, status, at). Receipt зависит от выбранного anchor: смена варианта повторно открывает ранние исходники, если результаты их анализа ушли с отменённой линией. Game.memoryBatchSources / Baseline.memoryBatchSeeds переносят выбранные источники через checkpoint и новый чат; новая игра очищает их. Полная копия хранит позиции; restore и импорт лора ставят дополнительный разбор на паузу с новой policy revision.

Транспорт общий с палочками: IsolatedFieldCoordinator + CharacterDiscoveryClient, один видимый masked popup, cleanup/ack. NativeStartLane исключает одновременное резервирование партии и cast. Brief и raw reply только в текущем background; потеря job — сохраняемая ошибка, не resend. Повтор разрешается явно. Существующий безопасный service audit использует категорию character-field/profile; состояние партий показывается отдельно.

JSON требует каждого source, complete:true, лимитов и точной цитаты в своей выдержке; это не доказательство смысловой полноты модели. Данные проходят planStoryAccompaniment и общую review queue. Batch events связаны с completed head и memoryBatchSourceRevisionId; profile proofs сохраняют исходные IDs. Старое state значение и пользовательское заявление о произошедшем событии не перезаписывают текущую память автоматически. Авторские поля/возраст/фото/числа сохранены.

Модули: core/storage story-memory-batch, StoryMemoryBatchPanel, native-start-lane; интеграция в graph/shared-game/checkpoint/reset/backup/import и content scheduler. Tests: story-memory-batch.test.ts, story-memory-batch-coordinator.test.ts, story-memory-batch-ui/runtime.spec.ts. Проверки и архивы — верх ROADMAP. Живая модель/личный аккаунт/installed Firefox не проверены.

## Начни здесь

Текущая точка и следующий шаг описаны выше. Ниже сохранена историческая передача после UX222 и критерии выполненной пакетной части RP-04. Поиск эмоций и большой экспорт тоже уже сделаны; повторять их реализацию не нужно.

Сначала проверь `git status`, ветку и последние коммиты. Рабочая ветка — `main`, remote — `https://github.com/NEONARCHY/DeepRole.git`. Если домашний checkout чистый, обнови его через `git pull --ff-only`. Если есть местные правки или расхождение веток, сохрани их и разберись с различиями; не выполняй reset/clean и не перезаписывай их автоматически. Не полагайся на наличие истории этого чата Codex: эта передача, AGENTS.md и свежие разделы ROADMAP — источник состояния работы.

Прочитай точечно: верх ROADMAP, раздел RP-04, `docs/AUTOMATIC-MEMORY.md` и `docs/WORLD-GAME.md`. Старые «Следующий шаг» в нижних исторических итерациях ROADMAP/MORNING-CHECKLIST не являются текущим приоритетом. Пользователь ожидает продолжения реализации, а не повторного общего обсуждения дорожной карты.

## Что уже готово

| Этап | Состояние |
| --- | --- |
| RP 211–213 | Возобновляемая очередь анкет, разбор большого исходного лора порциями, проверяемые связи найденных имён с существующими персонажами. |
| UX/RP 214–219 | Раздел «История», управление именами и объединениями, подсказки настроек, напоминание старого чата, одна общая игра лора, квадратные кнопки персонажей, пояснения ручной правки и защита полей. |
| RP 220 | Обычные завершённые ответы автоматически сохраняют пригодные факты и людей/дополнения, если сопровождение включено. Спорное уходит в сохраняемую очередь. **Ноль дополнительных модельных запросов** в текущем inline-пути. |
| FIX 221 | Большой экспорт: фото один раз в таблице, JSON частями, потоковое чтение records/photos. Мир v2 / backup v5; старые файлы поддерживаются. Без сжатия пикселей и квоты 200 МБ. |
| UX 222 | Поиск эмоций/действий при назначении изображений: часть RU/EN/custom названия, сохранение скрытого выбора, сброс ×, безопасные Enter/Escape. |

Актуальная установка: `downloads/DeepRole-Edge-emotion-search-20261012.zip`; канонические Chrome/Firefox/source ZIP находятся там же. Код, тесты и документы также переносятся Git. `.output`, `node_modules`, временные тестовые профили и `private-assets` не переносятся; локальные вспомогательные скрипты из прежнего компьютера не обязательны для продолжения.

## Решения пользователя, которые надо сохранить

- **Один лор — одна общая игра.** Новый чат подключается к последним персонажам/отношениям/характеристикам/памяти. Записывает актуальный чат; поздний ответ другого чата не получает право перезаписать игру.
- Авторский лор, возраст, ручной текст, исходные фото и защищённые поля сохраняются. Новые сведения идут через проверенные игровые overlays/события, не через переписывание всего канона.
- Имена/объединения следуют за общей игрой лора; исходные анкеты нужны истории и отмене. Более раннее решение «только текущий чат» заменено общей игрой RP218.
- **Возврат в старый чат и настоящий откат отложены пользователем.** Текущий RP218 может возобновить старый чат после напоминания, используя последние общие значения. Переделку на отдельное явное действие и откат сюжета сейчас не начинать: план сохранён в ROADMAP.
- Не включать скрыто новые платные/дополнительные запросы существующим пользователям. Не отправлять фотографии модели памяти и не запускать генерацию изображений при сопровождении.
- Интерфейс нужен обычному пользователю: обычные факты сохраняются без постоянных подтверждений, существенные сомнения объясняются коротко и отдельно. RU/EN, узкие панели, клавиатура и доступность обязательны.

## Исторические критерии пакетной части RP-04

**Сделай возобновляемый разбор небольшой партии новых подтверждённых сцен**, чтобы пропуски текущего inline-пути можно было дозаполнить без дублей, повторной полной подготовки персонажей и перезаписывания лора. Интервал **10–15 выбранных игровых ходов — начальный ориентир**, а не обещание отправлять весь лор с такой частотой. Учитывай объём, смену сцены и досрочную потребность отдельно.

1. Точечно проверь существующие durable receipts, исходные revision/event IDs, selected-line projection и service/job coordinators. Опиши границу нового слоя в ROADMAP; сохраняй рабочий inline 220.
2. Считай только новые завершённые игровые ходы актуальной выбранной линии. Исключи палочки, service/OOC, partial/failed, повтор/reload, отклонённые и невыбранные варианты. Привяжи курсор и состав партии к game/branch/revision/selection; смена варианта не должна сохранять чужую память.
3. Храни задание/курсор/статус/идемпотентность в существующем локальном хранилище и сейфе. Сбой или reload не повторяет уже принятый результат. Обработанная точка продвигается после проверенного сохранения; незавершённое можно продолжить или отменить. Импортированные audit записи не дают права автоматически запускать native работу.
4. Партия ограничивает **запрос**, не удаляет исходную историю. Используй доказуемые исходники и точные ссылки/цитаты, различай события, обещания, планы, секреты, мнения и задачи. Невыбранный вариант или обещание не превращается в произошедшее событие.
5. Используй текущие проверки повторов/конфликтов, protectedProfileFields и общую review queue. Рутинные пригодные факты следуют выбранной политике; существенное/неясное требует проверки. Служебный ответ не становится произвольной командой базе. Точная цитата не равна гарантии смысловой правильности.
6. Если глубокий разбор требует отдельного запроса DeepSeek, дай **отдельное понятное включение с объяснением частоты/расхода**, паузой и отключением. Существующее включение inline 220, обещающее ноль дополнительных запросов, не является разрешением скрытно начать такие партии. Не занимай неотправленный черновик и не запускай параллельную генерацию; используй имеющийся протокол служебной работы и проверяй актуальность после ожидания.
7. Проверь source proofs, права текущего writer, policy revision, ручные изменения, vault и выбранную линию при старте и финальном commit. Поздний ответ не воскресит отменённый факт и не перепишет ручную правку. Продолжение в новом чате наследует состояние обработки общей игры, не обнуляет его.
8. Минимальный видимый UX: включено/пауза, ожидающие сцены/готовый разбор, причина остановки и явный повтор при сбое. Не требуй открытия панели после каждого хода. Старую непроверенную переписку **до исходной точки** не анализируй автоматически: полный backfill остаётся отдельным явным действием.

### Критерии сдачи следующего этапа

- Партия новых сцен даёт пригодную память без повторов; сто синтетических ходов/reload не создают дубли.
- Повтор, partial/OOC, alternative/regenerate, пауза, прерванная работа, два чата/две вкладки, смена лора, поздняя ручная правка и блокировка сейфа проверены.
- Планы не сохраняются как завершённые события; конфликт/защита идут в review. Отмена выбранной сцены снимает её зависимую память.
- Отмена/ошибка сохраняет прежнюю память и черновик. Новая партия не отправляет фото или запрос провайдеру изображений.
- Full backup/restore и продолжение в новый чат сохраняют receipts/курсор, но не запускают импортированную служебную работу сами.
- Есть целевые unit и реальный синтетический browser flow, RU/EN 320/900, клавиатура/Axe, typecheck, сборки и ZIP. Живую модель/личный аккаунт отмечай отдельно от автотестов.

После этого продолжать смысловую проверку конфликтов и общий список незавершённых задач RP-04, затем общий релевантный бюджет RP-05. Маскировки/сложные идентичности RP-03 и полное дозаполнение старой переписки ещё открыты. Не объявлять весь «бесконечный ролплей» завершённым.

## Где продолжать в коде

- `src/core/story-automation.ts`, `src/storage/story-automation.ts`: policy, проверки фактов/людей, bounded inline planner.
- `src/core/story-automation-review.ts`, `src/storage/story-automation-review.ts`: сохраняемая проверка и late resolution исходных proposals.
- `src/core/story-dispatch-capture.ts`, `src/storage/story-dispatch-capture.ts`: принятые dispatch proofs и замороженные разрешения.
- `src/storage/story-game.ts`, `src/storage/world-game.ts`, `src/storage/story-history.ts`, `src/storage/story-effect-replay.ts`: выбранная история, writer, seeds и повторное применение.
- `src/adapters/*coordinator.ts`, `src/storage/service-*`, `src/core/service-*`: существующая служебная работа. Сначала найди подходящий coordinator по символам, не создавай второй транспорт вслепую.
- `src/entrypoints/shared/StoryAutomationPanel.tsx`, `StoryAutomationInbox.tsx`, `StoryWorkspace.tsx`: интерфейс сопровождения.
- `tests/story-automation.test.ts`, `tests/e2e/story-automation*.spec.ts`, `tests/world-game.test.ts`: исходная regression база.

## Проверки на момент передачи

Финальный общий прогон перед push: **3116 unit pass / 0 fail / 5 ранее отложенных todo**, TypeScript и diff без ошибок. FIX221 ранее дал полный unit **3106 pass / 5 todo**, затем **42 целевых**; UX222 — **26 целевых unit**, **8 новых GUI + 22 library/shared-emotion GUI**. В Edge проверен экспорт/импорт синтетических **24 персонажей / 40 фото / 280 MiB**, SHA-256 каждого оригинала совпал; отдельно установленная синтетическая MV3 восстановила v5. RP220 normal POST проверен на изолированной Edge MV3 без дополнительных запросов.

**Полный E2E не объявлен зелёным и не был прогнан целиком в этих итерациях.** Некоторые прежние getByLabel после добавления защиты анкеты теперь неоднозначны с checkbox: используй роль textbox/combobox вместо ослабления проверки. Старые подсказки перенесены в SettingsHelp. Исправленные целевые сценарии проходят. Личный аккаунт/живая модель/installed Firefox не проверены. Build large-chunk warning остаётся открытым RP-08.

### Команды и переносимость

После обычной установки зависимостей по lockfile:

```powershell
npm ci
npm run typecheck
npm test -- --maxWorkers=2
npm run test:e2e -- tests/e2e/story-automation.spec.ts --workers=2
npm run zip
npm run zip:firefox -- --sources
```

Браузерные тесты выполняй последовательно между отдельными Playwright запусками: они используют один сервер/каталог результатов. Конфигурация Chromium использует установленный Edge; Firefox должен быть доступен Playwright. Отсутствующий браузер не скрывай как успешную проверку. LeanCtx/Node пути зависят от компьютера: используй доступный runtime/MCP/CLI, не копируй прежние абсолютные пути без проверки.

После изменений обнови ROADMAP и эту передачу, пересобери обе `.output` папки и Chrome/Firefox/source ZIP, сверяй содержимое и отсутствие личных данных. Dated archives — исторические; актуальные canonical downloads должны соответствовать текущим сборкам. Пересборка или git pull **не перезагружает установленную копию Edge**: заменяются файлы именно в загруженной браузером папке, затем обновляются расширение и DeepSeek.
