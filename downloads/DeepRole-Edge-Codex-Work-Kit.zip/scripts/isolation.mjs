import {existsSync,lstatSync,mkdirSync,readdirSync,readFileSync,realpathSync,writeFileSync,openSync,closeSync,unlinkSync,renameSync} from 'node:fs';
import {resolve,join,dirname,isAbsolute,parse,relative} from 'node:path';
import {randomUUID,createHash} from 'node:crypto';

export const FORMAT='deeprole-agent-browser-v1';
export function noLinks(path){
 let current=resolve(path);
 for(;;){if(existsSync(current)&&lstatSync(current).isSymbolicLink())throw Error('Linked browser paths are not allowed');const parent=dirname(current);if(parent===current)break;current=parent;}
}
export function workspacePath(path){
 if(typeof path!=='string'||!isAbsolute(path)||resolve(path)===parse(resolve(path)).root)throw Error('A dedicated absolute workspace is required');
 const root=resolve(path),normal=root.replaceAll('\\','/').toLowerCase();
 if(/\/(?:brave-browser|chrome|edge)\/user data(?:\/|$)|\/gummy-desktop(?:\/|$)|\/browser-workspace(?:\/|$)/u.test(normal))throw Error('Existing browser profiles are forbidden');
 noLinks(root);return root;
}
export function ownedWorkspace(path,create=false){
 const root=workspacePath(path),marker=join(root,'ownership.json');
 if(!existsSync(marker)){
  if(!create)throw Error('Browser workspace has not been initialized');
  if(existsSync(root)&&readdirSync(root).length)throw Error('Refusing to adopt a nonempty directory');
  mkdirSync(root,{recursive:true});writeFileSync(marker,JSON.stringify({format:FORMAT,id:randomUUID()},null,2)+'\n',{flag:'wx'});
 }
 noLinks(marker);const owner=JSON.parse(readFileSync(marker,'utf8'));
 if(owner.format!==FORMAT||typeof owner.id!=='string'||!owner.id)throw Error('Invalid workspace ownership');
 for(const name of ['profile','extension','owner.lock','config.json'])noLinks(join(root,name));
 return root;
}
export function childPath(root,part){
 if(typeof part!=='string'||!part||part.includes('\\')||part.startsWith('/')||part.split('/').some(p=>!p||p==='.'||p==='..')||part.includes(':'))throw Error('Unsafe extension path');
 const path=resolve(root,part);if(relative(root,path).startsWith('..')||isAbsolute(relative(root,path)))throw Error('Path escapes root');noLinks(path);return path;
}
export const sha256=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
export function acquireOwner(root){
 const path=join(root,'owner.lock'),nonce=randomUUID();noLinks(path);
 if(existsSync(path)){
  const old=JSON.parse(readFileSync(path,'utf8'));if(old.format!==FORMAT||!Number.isSafeInteger(old.pid)||old.pid<1)throw Error('Unknown browser owner; refusing takeover');
  const running=pid=>{if(!Number.isSafeInteger(pid)||pid<1)return false;try{process.kill(pid,0);return true;}catch(error){return error.code!=='ESRCH';}};
  const alive=running(old.pid)||running(old.browserPid);
  if(alive)throw Error('This isolated browser already has a live owner');
  renameSync(path,join(root,'stale-owner-'+randomUUID()+'.json'));
 }
 const fd=openSync(path,'wx');try{writeFileSync(fd,JSON.stringify({format:FORMAT,pid:process.pid,nonce})+'\n');}finally{closeSync(fd);}
 const readOwned=()=>{noLinks(path);const current=JSON.parse(readFileSync(path,'utf8'));if(current.nonce!==nonce||current.pid!==process.pid)throw Error('Browser owner changed; refusing to release');return current;};
 const release=()=>{if(!existsSync(path))return;readOwned();unlinkSync(path);};
 release.trackBrowser=pid=>{if(!Number.isSafeInteger(pid)||pid<1)throw Error('Invalid owned browser PID');writeFileSync(path,JSON.stringify({...readOwned(),browserPid:pid})+'\n');};
 return release;
}
export function allowedUrl(value,extensionId,origins=[]){
 let u;try{u=new URL(value);}catch{throw Error('Invalid browser URL');}
 if(u.username||u.password)throw Error('Credentials in URLs are forbidden');
 if(u.href==='about:blank')return u.href;
 if(u.protocol==='chrome-extension:'&&extensionId&&u.hostname===extensionId&&!/%2e|%2f|%5c/iu.test(u.pathname))return u.href;
 if(['https:','http:'].includes(u.protocol)&&['https://chat.deepseek.com',...origins].includes(u.origin))return u.href;
 throw Error('URL is outside the isolated DeepRole workspace');
}

